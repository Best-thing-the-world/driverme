# DriverLink Deep Research — Cross-Dimension Insight Extraction

## Insight Generation Date: June 5, 2026
## Source Dimensions: 12 research dimensions + cross-verification
## Insight Count: 12

---

## Insight 1: The "Uber Disillusionment Pipeline" — A Captured Supply Base

**Insight:** A natural and growing supply pipeline of independent chauffeurs is being created by Uber's own business model evolution. As Uber's take rate climbed from 10% to 40%+ and the company prioritized autonomous vehicles (100K target by 2027) over human drivers, a wave of experienced premium drivers is actively seeking independence. This creates a **captive recruitment pool** for DriverLink.

**Derived From:** Dim 04 (driver economics), Dim 07 (marketplace dynamics), Dim 02 (competitive landscape)
**Supporting Evidence:**
- 72% of drivers report it's harder to earn the same amount vs. a year ago [^8^]
- Uber's own S-1 admitted ~70% of drivers quit within 8 months [Dim 04]
- Uber is acquiring Blacklane (March 2026) and deploying Waymo robotaxis — signaling reduced future reliance on human drivers in premium segments [^2^] [^11^]
- Black car drivers command 2.5-8x the hourly rate of UberX drivers when independent [Dim 04]
**Rationale:** The convergence of declining driver economics at Uber with Uber's strategic pivot to AVs creates a structural dislocation. Premium drivers who built their client relationships through Uber Black/Reserve now have both motive and means to go independent.
**Implications:** DriverLink should target recently departed Uber Black/Reserve drivers with specific messaging around "keep your earnings, own your brand."
**Confidence:** High

---

## Insight 2: The "SaaS-First, Marketplace-Second" Imperative — Why Network Effects Don't Matter (Yet)

**Insight:** Unlike ride-hailing where density-based network effects are everything, premium chauffeur services are fundamentally **relationship-based, not algorithm-based**. This means DriverLink should prioritize standalone SaaS utility over marketplace liquidity — the "come for the tool, stay for the network" approach validated by Toast and GlossGenius. Attempting to build a two-sided marketplace first would be a strategic error.

**Derived From:** Dim 07 (marketplace dynamics), Dim 03 (business models), Dim 04 (driver pain points)
**Supporting Evidence:**
- Premium/chauffeur network effects are asymptotic and weaker than ride-hailing [NFX analysis, Dim 07]
- 70% of small fleets still use manual scheduling [Dim 01] — the software pain point is more acute than the demand pain point
- OpenTable solved the same problem by building SaaS reservation tools first, then opening the marketplace [Dim 07]
- Toast achieved 118% annual growth by starting with POS (utility), not demand generation [Dim 03]
**Rationale:** The sequencing matters enormously. Drivers will pay for better scheduling, invoicing, and CRM tools immediately — even with zero riders on the platform. Marketplace liquidity can be layered on later once SaaS density is achieved.
**Implications:** The prototype's focus on driver dashboard, CRM, and storefront features (not rider acquisition) is strategically correct. Phase 1 should be pure SaaS; Phase 2 adds marketplace features.
**Confidence:** High

---

## Insight 3: The Regulatory Arbitrage Opportunity — SaaS Tool vs. Marketplace

**Insight:** How DriverLink positions itself legally (SaaS tool vs. transportation marketplace) determines its entire regulatory exposure. A **pure SaaS/booking tool model** that does not control dispatch, pricing, or hours and does not restrict drivers to the platform has dramatically stronger legal footing for avoiding licensing, insurance, and employee classification obligations across virtually all jurisdictions. This is a structural advantage that Uber, Lyft, and even Blacklane cannot replicate.

**Derived From:** Dim 08 (regulatory), Dim 02 (competitive), Dim 12 (international)
**Supporting Evidence:**
- California TCP requires W-2 employees for any TCP-listed vehicle [^471^]
- EU Platform Work Directive creates rebuttable employment presumption for "platforms" by Dec 2026 [Dim 12]
- 7+ US states have "marketplace contractor" laws codifying IC status — but these apply to marketplaces, not SaaS tools [Dim 08]
- FTC clarified (Jan 2025) that ICs are shielded from antitrust liability for collective bargaining [Dim 08]
**Rationale:** The legal distinction between "providing software tools" and "operating a transportation marketplace" is the single most important strategic positioning decision DriverLink will make. It affects every market, every pricing decision, and every feature.
**Implications:** Never dispatch rides. Never set prices. Never restrict drivers from multi-homing. The platform should be positioned as "Squarespace for chauffeurs" not "Uber for independents."
**Confidence:** High

---

## Insight 4: The "Fragmentation Multiplier" — Why Small Markets Outperform

**Insight:** Counter-intuitively, DriverLink's unit economics may be **better in Tier 2/3 cities** than in NYC/LA/SF. In smaller markets, independent chauffeurs have fewer alternatives, lower competitive intensity from Blacklane/Wheely, lower insurance costs, and higher relative value perception of SaaS tools. The Sun Belt strategy (Atlanta, Dallas, Houston) is not just about growth — it's about **profitability per driver**.

**Derived From:** Dim 01 (TAM), Dim 04 (driver economics), Dim 09 (GTM), Dim 12 (regional)
**Supporting Evidence:**
- NYC commercial insurance: $1,403/month; national average: $904/month [Dim 08]
- TLC licensing costs $500-$800 and requires 24-hour education course [Dim 08]
- California AB-1807 raised minimums to $2M (July 2025) [Dim 08]
- 80% of US population growth in Sun Belt [Dim 09]
- Atlanta, Dallas, Houston in top 3 growth metros [Dim 09]
**Rationale:** Higher regulatory and insurance costs in Tier 1 cities compress driver margins, making them more price-sensitive to SaaS fees. In Tier 2 cities, drivers keep more of their revenue and can afford higher SaaS spending.
**Implications:** Launch sequence: Atlanta (Month 1-6) → Dallas + Houston (7-12) → Charlotte + Phoenix + Tampa (13-18) → NYC/SF only after product-market fit is proven.
**Confidence:** Medium-High

---

## Insight 5: The "Corporate Travel Moat" — B2B2C as the Real Revenue Engine

**Insight:** While the prototype focuses on individual driver storefronts, the real enterprise value for DriverLink lies in **B2B2C corporate integrations**. Individual bookings through public storefronts will be dwarfed by corporate travel manager bookings through integrated platforms (Concur, Amex GBT, GroundSpan). This creates a two-revenue-stream model: SaaS from drivers + enterprise licensing from corporations.

**Derived From:** Dim 05 (customer segments), Dim 09 (GTM), Dim 10 (unit economics)
**Supporting Evidence:**
- Corporate clients represent 49-58% of chauffeur market revenue [Dim 05]
- Corporate travelers generate 2x bookings and 3x profitability vs. leisure [Dim 07]
- Uber for Business has 170,000+ customers [Dim 07]
- Amex GBT redesigned ground transport via GroundSpan partnership [Dim 09]
- 73% of travel managers prioritize safety over cost [Dim 05]
**Rationale:** Individual driver storefronts are the acquisition wedge, but corporate integrations are the retention and expansion engine. A single corporate account can generate more bookings than 50 individual customers.
**Implications:** Build SAP Concur/Expensify integration early. Target corporate travel managers as a parallel sales motion. The "DriverLink for Business" tier should be a separate product line.
**Confidence:** High

---

## Insight 6: The "Payments Layer Cake" — Embedded Fintech as 3-5x Revenue Multiplier

**Insight:** The prototype's booking and payment features are not just table stakes — they are the **primary revenue engine**. Across all vertical SaaS comparables, payment processing revenue eventually surpasses subscription revenue by 3-5x. At scale, DriverLink will generate 70-80% of revenue from the spread on payment processing, not from monthly subscriptions. This transforms the TAM from ~$42M (SaaS-only) to ~$108-500M (SaaS + Payments).

**Derived From:** Dim 03 (business models), Dim 10 (unit economics), Dim 01 (TAM)
**Supporting Evidence:**
- Toast: 85% of revenue from payments, 15% from subscriptions [^220^]
- Shopify: 74% from merchant solutions (payments), 26% from subscriptions [^721^]
- A16Z: embedded fintech increases revenue per customer by 2-5x [^741^]
- Embedded finance market: $185B opportunity, <20% addressed [^742^]
- Insurance commissions alone: 15-30% of premium [Dim 10]
**Rationale:** A driver processing $100K/year in bookings at 2.6% processing generates $2,600 in processing fees. The platform keeps 0.5-1.0% spread = $500-$1,000/year per driver in pure margin — 2x the subscription fee.
**Implications:** Prioritize Stripe Connect integration early. The 2.6% flat processing rate (GlossGenius model) is both a revenue driver and a competitive differentiator against fragmented, opaque alternatives.
**Confidence:** High

---

## Insight 7: The "NEMT Backdoor" — Recession-Proof Revenue with Government Guarantee

**Insight:** Non-Emergency Medical Transportation (NEMT) represents a **hidden trillion-dollar demand signal** (3.6 million missed appointments costing $150B annually) that is structurally underserved. As ModivCare (the largest broker) emerges from bankruptcy and the industry faces 64% annual driver turnover, independent drivers with the right certifications can capture predictable, recurring, government-backed demand. DriverLink could become the operating system for "medical chauffeurs."

**Derived From:** Dim 05 (customer segments), Dim 11 (vertical specialization), Dim 08 (regulatory)
**Supporting Evidence:**
- NEMT market: $4.4-6.6B in US, 7-10% CAGR [^134^]
- 3.6 million Americans miss medical appointments due to transport gaps [Dim 11]
- Dialysis patients generate 156 predictable trips/year [Dim 11]
- ModivCare bankruptcy signals industry stress but also opportunity [^885^]
- Medicare Advantage NEMT coverage expanding from 15% to 36% [Dim 05]
**Rationale:** Unlike discretionary luxury transport, medical transport is need-driven and largely government-funded. The ModivCare bankruptcy creates a supply vacuum that independent operators can fill.
**Implications:** Build NEMT-specific features: PASS certification tracking, wheelchair accessibility badges, Medicaid broker API integrations, recurring route scheduling. This vertical alone could justify a $50M+ valuation.
**Confidence:** Medium-High

---

## Insight 8: The "EV-First Mover" — Regulatory Tailwinds for Electric Chauffeurs

**Insight:** The convergence of corporate ESG mandates, urban emission zone regulations (ULEZ in London, congestion pricing in NYC), and Tesla's emergence as a luxury vehicle creates a **temporary first-mover advantage** for EV-focused independent chauffeurs. Blacklane's carbon-neutral positioning since 2017 gives them a 9-year head start, but the market is still early enough for DriverLink to capture the "green luxury" narrative.

**Derived From:** Dim 11 (vertical specialization), Dim 12 (international), Dim 05 (customer segments)
**Supporting Evidence:**
- 18% EV/hybrid in luxury fleets (2025), fastest-growing segment [Dim 11]
- Blacklane achieved EUR 300M revenue with carbon-neutral positioning [Dim 11]
- NYC congestion pricing + ULEZ in London favor zero-emission vehicles [Dim 12]
- Corporate clients increasingly demand carbon footprint tracking [Dim 05]
**Rationale:** Early EV adopters among chauffeurs face a paradox: they have the vehicles but lack the premium positioning and corporate access to monetize them. DriverLink can create an "EcoLuxury" certification tier that connects EV chauffeurs with ESG-conscious corporate clients.
**Implications:** Create an EV chauffeur badge/certification on the platform. Partner with Tesla, Lucid, and charging networks for referral revenue. Market to corporate travel managers with ESG mandates.
**Confidence:** Medium

---

## Insight 9: The "Vertical Stacking" Strategy — Why One Platform Beats Five

**Insight:** Rather than building separate products for airport, senior care, wedding, and corporate verticals, DriverLink should embrace **service templates** (as shown in the prototype) that let a single driver operate across multiple verticals. The same driver can do airport transfers Monday-Thursday, senior care Friday mornings, and weddings on Saturdays. This "vertical stacking" increases driver utilization and platform revenue per driver by 2-3x.

**Derived From:** Dim 05 (customer segments), Dim 11 (vertical specialization), Dim 10 (unit economics)
**Supporting Evidence:**
- Airport transfers: 47% of service type, most predictable demand [Dim 01]
- Weddings: $500-2,000 per event, 20-40% seasonal premium [Dim 11]
- NEMT: 156 recurring trips/year per patient [Dim 11]
- Hourly/as-directed services carry highest per-trip revenue potential [^2^]
**Rationale:** Independent drivers already want diversified demand streams to maximize utilization. A driver doing only airport transfers has ~40% utilization; adding hourly and event services can push this to 60-70%.
**Implications:** The prototype's service template system (airport, hourly, VIP black, senior, errand) is architecturally correct. Build analytics that help drivers identify optimal vertical mixes for their market.
**Confidence:** High

---

## Insight 10: The "Data Moat" — Switching Costs Through CRM Lock-In

**Insight:** In a premium chauffeur marketplace with weak network effects, the true defensibility comes not from density but from **data gravity**. As drivers build their customer CRM on DriverLink — storing preferences, booking histories, payment methods, and notes — the switching cost increases non-linearly. A driver with 200 customer profiles and 5 years of booking history on DriverLink faces a massive friction cost to migrate to any competitor.

**Derived From:** Dim 07 (marketplace dynamics), Dim 06 (technology), Dim 04 (driver pain points)
**Supporting Evidence:**
- CRM features increase switching costs more than subscription lock-in [Dim 07]
- Data portability regulations (GDPR Article 20) threaten lock-in but are poorly enforced [Dim 07]
- Square Appointments and GlossGenius both use customer directory as core retention mechanic [Dim 06]
- Independent drivers' #1 asset is their customer relationships [Dim 04]
**Rationale:** The prototype's CRM feature (customer profiles, booking history, notes, preferences) is the most strategically important feature for long-term defensibility — more important than marketplace liquidity.
**Implications:** Invest heavily in CRM features: customer tagging, automated follow-ups, loyalty program management, birthday/anniversary reminders. Make customer data export possible but migration painful through rich data formats.
**Confidence:** High

---

## Insight 11: The "International Timing Window" — EU Regulatory Collapse Creates Entry Opportunity

**Insight:** The EU Platform Work Directive (effective Dec 2026) will force existing ride-hail/chauffeur platforms to reclassify drivers as employees across 27 countries. This creates a **regulatory collapse event** where Uber, Lyft, and Blacklane face massive structural cost increases. A DriverLink-style pure-SaaS platform, operating as a software provider rather than an employer, could capture displaced independent chauffeurs across Europe.

**Derived From:** Dim 12 (international), Dim 08 (regulatory), Dim 02 (competitive)
**Supporting Evidence:**
- EU Platform Work Directive creates rebuttable employment presumption [Dim 12]
- Germany's P-Schein requirement (EUR 200-310, 5-year validity) already filters for professional drivers [Dim 12]
- France: 71,300 VTC drivers (+27% YoY), EUR 30/hour minimum guarantee [Dim 12]
- Blacklane acquisition by Uber means Uber inherits any EU regulatory restructuring costs [^12^]
**Rationale:** When the EU Directive takes effect, platforms will either absorb employment costs (raising prices) or shed drivers. Either outcome benefits a SaaS-tool alternative that stays outside the employment nexus.
**Implications:** Begin EU market research and localization planning NOW. Germany (Blacklane's home market) and UK (post-Brexit but similar regulatory trajectory) should be the first international targets.
**Confidence:** Medium

---

## Insight 12: The "Insurance Brokerage" Arbitrage — Unlocking Trapped Margin

**Insight:** Commercial livery insurance is the #1 pain point for independent drivers ($5K-$21K/year, often a surprise expense), yet no platform has built a **group buying + embedded insurance** solution at scale. By aggregating thousands of independent drivers into a collective risk pool, DriverLink could negotiate 20-40% premium reductions AND capture 15-30% commission on every policy sold. This single feature could add $500-1,500/year in revenue per driver — matching the entire SaaS subscription.

**Derived From:** Dim 04 (driver economics), Dim 08 (regulatory), Dim 10 (unit economics), Dim 03 (business models)
**Supporting Evidence:**
- Commercial livery insurance: $5K-$21.6K/year, largest fixed cost after vehicle [Dim 04]
- Over half of rideshare drivers lack proper gap coverage [Dim 08]
- California AB-1807 raised minimums to $2M — increasing costs further [Dim 08]
- Insurance commissions: 15-30% of premium = $750-$6,480/year per policy [Dim 10]
- NLA already offers affinity discount programs (40% off background checks, fuel cards) [Dim 09]
**Rationale:** Insurance is both the biggest pain point and the biggest untapped revenue opportunity. The NLA's affinity model proves group buying works but hasn't been productized at scale.
**Implications:** Partner with commercial auto insurers (Progressive Commercial, GEICO, FHIA) to create a "DriverLink Insurance" group program. Offer it as an upsell to all drivers. Build insurance requirement tracking into the onboarding flow.
**Confidence:** High

---

## Insight Summary Matrix

| # | Insight | Strategic Priority | Confidence |
|---|---------|-------------------|------------|
| 1 | Uber Disillusionment Pipeline | Marketing/Supply | High |
| 2 | SaaS-First, Marketplace-Second | Product Strategy | High |
| 3 | Regulatory Arbitrage (SaaS vs. Marketplace) | Legal/Positioning | High |
| 4 | Fragmentation Multiplier (Tier 2/3 > Tier 1) | GTM/City Selection | Medium-High |
| 5 | Corporate Travel Moat (B2B2C) | Revenue/Growth | High |
| 6 | Payments Layer Cake (3-5x TAM) | Revenue Model | High |
| 7 | NEMT Backdoor (Recession-Proof) | Vertical Expansion | Medium-High |
| 8 | EV-First Mover (Regulatory Tailwinds) | Differentiation | Medium |
| 9 | Vertical Stacking (Utilization > 60%) | Product/Retention | High |
| 10 | Data Moat (CRM Lock-In) | Defensibility | High |
| 11 | International Timing Window (EU Directive) | Expansion | Medium |
| 12 | Insurance Brokerage Arbitrage | Revenue/Retention | High |
