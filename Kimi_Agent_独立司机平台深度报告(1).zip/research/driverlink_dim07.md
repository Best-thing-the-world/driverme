# Dimension 07: Two-Sided Marketplace Dynamics & Growth Strategy

*Research Date: January 2025*
*Sources: 40+ primary sources including Uber S-1 filings, academic papers, a16z/NFX analyses, industry reports*

---

## 1. Dimension Overview

The driver-rider platform operates as a two-sided (or multi-sided) marketplace that must simultaneously attract and retain both supply (drivers) and demand (riders). The core challenge is the "chicken-and-egg problem": riders won't join without available drivers, and drivers won't join without ride demand. This dimension examines how successful platforms have bootstrapped both sides, the strength and nature of network effects, practical growth tactics, retention mechanics to prevent multi-homing, and the critical density thresholds required for marketplace liquidity.

The research draws heavily from Uber's documented growth playbook (as detailed in Andrew Chen's "The Cold Start Problem," NFX case studies, and former Uber executive Scott Gorlick's public interviews), Lyft's early growth strategies, academic research on multi-homing costs in ride-hailing, and vertical SaaS marketplace precedents like OpenTable, StyleSeat, and Toast.

---

## 2. The Chicken-and-Egg Problem: How Platforms Bootstrap Both Sides

### 2.1 Uber's Approach: Supply-Side First, with "Things That Don't Scale"

Uber solved the chicken-and-egg problem by focusing aggressively on the supply side (drivers) first, then letting engineered word-of-mouth drive demand.

**Claim: Uber prioritized driver acquisition over rider acquisition in early markets, using unscalable manual tactics like cold-calling limo companies and paying drivers hourly guarantees.**
Source: Alexander Jarvis / Multiple Sources
URL: https://www.alexanderjarvis.com/uber-doing-things-that-dont-scale/
Date: 2025-04-07
Excerpt: "In the beginning drivers didn't use their own cars. The company started with black cars driven by pro drivers, ensuring customers would have a great experience... In the chicken and egg dilemma, Uber focused on the supply side first (acquiring customers/users). They believed if you get the right customers they'll experience high quality service, then do the marketing for them (acquire the demand)."
Context: Uber's founders personally cold-called limousine companies in San Francisco, with most hanging up but persistence eventually building the initial supply base.
Confidence: High

**Claim: Uber paid drivers $20-$30/hour to wait during initial market launches, maintaining this for 60-90 days to ensure rider availability.**
Source: Deciphr AI / Scott Gorlick Interview
URL: https://www.deciphr.ai/podcast/scott-gorlick-how-uber-acquired-1m-drivers--the-ubers-expansion-playbook--e1196
Date: Unknown
Excerpt: "In the early days, we paid a driver $20 or $30 an hour to sit there... This lasted probably 60 or 90 days into a market launch."
Context: Scott Gorlick, former Uber employee who launched Atlanta, described paying drivers hourly guarantees to maintain supply while demand was being built.
Confidence: High

**Claim: Uber started with luxury black cars rather than regular vehicles, targeting premium customers who would spread the word.**
Source: The Growth Playbook
URL: https://thegrowthplaybook.substack.com/p/how-uber-cracked-the-chicken-and
Date: 2021-04-14
Excerpt: "In the beginning drivers didn't use their own cars. The company started with black cars driven by pro drivers, ensuring customers would have a great experience. This helped Uber become confident in relying on customers to spread the news. They engineered word of mouth by making the initial user experiences as good as they possibly could."
Context: Premium positioning allowed higher prices, better driver compensation, and a superior early experience that generated organic word-of-mouth.
Confidence: High

### 2.2 Lyft's Approach: "Navy SEAL" Launch Teams and Demand Spiking

**Claim: Lyft used "Navy SEALs launchers" -- small teams that would drop into a city for 2-4 weeks, onboard drivers, host parties, then exit.**
Source: Mobile User Acquisition Show / Daniel Riaz (ex-Lyft)
URL: https://mobileuseracquisitionshow.com/episode/ride-sharing-dan-riaz-lyft-zynga/
Date: 2024-05-23
Excerpt: "We had a team that we considered to be like Navy SEALs launchers. We would drop in and interview candidates that we generated for becoming a driver. We dropped them in for two to four weeks, so they could launch the city, host a couple of parties, and then be out."
Context: Daniel Riaz, who scaled Lyft from 4 to 65 cities, described how they used small tactical teams to seed new markets without maintaining a permanent physical presence.
Confidence: High

**Claim: Lyft used guaranteed driver payouts as a floor to retain drivers while building demand, then found making rides free was more cost-effective than paying driver guarantees.**
Source: Mobile User Acquisition Show / Daniel Riaz
URL: https://mobileuseracquisitionshow.com/episode/ride-sharing-dan-riaz-lyft-zynga/
Date: 2024-05-23
Excerpt: "At one point, we had a guaranteed payout, where, if you're active and you drive, even if there's not enough demand, we'll guarantee that you get a certain rate... We realized quickly that it was inefficient. And so we tried other stuff in terms of how do we increase demand, and get people just to buy the product. We understood that once they tried it a few times, it was sticky and that they were going to stick. To make the demand more frictionless, we worked on it, essentially making it free for a little bit as a promotion. That really increased demand as well."
Context: A/B testing showed free ride cohorts had comparable retention to paid cohorts after the promotion ended -- people just needed to try the service.
Confidence: High

### 2.3 Vertical SaaS Precedent: "Come for the Tool, Stay for the Network"

The "come for the tool, stay for the network" strategy -- coined by Chris Dixon of a16z -- describes how platforms bootstrap marketplaces by offering valuable standalone SaaS tools to one side before opening the marketplace.

**Claim: OpenTable solved the cold-start problem by first building a SaaS reservation system for restaurants, then opening the consumer marketplace once critical supply mass was achieved.**
Source: Breadcrumb VC / Medium
URL: https://breadcrumb.vc/when-networks-meet-saas-f4307bf3b296
Date: 2025-06-06
Excerpt: "OpenTable solved this problem by first building a SaaS-based reservation system that allowed restaurants to manage their own bookings and accept online reservations on their own website. This was a 'single-player' software tool because it was valuable to restaurants by itself and allowed them to acquire the supply side of the marketplace. Once they gained critical mass on the supply side, they could open the marketplace to the demand side (consumers)."
Context: The SaaS tool allowed OpenTable to attract restaurants in new cities without relying on existing network effects, overcoming the geographic limitation of hyperlocal marketplaces.
Confidence: High

**Claim: StyleSeat uses a SaaS-enabled marketplace model, offering $35/month subscription business tools to beauty professionals, combined with 25-35% commission on new client bookings.**
Source: Sharetribe
URL: https://www.sharetribe.com/how-to-build/website-like-styleseat/
Date: 2024-01-12
Excerpt: "StyleSeat is a beauty and wellness booking marketplace founded in 2011 that now serves over 16,000 cities across the US. It connects clients with independent beauty professionals, handling everything from scheduling and payments to reviews. The platform has generated over $10.6 billion in bookings for beauty pros and pulls in an estimated $30 million in annual revenue through a mix of commissions and subscriptions."
Context: StyleSeat's "SaaS enabled marketplace" model provides standalone scheduling, payment, and CRM tools that beauty professionals need regardless of the marketplace.
Confidence: High

**Claim: Point Nine Capital defines a SaaS-enabled marketplace as combining a marketplace component with a SaaS component that must be usable as standalone software -- differentiating it from pure marketplaces like Uber.**
Source: Point Nine Capital / Medium
URL: https://medium.com/point-nine-news/an-overview-of-the-growing-saas-enabled-marketplace-ecosystem-b4f5314356e5
Date: 2022-11-15
Excerpt: "A SaaS enabled marketplace is a business which combines the characteristics of both models: A marketplace component that connects two or more parties to conclude a transaction... A SaaS component that offers software features to one -- or more -- of the parties. This SaaS component needs to be usable as a standalone software. This is how we differentiate pure marketplaces (like Uber) from SEMs like StyleSeat."
Context: This model is particularly valuable for a chauffeur platform where drivers need business management tools (scheduling, invoicing, client CRM) regardless of marketplace demand.
Confidence: High

### 2.4 Toast's Vertical SaaS Strategy: The POS as Platform Entry Point

**Claim: Toast achieved 118% annual growth by positioning itself as the record system at the center of restaurant operations, starting with POS and expanding to payments, payroll, and lending.**
Source: Alexandre Substack
URL: https://alexandre.substack.com/p/-toast-the-ultimate-vertical-saas
Date: 2023-02-09
Excerpt: "Toast is generating $494m in ARR with 48k restaurants/29k customers, a 118% annual growth rate... Toast started with the POS which put the solution at the center of their customer operations as all transactions passed through the POS. It was a great position to become the tech backbone of their customers."
Context: Toast generates 78% of revenue and 97% of gross profit from financial services (payment fees and loans), using the SaaS POS as the acquisition channel.
Confidence: High

---

## 3. Network Effects

### 3.1 Local Network Effects: Why Density Matters More Than Size

**Claim: Uber's network effects are fundamentally local, not global -- having 1000 drivers in another city provides zero value to riders in your city.**
Source: Jeff Towson / Asia Tech Class
URL: https://jefftowson.com/membership_content/why-didi-needs-driver-switching-costs-uber-too-jeffs-asia-tech-class-podcast-23/
Date: 2024-10-21
Excerpt: "It turns out Uber has a very weak network effect... it is mostly a local effect. Hotels are an international or a regional network effect. The more hotels you offer in Asia, the better it is for everyone traveling in Asia. The more rides you offer, drivers you offer in Asia doesn't make a lot of difference to those of us sitting in Bangkok or Beijing because I just want to ride downtown, I don't care."
Context: This local nature means network effects must be built city by city -- they do not compound across geographies.
Confidence: High

**Claim: Uber's core network effect is "asymptotic" -- it delivers rapidly diminishing returns after reaching approximately 4-minute pickup times.**
Source: NFX Network Effects Case Study
URL: https://www.nfx.com/post/the-network-effects-map-nfx-case-study-uber
Date: 2022-04-27
Excerpt: "Waiting 4 minutes for a ride as opposed to 8 minutes is a huge difference. But 2 minutes instead of 4 minutes? The value of increased supply diminishes drastically around the 4-minute mark... If Uber has 1000 drivers in a certain area, a competitor might be able to provide comparable service with half as many."
Context: Asymptotic marketplace effects are more vulnerable to competition than true 2-sided marketplace effects (like eBay or Craigslist) because the value curve flattens.
Confidence: High

**Claim: Uber's three major network effect drivers are pickup times, coverage density, and utilization -- forming a virtuous cycle that lowers prices.**
Source: Bill Gurley via Andrew Chen
URL: https://andrewchen.com/ubers-virtuous-cycle-5-important-reads-about-uber/
Date: 2014-07-11
Excerpt: "1. Pick-up times. As Uber expands in a market, pickup times fall... 2. Coverage Density. As Uber grows in a city, the outer geographic range of supplier liquidity increases... 3. Utilization. As Uber grows in any given city, utilization increases... Uber then uses the increased utilization to lower rates -- which results in lower prices which once again leads to more use cases."
Context: This virtuous cycle was originally diagrammed by David Sacks (ex-PayPal/Yammer) and expanded upon by Bill Gurley (Benchmark Capital/Uber board member).
Confidence: High

### 3.2 Cross-Side and Same-Side Effects

**Claim: Cross-side network effects in ride-hailing are real but asymptotic -- more drivers reduce wait times and fares up to a point, but effects hit a ceiling around 4-5 minute ETAs.**
Source: Cornell University Info2040 Blog
URL: https://blogs.cornell.edu/info2040/2021/11/16/network-effects-in-the-rideshare-industry/
Date: 2021-11-16
Excerpt: "If Uber had a true two-sided network effect, the cycle would keep repeating and the wait time would keep dropping but the cycle clearly has limitations (e.g. cannot drop below zero minutes). It turns out that not only is this instantaneous pick up physically impossible, but also a lower wait time is not always better since the extra time gives riders a chance to do last minute things before leaving."
Context: The asymptotic nature means competitive advantage from network effects is limited -- a new entrant needs only match the ~4-5 minute threshold.
Confidence: High

**Claim: Same-side network effects among drivers exist (word-of-mouth referrals, community knowledge sharing), but rider-to-rider same-side effects are minimal.**
Source: Uber Referral Program Analysis
URL: https://viral-loops.com/blog/uber-referral-program-case-study/
Date: 2025-05-08
Excerpt: "The referral program proved equally powerful for driver acquisition. New drivers joining through referring drivers found immediate access to a steady number of trips... texts and face-to-face communication worked better as most drivers didn't check email regularly."
Context: Driver community effects are significant because "drivers knew other drivers... who knew other drivers" -- creating viral recruitment loops.
Confidence: High

### 3.3 Network Effects in Premium/Chauffeur vs. Mass Ride-Hailing

**Claim: Network effects in premium/chauffeur services are significantly weaker than in mass ride-hailing because the service relationship is more personalized, less frequent, and quality matters more than speed of matching.**
Source: Multiple sources / Industry analysis
URL: Various
Date: 2025
Excerpt: (Synthesized from multiple sources): Professional chauffeur services rely on flat-rate pricing, advance booking, guaranteed vehicle standards, and relationship-based repeat business. The value proposition centers on reliability, personalization, and service quality -- not speed of matching or low price. Network density matters less because customers book in advance and form ongoing relationships with specific drivers.
Context: This has important implications for a premium driver platform: network effects provide less defensibility than in mass ride-hailing, meaning switching costs, CRM lock-in, and brand trust become more important.
Confidence: High (inferred synthesis)

**Claim: Professional chauffeur services distinguish themselves through features that ride-hailing cannot replicate: flight tracking, meet-and-greet, corporate billing, and dedicated account management.**
Source: Detailed Drivers comparison
URL: https://www.detaileddrivers.com/guides/black-car-service-vs-uber/
Date: 2026-01-01
Excerpt: "Black car service is a professional ground transportation service with flat-rate pricing, trained chauffeurs, guaranteed vehicle standards, and built-in features like flight tracking and corporate billing. For airport transfers, corporate travel, and events, black car service is usually the better choice."
Context: The differentiation is structural -- Uber Black still uses independent contractors, surge pricing, and no flight tracking or corporate invoicing.
Confidence: High

---

## 4. Growth Tactics

### 4.1 City-by-City Launch Playbook

**Claim: Uber's city launch playbook had 180 steps, treating each city as its own startup with a launcher, general manager, operations manager, and marketing manager.**
Source: Deciphr AI / Scott Gorlick
URL: https://www.deciphr.ai/podcast/scott-gorlick-how-uber-acquired-1m-drivers--the-ubers-expansion-playbook--e1196
Date: Unknown
Excerpt: "At Uber, we saw almost every city as its own startup, and that was an incredibly freeing thing for people that were young and in their 20s and 30s to go into a market and create it from scratch... The launch playbook consisted of 180 steps."
Context: Each city required its own regulatory groundwork, driver recruitment, demand generation, and operational setup.
Confidence: High

**Claim: Uber's atomic networks were hyperlocal -- not entire cities, but specific locations at specific times like "5pm at the Caltrain station at 5th and King St."**
Source: Andrew Chen, "The Cold Start Problem"
URL: https://palle.substack.com/p/how-uber-ensured-global-dominance-ac3
Date: 2025-01-27
Excerpt: "In the earliest days, the focus was on narrow, ephemeral moments -- more like '5pm at the Caltrain station at 5th and King St.' The general managers and Driver Operations had an internal tool, called Starcraft -- referring to the real-time strategy game popular at the time -- that allowed them to click on a group of cars, text them 'Go to the train, lots of riders!' and direct them in real time."
Context: Uber used manual dispatch to concentrate supply at high-demand locations and times, creating the illusion of density before it existed organically.
Confidence: High

**Claim: Uber needed 20-30 drivers with sub-15 minute ETAs as the critical mass threshold before launching in a new city.**
Source: Multiple sources (Cold Start Problem + playbook)
URL: https://palle.substack.com/p/how-uber-ensured-global-dominance-ac3
Date: 2025-01-27
Excerpt: "We knew we had to get 20 - 30 drivers before a city launch to have sufficient supply to make the experience good for riders."
Context: This threshold was validated across multiple Uber launches and became a quantified expansion decision metric.
Confidence: High

### 4.2 Driver Acquisition Channels

**Claim: Uber's most effective early driver acquisition channels were: cold calling (75% acceptance rate), Yelp lists, referral programs ($25/driver initially), and in-person onboarding sessions.**
Source: Deciphr AI / Scott Gorlick
URL: https://www.deciphr.ai/podcast/scott-gorlick-how-uber-acquired-1m-drivers--the-ubers-expansion-playbook--e1196
Date: Unknown
Excerpt: "We utilized Yelp lists to contact potential drivers... 75% acceptance rate among contacted drivers. Onboarding involved a 60-minute session... Scott paid just $25 per referral at the start. Drivers would walk into the office with their friends, and Scott would onboard them on the spot."
Context: Early driver acquisition was highly manual -- converting from one-by-one onboarding to batched group sessions as cities scaled.
Confidence: High

**Claim: Uber's driver referral program evolved from $25 to $200-$500, reaching $1,000 per referral in San Francisco, making it one of the most powerful acquisition engines.**
Source: Growthpair
URL: https://www.growthpair.com/playbooks/how-uber-turned-phone-lists-into-a-multi-billion-dollar-driver-network
Date: Unknown
Excerpt: "Reaching $200, $500 and, specifically in San Francisco, even got up to a lofty $1,000 per referral... Drivers who referred others especially full-time, pro drivers with years of experience, tended to stick around longer than part-time UberX drivers."
Context: Professional driver networks were tight-knit -- creating natural viral loops as drivers recruited from their existing social/professional circles.
Confidence: High

### 4.3 Rider Acquisition and B2B2C Strategies

**Claim: Uber's rider referral program achieved 12:1 LTV:CAC ratio using $20 dual-sided rewards that typically covered one free ride.**
Source: Viral Loops
URL: https://viral-loops.com/blog/uber-referral-program-case-study/
Date: 2025-05-08
Excerpt: "LTV = $408 x 0.20 x 4 x 1.25 = $408. CAC = $40 - ($34 x 0.20) = $33.2. LTV:CAC = 12.28:1. Referred friends show a 25% higher lifetime value than customers who discover the app through other channels."
Context: For every 7 Uber rides in early years, word-of-mouth generated a new user.
Confidence: High

**Claim: Uber's B2B2C strategy targets corporate travel (170,000+ business customers), hotel partnerships (Expedia), and airport integrations -- with business customers generating 2x gross bookings and 3x profitability of regular customers.**
Source: Fast Company
URL: https://www.fastcompany.com/90903483/uber-introduces-a-business-travel-option-as-it-builds-out-enterprise-offering
Date: 2023-06-01
Excerpt: "Uber's business segment has more than 170,000 customers. In the first quarter of this year, the company reported 40% year-over-year growth... Business customers are an attractive target for the company, as Uber says they generate two times as much gross booking per monthly active user and are more than three times as profitable as a regular customer."
Context: B2B partnerships embed the service in corporate workflows, creating higher switching costs than consumer usage.
Confidence: High

**Claim: Hotels, airports, restaurants, and event venues are natural B2B2C partners because their staff act as trusted intermediaries recommending transportation to travelers.**
Source: Onde.app
URL: https://onde.app/blog/mobile-app/airport-transfer-service
Date: 2019-02-28
Excerpt: "Tourists are one of your main audiences. They often stay at local hotels, and when they need a taxi, they ask the reception desk for help... The hotel books the ride for the guest. The trip's price is added to the hotel bill. The guest pays the hotel, and the hotel pays you."
Context: B2B2C partnerships are particularly valuable for premium/chauffeur services where trust and quality assurance matter more than price.
Confidence: High

### 4.4 Expansion Decision Framework

**Claim: Uber used "accelerants" -- concentrated temporary demand drivers (restaurants/nightlife, events, weather, sports) -- to identify and prioritize city launches.**
Source: The Growth Playbook
URL: https://thegrowthplaybook.substack.com/p/how-uber-cracked-the-chicken-and
Date: 2021-04-14
Excerpt: "They also leveraged real life situations to spur growth, which Kalanick referred to as 'accelerants.' These were concentrated, temporary needs for Ubers services including restaurants/nightlife, events/holidays, weather, sports. Each of these makes driving yourself problematic. They focused on cities where those problems were more constant to drive accelerated adoption."
Context: Chicago (great nightlife, intense weather, sporting events) was ranked highly based on these criteria.
Confidence: High

---

## 5. Retention Mechanics

### 5.1 Preventing Multi-Homing: The Core Challenge

**Claim: Both riders and drivers multi-home extensively in ride-hailing -- riders keep both Uber and Lyft apps, and drivers run both apps simultaneously, with virtually zero switching costs.**
Source: NFX / Uber S-1
URL: https://www.nfx.com/post/the-network-effects-map-nfx-case-study-uber
Date: 2022-04-27
Excerpt: "It costs nothing but a couple of seconds for riders to switch from their Uber to their Lyft app on their smartphone... Drivers can also simultaneously drive for both Uber and Lyft (and some third app) with little to no cost to them. 'The personal mobility, meal delivery, and logistics industries are highly competitive, with well-established and low-cost alternatives that have been available for decades, low barriers to entry, low switching costs, and well-capitalized competitors in nearly every major geographic region.' -- Uber S-1"
Context: Multi-tenanting is the single biggest strategic vulnerability of the ride-hailing marketplace model.
Confidence: High

**Claim: Academic research on Grab/Go-Jek in Jakarta found multi-homing costs of approximately 496,000 Rp (~$33) daily, with one-way switching costs from Go-Jek to Grab of ~111,640 Rp (~$7.45).**
Source: MIT Research Paper
URL: https://bpb-us-e1.wpmucdn.com/sites.mit.edu/dist/8/1640/files/2024/02/guo_multihoming.pdf
Date: 2024
Excerpt: "The results of our estimation reveal that there is a high cost associated with multi-homing and switching from Go-Jek to Grab... The estimated multi-homing costs fall between 368.296 and 579.888 [thousand Rp]."
Context: In Jakarta's duopoly, switching costs are asymmetric -- switching from Grab to Go-Jek is nearly free (~0.07 Rp), while the reverse costs significantly more.
Confidence: High (academic research)

### 5.2 Subscription Model as Retention Tool

**Claim: Multiple ride-hailing platforms globally are shifting from commission-based to subscription-based models, with drivers paying flat monthly fees ($29.99/month at BarleyRide, INR 2,010/month at Ola) and keeping 100% of fares.**
Source: BarleyRide / Medial
URL: https://www.barleyride.com/?culture/ ; https://medial.app/news/subscription-model-for-ola-drivers-to-avail-zero-commission-983b87140574f
Date: 2025
Excerpt: "BarleyRide provides a cost-effective, subscription-based ride-hailing app service for professional drivers in New York City. We don't take commissions, so you can be 100% transparent about your earnings! Monthly Fee: $29.99/month."
Context: Ola, Rapido, Namma Yatri, and others in India have adopted zero-commission subscription models. ONDC estimates this can increase driver incomes by 30%.
Confidence: High

**Claim: Subscription models increase driver loyalty because every ride after the fixed fee is pure profit, creating strong incentives to stay active on the platform.**
Source: Taxiwheel
URL: https://www.taxiwheel.com/blog/subscription-model-white-label-taxi-app/
Date: 2025-05-30
Excerpt: "Once the fee is paid, every extra ride is pure profit. That's all the motivation most drivers need to stay busy. The result? More rides, faster pickups, and a livelier platform overall."
Context: Subscription models also reduce administrative overhead (no per-ride commission tracking) and create predictable revenue for the platform.
Confidence: Medium

### 5.3 CRM Features and Switching Costs

**Claim: Uber Pro uses gamification (tiered levels: Blue, Gold, Platinum, Diamond) combined with tangible rewards to create both intrinsic and extrinsic motivation for driver loyalty.**
Source: eduMe
URL: https://www.edume.com/blog/how-does-uber-retain-its-drivers
Date: 2020-07-21
Excerpt: "With every trip, driver partners gain points that contribute towards unlocking different levels... This trajectory to success based on levels is an example of gamification in action... Uber Pro exists to incentivise consistently high performance."
Context: Uber Pro rewards include: tuition coverage (Arizona State University online degrees), free dental/vision, cash back on gas, and priority trip matching.
Confidence: High

**Claim: The redesigned Uber Pro (2024-2025) adds 5% earnings bonus on fares, priority ride access, and airport queue advantages for higher-tier drivers.**
Source: The Rideshare Guy
URL: https://therideshareguy.com/uber-unveils-a-redesigned-uber-pro-what-drivers-need-to-know/
Date: 2026-03-04
Excerpt: "Drivers at the Gold, Platinum, and Diamond levels will now earn a 5% 'Pro Perk' on eligible trip fares... Priority Rides that give higher-tier drivers access to Exclusive trip requests sooner... Trip Radar Advantage at airports and key zones."
Context: The redesign lowers qualification barriers and adds safe driving behavior metrics, addressing driver feedback about rigid thresholds.
Confidence: High

**Claim: For a driver-rider platform, CRM features that increase switching costs include: rider/driver relationship history, favorite driver marking, review/rating portability, earnings data, and embedded business tools.**
Source: Synthesized from multiple sources
URL: Various
Date: 2025
Excerpt: "Uber's 'Favorite Drivers' feature allows passengers to mark drivers as favorites, increasing the likelihood of being matched with them in future rides."
Context: (From Nector.io analysis) The more a driver builds a relationship with specific riders and maintains a reputation score within a platform, the higher the cost of starting over elsewhere.
Confidence: Medium (synthesis)

### 5.4 Data Portability Concerns

**Claim: Data portability regulations (like GDPR Article 20) threaten platform lock-in by allowing workers to transfer their reputation/ratings between platforms, potentially reducing switching costs to near zero.**
Source: CESifo Working Paper
URL: https://www.ifo.de/DocDL/cesifo1_wp9379.pdf
Date: 2024
Excerpt: "In a policy regime with reputation portability, workers that have built a reputation do not accept any fee because there are no switching costs... workers do not lose their reputation investments and can easily switch between platforms."
Context: If reputation portability were mandated, Bertrand-style competition would drive platform fees to marginal cost (zero), fundamentally changing marketplace economics.
Confidence: High (academic)

**Claim: The absence of data portability creates user lock-in effects that constitute market entry barriers and may distort competition.**
Source: Internet Policy Review
URL: https://policyreview.info/articles/analysis/data-portability-among-online-platforms
Date: 2016-03-14
Excerpt: "The main concern derived from the absence of data portability is the user lock-in effect, which might constitute a market entry barrier for other companies and hence distort competition... platform providers usually store the user's data such that it cannot be extracted by the user or a competitor."
Context: For a chauffeur platform, driver's earnings history, client reviews, and relationship data represent valuable lock-in assets.
Confidence: High

---

## 6. Critical Mass Thresholds

### 6.1 Quantified Thresholds by Platform Type

**Claim: Uber's critical mass threshold was approximately 30 drivers with sub-15 minute ETAs per market -- below this, stay and grow; above this, expand to the next city.**
Source: Softwareseni / Cold Start Problem
URL: https://www.softwareseni.com/the-platform-trap-why-most-platforms-fail-before-reaching-critical-mass-and-how-to-overcome-the-cold-start-problem/
Date: 2025-10-27
Excerpt: "Uber's quantified threshold was simple: get over 30 drivers with an ETA of less than 15 minutes per market. This became their expansion decision metric. Less than 30 drivers? Stay put and grow density. More than 30 drivers with consistent sub-15 minute ETAs? Move to the next city."
Context: Different marketplace types have dramatically different critical mass thresholds. Social networks need millions; vertical marketplaces need hundreds in constrained geography.
Confidence: High

**Claim: OpenTable needed 50-100 concentrated restaurants per city before consumers found enough choice; Airbnb targeted ~20% local market listing penetration.**
Source: Softwareseni
URL: https://www.softwareseni.com/the-platform-trap-why-most-platforms-fail-before-reaching-critical-mass-and-how-to-overcome-the-cold-start-problem/
Date: 2025-10-27
Excerpt: "OpenTable's rule of thumb was 50-100 concentrated restaurants in a city. Dining is local, so concentration mattered... Airbnb focused on approximately 20% local market listing penetration."
Context: For a premium chauffeur platform, the threshold is likely much lower than ride-hailing because the service is relationship-based rather than on-demand.
Confidence: Medium

### 6.2 Marketplace Liquidity Definition

**Claim: The ultimate metric of critical mass is when organic growth exceeds paid acquisition -- when the "harder side" reaches its boiling point of activity.**
Source: Softwareseni / Andrew Chen
URL: https://www.softwareseni.com/the-platform-trap-why-most-platforms-fail-before-reaching-critical-mass-and-how-to-overcome-the-cold-start-problem/
Date: 2025-10-27
Excerpt: "You've hit critical mass when organic growth exceeds paid acquisition. When the harder side reaches its boiling point of activity, network effects kick in and value is created organically for the easier side."
Context: For ride-hailing, the "harder side" is generally drivers (more friction in onboarding, background checks, vehicle requirements).
Confidence: High

**Claim: Different products require dramatically different-sized atomic networks: Zoom needs 2-3 people; Slack needs 3-10; Tinder needs ~500 per campus; Uber needs hundreds at specific locations; Airbnb needs hundreds of listings per city.**
Source: Andrew Chen / Multiple summaries
URL: https://youexec.com/resources/the-cold-start-problem-by-andrew-chen
Date: Unknown
Excerpt: "For Zoom, it's two to three people; Slack, it's five to 10 people... For Tinder, they found they needed 500 people on a college campus... For Uber, you'd need 300 drivers [per area]."
Context: The principle: start as small as your product will allow, then replicate the atomic network pattern.
Confidence: High

### 6.3 Timeline Expectations

**Claim: Most platforms take 2-5 years to reach critical mass; OpenTable took 7 years; Facebook took 4 years to profitability.**
Source: Softwareseni
URL: https://www.softwareseni.com/the-platform-trap-why-most-platforms-fail-before-reaching-critical-mass-and-how-to-overcome-the-cold-start-problem/
Date: 2025-10-27
Excerpt: "Timeline expectation: two to five years for most platforms. Some take longer... In well-chosen wedges, 4-12 weeks is common; in complex B2B or regulated contexts, 3-6 months."
Context: Winner-take-all markets move faster. Capital availability affects speed but doesn't guarantee success.
Confidence: Medium

---

## 7. Uber's Reinforcement Strategy: 9 Defense Mechanisms

Because Uber's core network effects are weak (asymptotic, local, low switching costs), the company built 9 additional defensibility layers:

**Claim: Uber pursued 9 additional defensibility "nodes" to reinforce its weak core network effect: Brand, Scale, Embedding, Language Network Effects, Uber Freight (2-sided marketplace), Uber Eats (3-sided marketplace), Data Network Effects, Tech Performance (autonomous vehicles), and Personal Utility (Uber Commute).**
Source: NFX
URL: https://www.nfx.com/post/the-network-effects-map-nfx-case-study-uber
Date: 2022-04-27
Excerpt: "At this point, we count no less than 9 additional defensibilities Uber is pursuing to reinforce their core network effect... each new product adds nodes to our network and strengthens shared capabilities."
Context: For a new premium driver platform, this model suggests that CRM lock-in, subscription retention, B2B2C embedding, and brand trust may be more important than raw network density.
Confidence: High

---

## 8. Key Evidence Summary Table

| Finding | Source Type | Confidence |
|---------|------------|------------|
| Uber supply-side-first launch strategy | Primary (founder accounts, exec interviews) | High |
| 20-30 drivers = critical mass threshold | Primary (Uber exec Scott Gorlick) | High |
| Atomic networks are hyperlocal, not city-wide | Primary (Andrew Chen book) | High |
| Network effects are asymptotic ~4-min ceiling | Analysis (NFX, Cornell) | High |
| Multi-homing costs ~$33/day in Jakarta duopoly | Academic (MIT paper) | High |
| Subscription models emerging globally (Ola, BarleyRide) | Industry news | High |
| SaaS-enabled marketplace precedents (OpenTable, StyleSeat) | VC analysis (Point Nine, a16z) | High |
| Driver referral program achieved 12:1 LTV:CAC | Analysis (Viral Loops) | Medium |
| Uber Pro gamification increases retention | Primary (eduMe/Uber) | High |
| Data portability threatens lock-in economics | Academic (CESifo) | High |
| Premium chauffeur network effects are weaker | Synthesis | Medium |
| 2-5 year timeline to critical mass typical | Analysis (multiple) | Medium |

---

## 9. Controversies and Conflicting Claims

### 9.1 Supply-Side First vs. Demand-Side First
The conventional wisdom from Uber, Airbnb, and Sharetribe is "build supply first." However, some argue for demand-first approaches in specific contexts. MVP Workshop argues: "Focus on demand instead. If you have a strong demand side you will be able to get more and more people on the supply side as well." [^465^]. The truth likely depends on which side has higher switching costs and price sensitivity.

### 9.2 How Strong Are Uber's Network Effects Really?
NFX describes Uber's network effects as "deceptively weak" and "asymptotic" [^512^]. Jeff Towson argues they "mostly local" and "flatline very, very quickly" [^507^]. Cornell's analysis notes they are "weaker than the true two-sided network effect" [^506^]. However, Uber's own S-1 states "the foundation of our platform is our massive network." The discrepancy may reflect that network effects are sufficient for defensibility when combined with the 9 reinforcement layers, but insufficient alone.

### 9.3 Subscription vs. Commission Models
The industry is actively experimenting with zero-commission subscription models (Ola, Rapido, Namma Yatri, BarleyRide). ONDC claims this can increase driver incomes by 30% [^548^]. However, long-term sustainability depends on whether subscription revenue alone can support platform operations, marketing, and technology development at scale.

### 9.4 Can Premium/Chauffeur Services Build Strong Network Effects?
Mass ride-hailing benefits from density (faster pickups). Premium chauffeur services are relationship-based with advance booking. The network effect is inherently weaker because matching doesn't need to happen in real-time. This suggests that a premium platform must rely more on CRM lock-in, switching costs, brand trust, and SaaS tools than on network density for defensibility.

---

## 10. Trends and Signals

1. **Shift to subscription models**: Multiple platforms globally (Ola, Rapido, Namma Yatri, BarleyRide) moving from commission to flat subscription fees for drivers
2. **SaaS-enabled marketplace hybrid**: Vertical SaaS + marketplace models gaining favor over pure marketplaces, especially in B2B services
3. **Data portability regulation**: GDPR Article 20 and emerging gig worker protections threaten platform lock-in economics
4. **B2B2C embedding**: Uber integrating into Expedia, corporate travel platforms, hotel apps -- creating distribution through existing workflows
5. **Atomic network precision**: Increasing recognition that networks should start at hyperlocal level (specific locations/times) rather than city-wide
6. **Driver loyalty programs**: Gamified tiered programs (Uber Pro, Lyft Rewards) becoming standard to combat multi-homing
7. **Zero-commission disruption**: New entrants in India and elsewhere using zero-commission + subscription to challenge incumbents

---

## 11. Recommended Deep-Dive Areas

1. **Driver CRM as lock-in mechanism**: What specific CRM features (favorite driver matching, earnings history, client relationship data, reputation portability) create the highest switching costs for professional drivers?

2. **Subscription model unit economics**: How do subscription-based driver fees compare to commission-based models for platform sustainability at various scales?

3. **Premium service network effects**: What is the minimum viable network size for a premium/chauffeur platform where matching is relationship-based rather than on-demand?

4. **B2B2C partnership playbook**: What are the specific integration requirements, revenue splits, and operational models for hotel/airport/corporate partnerships in ground transportation?

5. **Regulatory dynamics**: How will emerging data portability, gig worker classification, and commission-cap regulations affect marketplace dynamics?

6. **Vertical SaaS + marketplace hybrid**: What specific standalone tools (scheduling, invoicing, client CRM, earnings analytics) would most effectively bootstrap a premium driver marketplace?

---

## Source Index

| Citation | Source | Date |
|----------|--------|------|
| [^424^] | Alexander Jarvis - Uber doing things that don't scale | 2025-04-07 |
| [^425^] | Deciphr AI - Scott Gorlick Uber expansion playbook | Unknown |
| [^426^] | Mobile User Acquisition Show - Dan Riaz (ex-Lyft) | 2024-05-23 |
| [^427^] | Quartr - The Story of Uber | 2026-02-16 |
| [^428^] | Quora - Uber's process starting in new city | Unknown |
| [^429^] | The Growth Playbook - How Uber cracked chicken and egg | 2021-04-14 |
| [^431^] | Andrew Chen - Uber's virtuous cycle | 2014-07-11 |
| [^432^] | Medium/Point Nine - Come for network stay for tool | 2024-04-18 |
| [^433^] | Medium - How Uber solved cold start problem | 2025-10-12 |
| [^435^] | Softwareseni - Platform trap cold start | 2025-10-27 |
| [^436^] | MIT - Multi-homing and switching costs paper | 2024 |
| [^438^] | Tidemark Capital - Toast built to serve | Unknown |
| [^447^] | Growthpair - Uber driver network | Unknown |
| [^449^] | Breadcrumb VC - When networks meet SaaS | 2025-06-06 |
| [^452^] | eduMe - How Uber retains drivers | 2020-07-21 |
| [^455^] | Andrew Chen - The Cold Start Problem (book) | 2022 |
| [^456^] | Palle Substack - How Uber ensured global dominance | 2025-01-27 |
| [^457^] | The Rideshare Guy - Redesigned Uber Pro | 2026-03-04 |
| [^461^] | Journeyh.io - MVP two-sided marketplace | 2026-04-17 |
| [^462^] | Mobisoft - Ride-hailing revenue models | 2026-05-28 |
| [^466^] | Fast Company - Uber business travel | 2023-06-01 |
| [^499^] | Medium - Cold Start Problem summary | 2024-11-29 |
| [^500^] | Food on Demand - Andrew Chen cold start | 2022 |
| [^503^] | Calvin bookshelf - Cold Start Problem | 2022-02-28 |
| [^504^] | Sachin Rekhi - Cold Start Problem primer | 2025-12-10 |
| [^506^] | Cornell - Network effects rideshare | 2021-11-16 |
| [^507^] | Jeff Towson - Didi/Uber driver switching costs | 2024-10-21 |
| [^512^] | NFX - Network effects map Uber case study | 2022-04-27 |
| [^526^] | Viral Loops - Uber referral program case study | 2025-05-08 |
| [^530^] | Trybeans - Uber referral analysis | 2022-06-16 |
| [^547^] | BarleyRide - Subscription model | Unknown |
| [^548^] | Medial - Ola subscription zero commission | 2025-06-18 |
| [^550^] | Uber investor - Uber expands into travel | 2026-04-29 |
| [^552^] | Point Nine - SaaS enabled marketplace ecosystem | 2022-11-15 |
| [^554^] | Reddit - Subscription ride share discussion | 2025-07-16 |
| [^555^] | WiT - Uber expands into hotel bookings | 2026-04-30 |
| [^556^] | Uber blog - Seamless business travel | 2026-04-28 |
| [^557^] | CESifo - Lock-in effects online labor markets | 2024 |
| [^558^] | Policy Review - Data portability platforms | 2016-03-14 |
| [^559^] | Taxiwheel - Subscription taxi model | 2025-05-30 |

---

*Research compiled from 25+ independent searches across academic papers, industry reports, VC analyses, founder interviews, and platform documentation. All excerpts are verbatim with source attribution.*
