# Dimension 08 — Regulatory, Insurance & Compliance Landscape

## Executive Summary

The regulatory environment for independent chauffeur/driver platforms in the US is a complex patchwork of federal, state, and local requirements spanning driver licensing, vehicle standards, commercial insurance, worker classification, data privacy, and accessibility mandates. The landscape is undergoing significant changes in 2025-2026, most notably California's AB-1807 (raising commercial liability minimums to $2M) and SB-371 (reducing rideshare UM/UIM coverage). Platform business models that position themselves as SaaS tools rather than marketplaces may face different regulatory obligations, though the distinction remains legally untested in many jurisdictions.

---

## 1. Driver Licensing

### 1.1 Federal CDL Requirements (FMCSA)

Claim: The Federal Motor Carrier Safety Administration (FMCSA) sets baseline standards for Commercial Driver's Licenses (CDLs), but individual states issue the licenses. A CDL is required for vehicles with GVWR of 26,001+ pounds, vehicles towing 10,001+ pounds with GCWR of 26,001+, vehicles designed for 16+ passengers, or vehicles carrying hazardous materials. [^475^]
Source: FMCSA
URL: https://www.fmcsa.dot.gov/cdl
Date: Current (continuously updated)
Excerpt: "Most drivers must obtain a commercial driver's license (CDL) through their home State (it is illegal to have a license from more than one State). In addition, special endorsements may be required if you or your company drivers will be driving any of the following vehicles: a truck with double or triple trailers; a truck with a tank; a truck carrying hazardous materials; a passenger vehicle."
Context: Federal baseline that states must follow at minimum
Confidence: High

Claim: Effective June 23, 2025, medical examiners must electronically submit all CMV driver medical examination results directly to FMCSA through the National Registry of Certified Medical Examiners. Texas began implementation on March 23, 2025. [^479^]
Source: Texas Department of Public Safety
URL: https://www.dps.texas.gov/section/commercial-driver-license
Date: Current
Excerpt: "Effective June 23, 2025, Certified Medical Examiners (MEs) are required to electronically submit all CMV driver medical examination results directly to the FMCSA and State Driver's Licensing Agencies (SDLAs) through the National Registry of Certified Medical Examiners."
Context: Major regulatory change affecting all commercial drivers
Confidence: High

### 1.2 Chauffeur's License vs. Regular License

Claim: A chauffeur license is distinct from both a regular driver's license and a CDL. It applies to for-hire driving of smaller passenger vehicles (limousines, sedans, SUVs) typically carrying up to 14 passengers. A CDL is required only for vehicles carrying 16+ passengers. [^593^]
Source: Muse Limo
URL: https://www.muselimo.com/what-is-a-chauffeurs-license/
Date: December 16, 2025
Excerpt: "Many of you may confuse a chauffeur license with a Commercial Driver's License (CDL), but they are used for different types of driving. A CDL is needed to operate large commercial vehicles like trucks, buses, or tractor-trailers. A chauffeur license applies to drivers of smaller for-hire passenger vehicles, such as Sedans, limousines, or SUVs."
Context: Critical distinction for luxury/chauffeur service drivers
Confidence: High

Claim: States use different terms and requirements for chauffeur licensing. Michigan requires a separate chauffeur's license; Illinois requires a public passenger vehicle license; California only requires a CDL for larger vehicles; New York requires Class E or commercial license. [^595^]
Source: DRVN
URL: https://www.drvn.com/chauffeur/chauffeur-license-requirements
Date: March 3, 2025
Excerpt: "States like Michigan and Illinois require a separate chauffeur's license, while others, like California, only require a commercial driver's license (CDL) for larger vehicles... Many states require chauffeurs to be at least 18, while others, such as New York and Florida, set the minimum age at 21 for professional drivers."
Context: State-by-state variation creates compliance complexity
Confidence: High

### 1.3 TCP (Transportation Charter Permit) — California

Claim: The California Public Utilities Commission (CPUC) issues TCP permits for charter-party carriers. Requirements include: California business registration, commercial vehicle registration, commercial insurance policy, and drug/alcohol testing program. The application fee is $1,000+ and processing takes 2-4 weeks. [^471^]
Source: Business Rocket
URL: https://www.businessrocket.com/get/california-tcp-license-registration/
Date: Current
Excerpt: "When you apply for a TCP Permit, you have to meet some specific requirements outlined by CPUC. Firstly, your vehicle must have commercial use registration... Secondly, your business needs to be registered in California... Lastly, it is required to have a commercial insurance policy and a drug test on file to prioritize passenger safety."
Context: Critical for any chauffeur platform operating in California
Confidence: High

Claim: CPUC does NOT allow independent contractors to operate TCP-sanctioned vehicles unless that contractor has their own independent TCP license. All drivers must be classified as W-2 employees of the TCP license holder. [^471^]
Source: Business Rocket
URL: https://www.businessrocket.com/get/california-tcp-license-registration/
Date: Current
Excerpt: "CPUC does not allow for independent contract work regarding any vehicle listed in a TCP fleet, unless that independent contract has their own TCP License. This means that it is mandatory for an owner to classify anyone operating his or her vehicles as a driver for their business."
Context: This creates a major structural constraint for platform business models in CA
Confidence: High

Claim: AB-1807, effective July 1, 2025, raised California's minimum commercial auto liability from $750,000 to $2 million combined single limit per vehicle for charter-party carriers and TNCs. [^524^]
Source: Inszone Insurance
URL: https://inszoneinsurance.com/blog/california-limo-insurance-could-jump
Date: January 16, 2026
Excerpt: "Assembly Bill 1807 significantly raised the bar for commercial passenger carriers: New minimum liability: $2 million combined single limit per vehicle. Old requirement: $750,000 for sedans and small SUVs, $1 million for larger vans, $1.5 million for stretch limos."
Context: Massive cost increase for operators in California
Confidence: High

### 1.4 TLC (Taxi & Limousine Commission) — New York City

Claim: TLC driver license applicants must be at least 19, hold a valid NYS DMV Chauffeur license (Class A, B, C, or E), have a valid SSN, no more than 5 points on their DMV license within 15 months, and complete multiple steps within 90 days. [^535^]
Source: NYC TLC Official
URL: https://www.nyc.gov/site/tlc/drivers/get-a-tlc-drivers-license.page
Date: Current
Excerpt: "Minimum age: 19. Have a Valid DMV Chauffeur's license- Commercial Classes (A, B, C) or For-hire Class (E). You must have a valid Social Security Number. No fines or fees owed to NYS DMV or TLC. No more than 5 points on your DMV license within a 15 month period."
Context: One of the most rigorous licensing regimes in the US
Confidence: High

Claim: TLC applicants must complete: 24-hour TLC Driver Education Course, Wheelchair Accessible Vehicle (WAV) Training, pass an 80-question exam (70% passing), drug test, fingerprinting, medical exam, defensive driving course, and sex trafficking awareness training. Total cost ranges from approximately $500-$800. [^536^] [^539^]
Source: INSHUR / Dav El BostonCoach
URL: https://inshur.com/en-us/blog/in-depth-guide-to-tlc-license-nyc-2025
Date: December 9, 2024
Excerpt: "Complete the 24-Hour TLC Driver Education Course... Complete the Wheelchair Accessible Vehicle (WAV) course... Pass the TLC Driver License Exam (56 out of 80 questions correctly, equal to a 70% pass mark)."
Context: Comprehensive and expensive licensing process
Confidence: High

Claim: Effective October 1, 2025, all out-of-state TLC applicants must complete additional steps involving the ID-5 form and FS-6T receipt at a NYS DMV office. [^535^]
Source: NYC TLC Official
URL: https://www.nyc.gov/site/tlc/drivers/get-a-tlc-drivers-license.page
Date: Current
Excerpt: "Starting on October 1, 2025, all out-of-state Applicants/Licensees—whether applying for a new, renewal, or replacement TLC Driver's License—must complete a new step to allow the TLC to obtain the necessary Client ID number for their application."
Context: New barrier for out-of-state drivers seeking TLC licenses
Confidence: High

### 1.5 For-Hire Vehicle Permits — Major Cities

Claim: Chicago requires all public passenger vehicles to be licensed. Limousines face additional requirements under Chapter 9-114, with specific local insurance requirements: $350,000 CSL for 1-9 passenger livery vehicles. [^481^]
Source: Chicago Municipal Code
URL: https://codelibrary.amlegal.com/codes/chicago/latest/chicago_il/0-0-0-2648887
Date: Current
Excerpt: "It is unlawful for any person to operate a motor vehicle, or for the registered owner thereof to permit it to be operated, for the transportation of passengers for hire within the city unless it is licensed by the city as a public passenger vehicle pursuant to this chapter."
Context: Major city regulatory framework
Confidence: High

Claim: Miami-Dade County requires limousine for-hire license applications, background checks, vehicle standards meeting luxury sedan/SUV MSRP requirements, local business tax receipt, vehicle inspections, and chauffeur's license issued by Miami-Dade County. [^482^]
Source: Limo Anywhere / PortMiami Guide
URL: https://www.limoanywhere.com/2024/09/18/navigating-chauffeur-service-regulations-at-portmiami-a-comprehensive-guide/
Date: September 18, 2024
Excerpt: "Submit Application: Complete the Limousine For-Hire License Application. Background Checks: Undergo financial and criminal history checks. Vehicle Standards: Ensure your vehicles meet the county's definitions for luxury sedans or SUVs, including specifications like the Manufacturer's Suggested Retail Price (MSRP) and vehicle age."
Context: County-level regulation in major Florida market
Confidence: High

---

## 2. Vehicle Requirements

### 2.1 Vehicle Registration

Claim: TCP-licensed vehicles in California must have commercial use registration, which signifies to the DMV that the vehicle is used for business purposes regardless of who the registered owner is. [^471^]
Source: Business Rocket
URL: https://www.businessrocket.com/get/california-tcp-license-registration/
Date: Current
Excerpt: "Commercial registration classifies a vehicle to be used primarily for business purposes. This classification signifies to the DMV that this vehicle will no longer be considered for personal use, but instead for commercial use, regardless of who the registered owner of the vehicle is."
Context: Standard requirement across most jurisdictions
Confidence: High

### 2.2 Vehicle Age and Condition Standards

Claim: Uber requires vehicles to be 15 years old or newer, with 4 doors, seating for at least 5, air conditioning, and good condition. Lyft typically has similar requirements but varies by location. [^583^] [^587^]
Source: Uber / Lyft Help
URL: https://help.uber.com/en/driving-and-delivering/article/vehicle-requirements
Date: Current
Excerpt: "Vehicle age: Must be 15 years old or newer... Must have 4 doors and seating for at least 5 individuals... Equipped with air conditioning."
Context: Platform-level requirements that may be stricter than state requirements
Confidence: High

Claim: Starting January 1, 2026, vehicle age requirements will be changing in select regions for Lyft. [^589^]
Source: Lyft Help
URL: https://help.lyft.com/hc/en-us/sections/115003494688-State-and-city-requirements
Date: January 31, 2024
Excerpt: "Starting January 1, 2026, vehicle age requirements will be changing in select regions to comply with Lyft and local regulations."
Context: Potential tightening of vehicle age standards
Confidence: High

### 2.3 Inspection Requirements

Claim: Illinois requires annual safety inspections for commercial vehicles with GVWR over 8,000 pounds, including limousines. Inspections cover brakes, tires, lights, steering, suspension, and emissions. [^565^]
Source: Illinois Vehicle Safety Requirements
URL: https://844seemike.com/blog/illinois-vehicle-safety-inspection-requirements/
Date: September 25, 2025
Excerpt: "Commercial vehicles with a GVWR of more than 8,000 pounds must undergo a yearly safety inspection. Inspections include checks on brakes, tires, lights, steering components, suspension systems, and exhaust emissions."
Context: State-level inspection requirements vary significantly
Confidence: High

Claim: TLC requires all for-hire vehicles to pass inspection before license activation. Inspections include interior, exterior, safety equipment, and emissions testing. [^478^]
Source: NYC TLC
URL: https://www.nyc.gov/site/tlc/vehicles/get-a-for-hire-vehicle-license.page
Date: Current
Excerpt: "TLC will email and post on TLC UP your vehicle inspection appointment date. Visit Vehicle Inspections webpage for the For-Hire Vehicle inspection requirements. Bring your vehicle to your scheduled inspection appointment. Once the vehicle passes inspection, your vehicle license will be activated within 48 hours."
Context: Mandatory inspection for all FHV operations in NYC
Confidence: High

### 2.4 Insurance Minimums

Claim: Commercial auto insurance minimums vary dramatically by state. Key examples: Virginia requires $125,000 for 1-7 passenger vehicles; Connecticut requires $1.5M for 1-14 passengers; Michigan requires $1M CSL for 1-9 passengers. [^520^] [^525^]
Source: ABP Insurance / Business.com
URL: https://www.abpinsurance.com/commercial-insurance-virginia/limousine-livery / https://www.business.com/insurance/commercial-auto-state/
Date: Current
Excerpt (Virginia): "Virginia mandates that livery operators maintain combined single limit liability coverage that scales with passenger capacity. Vehicles seating seven or fewer passengers must carry a minimum of $125,000 in liability coverage."
Excerpt (Connecticut): "If you operate passenger-carrying vehicles in the state, your minimum insurance requirements are $1.5 million for vehicles carrying more than eight passengers."
Context: Insurance minimums are jurisdiction-specific and complex
Confidence: High

---

## 3. Insurance Landscape

### 3.1 Commercial Auto Insurance Costs

Claim: Commercial limo insurance costs an average of $904/month ($10,847 annually) for $1 million CSL on sedan and SUV operations. Vermont operators pay $581/month; New York TLC services pay $1,403/month. Stretch limos add 25-40% to base rates; party buses add 40-75%. [^488^]
Source: MoneyGeek
URL: https://www.moneygeek.com/insurance/business/commercial-auto/limo/
Date: November 2025
Excerpt: "Commercial limo insurance costs $904/month ($10,847 annually) for $1 million CSL on sedan and SUV operations. Vermont operators pay $581/month; New York TLC services pay $1,403/month. Stretch limos add 25% to 40% to base rates; party buses add 40% to 75% due to federal DOT requirements and higher injury exposure."
Context: Key cost data for business planning
Confidence: High

Claim: California's AB-1807 raised minimums to $2M CSL effective July 1, 2025, driving premium increases of 20-50% for many operators. Workers' compensation applies even to contractors if they're dispatched or scheduled. [^524^]
Source: Inszone Insurance
URL: https://inszoneinsurance.com/blog/california-limo-insurance-could-jump
Date: January 16, 2026
Excerpt: "Small limo fleets (1-10 vehicles): Owners now pay multiples of their previous liability premiums... Black-car and executive drivers: Independent drivers using SUVs or sedans once insured under personal policies now need full commercial coverage."
Context: Significant cost pressure on California operators
Confidence: High

### 3.2 Rideshare Insurance Gap Coverage

Claim: Uber and Lyft maintain contingent liability coverage during "Period 1" (app on, waiting for ride): $50K/person bodily injury, $100K/accident bodily injury, $25K property damage. During Periods 2 & 3 (en route/on trip): $1M third-party liability. TLC, livery, and TCP drivers must carry their own commercial insurance. [^495^]
Source: Lyft Help
URL: https://help.lyft.com/hc/en-us/all/articles/115013080548
Date: January 31, 2024
Excerpt: "Lyft does not procure insurance for rides with (i) Taxi and Limousine Commission (TLC) drivers originating in the five boroughs of New York City... and (ii) livery and/or Transportation Charter Permit (TCP) drivers countrywide. TLC, livery, and TCP drivers procure their own policies consistent with state and local requirements."
Context: Platform insurance does not cover professionally licensed drivers
Confidence: High

Claim: New York State requires higher coverage: $75K/$150K/$25K during waiting period; $1.25M during active rides for TNCs. The $1.25M requirement is significantly higher than the $1M standard in most other states. [^485^] [^486^]
Source: Uber / 1800Law1010
URL: https://www.uber.com/us/en/u/fair-insurance/ / https://www.1800law1010.com/blog/rideshare-insurance-in-new-york/
Date: June 4, 2026 / January 20, 2026
Excerpt: "New York State (excluding New York City) has an uninsured motorist/underinsured motorist (UM/UIM) requirement for personal car owners, but at $50,000 per incident that requirement is 25 times lower than the $1.25 million requirement for TNCs in New York when a passenger is in the vehicle."
Context: Among the highest requirements nationally
Confidence: High

### 3.3 Platform-Provided Insurance Models

Claim: Uber maintains commercial auto insurance on behalf of drivers when they're active on the platform. This includes: third-party liability, uninsured/underinsured motorist coverage (where required), and contingent comprehensive/collision. Drivers must maintain personal auto insurance at mandatory minimum limits. [^489^]
Source: Uber
URL: https://www.uber.com/us/en/drive/insurance/
Date: Current
Excerpt: "Uber maintains commercial auto insurance on your behalf for ridesharing and delivery activities when you're driving on our platform. When you're not driving with Uber, you maintain your own personal auto insurance."
Context: The industry-standard three-period insurance model
Confidence: High

Claim: Over half of all rideshare drivers do not carry rideshare insurance despite the coverage gap, according to Gridwise market study. [^492^]
Source: AutoInsurance.com
URL: https://www.autoinsurance.com/best/rideshare/
Date: January 7, 2026
Excerpt: "According to a market study by the rideshare assistant app Gridwise, over half of all rideshare drivers do not carry rideshare insurance."
Context: Significant uninsured risk in the market
Confidence: Medium (secondary reporting)

### 3.4 2025-2026 Insurance Legislative Changes

Claim: California SB 371, effective January 1, 2026, reduced TNC uninsured/underinsured motorist coverage from $1M per incident to $60K per person / $300K per accident. Third-party liability when driver is at fault remains at $1M. The bill was part of a compromise with AB 1340 granting drivers union rights. [^513^] [^515^]
Source: Uber Newsroom / Chain Law
URL: https://www.uber.com/us/en/newsroom/california-insurance-reform/ / https://www.chainlaw.com/rideshare-insurance-reform-ca/
Date: June 3, 2026 / March 5, 2026
Excerpt: "Starting January 1, 2026, every Uber passenger trip in CA will be covered by: UM/UIM Coverage ($60,000 per individual and $300,000 per accident)... $1 million in liability insurance to cover injuries or property damage in accidents caused by the rideshare driver."
Context: Major change — California riders had been paying among highest insurance costs
Confidence: High

Claim: Consumer Attorneys of California is promoting a counter-ballot measure for November 2026 to reverse SB 371's insurance reductions and add additional consumer safeguards. [^516^]
Source: Attorney Jeff
URL: https://attorneyjeff.com/uber-new-law-in-california/
Date: February 21, 2026
Excerpt: "The Consumer Attorneys of California is currently leading a coalition promoting counter-ballot measures for November 2026, which would include: Additional consumer safeguards that prioritize victims' safety; Ending inflated medical billing by limiting attorney fee structures."
Context: Ongoing political battle over insurance levels
Confidence: High

Claim: Uber's internal data (December 2025) shows insurance costs as percentage of rideshare fares: Texas 15%, Massachusetts 20%+, New York state 25%+, New Jersey 25%+. California and Nevada are expected to see costs fall as reforms are phased in. [^485^]
Source: Uber
URL: https://www.uber.com/us/en/u/fair-insurance/
Date: June 4, 2026
Excerpt: "New Jersey and New York have surged to the top of the rankings, with costs fueled by high UM/UIM requirements, litigation abuse, staged accidents, and runaway verdicts. States like California and Nevada are expected to see costs fall over the coming months as reforms passed in 2025 are phased in."
Context: Data-driven view of insurance cost distribution
Confidence: High

---

## 4. Driver Classification

### 4.1 Independent Contractor vs. Employee — Federal

Claim: The DOL's 2024 independent contractor final rule (Biden-era), which used a six-factor "economic realities" test giving no factor predetermined weight, is no longer being enforced as of May 2025. DOL field staff are instructed to use the prior Fact Sheet #13 framework. The 2024 rule remains in effect for purposes of private litigation. [^566^] [^567^]
Source: Jackson Lewis / Venable
URL: https://www.jacksonlewis.com/insights/businesses-get-break-dol-wont-enforce-2024-independent-contractor-rule
Date: July 3, 2025
Excerpt: "The US Department of Labor (DOL) will no longer apply the 2024 independent contractor final rule when analyzing whether a worker is an employee or independent contractor... The 2024 final rule remains in effect 'for purposes of private litigation' relating to independent contractor status under the FLSA."
Context: Significant federal policy reversal
Confidence: High

Claim: The FTC issued a policy statement on January 14, 2025 clarifying that independent contractors and gig workers are shielded from antitrust liability when engaging in collective bargaining and organizing activities under the Clayton and Norris-LaGuardia Acts. [^545^]
Source: FTC
URL: https://www.ftc.gov/news-events/news/press-releases/2025/01/ftc-issues-policy-statement-clarifying-independent-contractors-gig-workers-organizing-activities-are
Date: January 14, 2025
Excerpt: "The Federal Trade Commission today issued a policy statement clarifying that independent contractors, including gig workers, are shielded from antitrust liability when engaging in protected bargaining and organizing activities... 'Gig workers shouldn't be forced to accept low wages or poor working conditions just because they're independent contractors.'"
Context: Important development for driver organizing rights
Confidence: High

### 4.2 AB5 and Proposition 22 — California

Claim: AB 5 (2019) codified the "ABC test" requiring all three conditions for independent contractor status: (A) free from control, (B) work outside usual course of business, (C) customarily engaged in independent trade. Proposition 22 (2020) created an exemption for app-based drivers, allowing independent contractor classification with certain benefits. [^490^] [^497^]
Source: Labor Law PC / SPUR
URL: https://www.laborlawpc.com/blog/changes-to-independent-contractor-classification-in-california-for-2024/
Date: August 27, 2024
Excerpt: "AB 5 (Assembly Bill 5), which was enacted in 2019 and codified the 'ABC test' for determining whether a worker is an employee or an independent contractor. The ABC test presumes that all workers are employees unless the hiring entity can demonstrate that the worker meets all three conditions."
Context: The foundational legal framework for California gig work
Confidence: High

Claim: On July 25, 2024, the California Supreme Court unanimously upheld Proposition 22 in Castellanos v. State of California, rejecting union challenges that the law violated the state constitution by infringing on workers' compensation authority. [^557^] [^562^]
Source: FedSoc / CalMatters
URL: https://fedsoc.org/scdw/california-supreme-court-upholds-prop-22 / https://calmatters.org/economy/2024/07/prop-22-california-gig-work-law-upheld/
Date: January 8, 2026 / July 26, 2024
Excerpt: "In a major victory for gig-work companies, the California Supreme Court today upheld a voter-approved law that allows Uber and other app makers to treat their drivers and delivery workers as independent contractors instead of employees. The decision on Proposition 22 was unanimous."
Context: Major legal certainty for platform business models
Confidence: High

Claim: Under Prop 22, drivers receive: minimum earnings guarantee of 120% of minimum wage (based on "engaged time" only), healthcare stipends for certain eligible workers, occupational accident insurance with $1M limit, and 35 cents/mile reimbursement. They do NOT receive: sick pay, minimum wage for waiting time, unemployment insurance, or workers' comp. [^562^]
Source: CalMatters
URL: https://calmatters.org/economy/2024/07/prop-22-california-gig-work-law-upheld/
Date: July 26, 2024
Excerpt: "Under Prop. 22, gig workers are promised guaranteed minimum earnings of 120% of minimum wage, health care stipends, occupational accident insurance and accidental death insurance... Because Prop. 22 will stand, app-based platform workers will continue to be ineligible for benefits such as sick pay, a minimum wage for all time worked, unemployment insurance and more."
Context: Key trade-offs of the Prop 22 model
Confidence: High

### 4.3 State "Marketplace Contractor" Laws

Claim: Multiple states have passed laws defining app-based platform workers as independent contractors: Iowa (2018), Kentucky (2018), Tennessee (2018), Utah (2015), Texas (2019), South Dakota (2022). These laws typically require that platforms do not prescribe specific hours, prohibit use of other platforms, or restrict other work. [^537^] [^543^]
Source: NELP / EPI
URL: https://www.nelp.org/insights-research/marketplace-platforms-employers-state-law/ / https://www.epi.org/publication/state-misclassification-of-workers/
Date: April 9, 2024 / December 15, 2021
Excerpt (NELP): "Alaska: A transportation network company driver is an independent contractor... if the transportation network company does not unilaterally prescribe specific hours... does not impose restrictions on the ability of the driver to use the digital network of other transportation network companies..."
Context: Growing state-level codification of IC status
Confidence: High

### 4.4 Platform Structure and Classification

Claim: Under Texas Administrative Code, marketplace contractors are independent contractors if: paid per-job, platform doesn't prescribe hours, worker not prohibited from using other platforms, worker not restricted from other occupations, platform doesn't control when/where work occurs, worker responsible for expenses and tools, platform doesn't give specific instructions, and worker not required to attend mandatory meetings. [^540^]
Source: Kuiper Law Firm
URL: https://kuiperlawfirm.com/state-law-update-classification-of-marketplace-contractors/
Date: September 9, 2024
Excerpt: "The Texas Workforce Commission collects unemployment taxes from Texas employers, and the Texas Administrative Code specifically excepts marketplace contractors from the definition of employment for purposes of unemployment insurance."
Context: Template for structuring platform-driver relationships
Confidence: High

Claim: The "SaaS tool vs. marketplace" distinction has not been fully tested in courts for driver classification. However, the degree of control, integration of services, and economic dependence are key factors that courts examine. A platform that primarily provides scheduling and payment tools without controlling rates, routes, or dispatch may have stronger IC classification arguments. [^544^]
Source: Goldberg Segalla
URL: https://www.goldbergsegalla.com/news-and-knowledge/news/department-of-labor-workers-in-virtual-marketplace-companies-are-independent-contractors/
Date: March 31, 2023
Excerpt: "The Department of Labor considered six factors in reaching its conclusion that virtual marketplace company workers are independent contractors: 1. The nature and degree of the potential employer's control; 2. The permanency of the worker's relationship; 3. The amount of the worker's investment in facilities and/or equipment; 4. The amount of skill, initiative, judgment, or foresight required; 5. The worker's opportunities for profit or loss; 6. The extent of integration of the worker's services into the potential employer's services."
Context: Framework for platform design decisions
Confidence: High

---

## 5. Data Privacy

### 5.1 CCPA/CPRA for Driver and Rider Data

Claim: The California Privacy Protection Agency (CPPA) initiated its first-ever enforcement review of connected vehicle manufacturers in July 2023, examining how companies collect and use driver, passenger, and even bystander data. Rideshare services must identify all third parties who receive user personal information and ensure adequate opt-out mechanisms. [^494^]
Source: Akin Gump
URL: https://www.akingump.com/en/insights/blogs/ag-data-dive/cppa-takes-aim-at-connected-cars-in-first-ever-review
Date: August 23, 2023
Excerpt: "On July 31, 2023, the California Privacy Protection Agency (CPPA) announced an enforcement review of the data privacy practices of connected vehicle (CV) manufacturers and technologies... Modern vehicles are effectively connected computers on wheels...able to collect a wealth of information via built-in apps, sensors, and cameras."
Context: Active regulatory scrutiny of transportation data practices
Confidence: High

Claim: Under CCPA/CPRA, rideshare services that provide passenger data to third parties for targeted advertising are engaged in "sharing" under CPRA. Services must ensure adequate notice in privacy policies about sharing of sensitive personal information including geolocation data. [^484^]
Source: Norton Rose Fulbright
URL: https://www.nortonrosefulbright.com/-/media/files/nrf/nrfweb/knowledge-pdfs/privacy-implications-of-autonomous-vehicles.pdf
Date: Current
Excerpt: "An AV rental services that provides passenger data to a third-party targeting ads to the passenger, is an example of sharing under CPRA. Whenever a rental or ride sharing service provides information to third parties that reaches conclusions about users, including those based on locations traveled to, music listened to, how fast they drive, etc., they must ensure they comply with the notice and opt out requirements."
Context: CPRA expands obligations beyond CCPA
Confidence: High

### 5.2 GDPR

Claim: In August 2024, Dutch DPA imposed a EUR 290 million fine on Uber for improperly transferring European driver data to the US between August 2021 and November 2023 without proper safeguards, including account details, taxi licenses, location data, photos, payment details, identity documents, and criminal or medical records. [^598^]
Source: ComplexDiscovery
URL: https://complexdiscovery.com/uber-faces-e290-million-fine-for-gdpr-violation-in-data-transfer-to-us/
Date: August 27, 2024
Excerpt: "The findings revealed that from August 2021 to November 2023, Uber transferred sensitive information, including account details, taxi licenses, location data, photos, payment details, identity documents, and criminal or medical records, to servers in the United States without employing proper safeguards."
Context: Major GDPR enforcement with implications for all platforms handling EU driver data
Confidence: High

### 5.3 PCI DSS for Payment Processing

Claim: PCI DSS applies to any merchant or service provider that stores, processes, or transmits cardholder data, including SaaS providers whose applications handle cardholder data. Requirements include: network security controls, secure configurations, protecting stored account data, encrypting cardholder data in transit, malware protection, secure systems development, access restriction, user authentication, physical access restriction, logging/monitoring, regular security testing, and information security policy. [^541^]
Source: Scale Computing
URL: https://www.scalecomputing.com/blog/what-is-pci-compliance-an-essential-guide-to-understanding-pci-dss-requirements
Date: October 23, 2025
Excerpt: "Merchants and service providers who transmit, process, or store cardholder data must comply with PCI DSS, regardless of their size or transaction volume. This includes... SaaS providers whose applications handle cardholder data (even if payments are embedded via integrations)."
Context: Payment processing compliance is mandatory for any platform handling payments
Confidence: High

---

## 6. Accessibility Requirements

### 6.1 ADA Compliance for Transportation Services

Claim: The ADA does NOT require taxi companies or TNCs to provide wheelchair accessible vehicles except in limited circumstances. Taxis fall under Title III (private accommodations), where WAVs are not required. However, NYC taxis are unique — they fall under Title II (public entities) due to TLC's significant control, requiring accessibility. [^517^]
Source: National Council on Disability
URL: https://unitedspinal.org/pdf_advocacy/NCD-ground-transportation-2025.pdf
Date: 2025
Excerpt: "At the federal level, the ADA and its implementing transportation regulations do not mandate taxi companies or TNCs to provide a percentage of WAVs. This has resulted in a lack of WAVs except in a few jurisdictions where state and local laws require them... It is important to note that NYC's taxis are unique...NYC's taxi services are operated by the TLC within the meaning of Title II of the ADA."
Context: Major finding — federal ADA does not mandate WAV for most private ride services
Confidence: High

Claim: Any transit agency that contracts with a TNC to provide public transit must ensure the TNC abides by the same Title II ADA obligations, including providing WAVs. Contractors "stand in the shoes" of the public entity. [^517^]
Source: National Council on Disability
URL: https://unitedspinal.org/pdf_advocacy/NCD-ground-transportation-2025.pdf
Date: 2025
Excerpt: "Regardless of whether the ADA requires TNCs to provide WAVs, any transit agency that contracts with a TNC to provide public transit must ensure that the TNCs abide by the same Title II obligations to provide WAVs that apply to transit agencies."
Context: Important for platforms partnering with public transit agencies
Confidence: High

### 6.2 WAV Mandates — New York City

Claim: In August 2024, a federal court ordered TLC to ensure 50% of all active medallions are operated with WAVs by March 31, 2025, and 50% of all authorized medallions attached to WAVs by end of 2028. TLC promulgated rules adopted October 16, 2024 requiring all new taxi hack-ups to be WAVs. By June 2025, over 50% of active taxi fleet was wheelchair accessible, up from 213 WAVs in 2013. [^517^] [^571^]
Source: NCD / NYC TLC Press Release
URL: https://unitedspinal.org/pdf_advocacy/NCD-ground-transportation-2025.pdf
Date: 2025
Excerpt: "In August 2024, the judge ruled that the TLC's efforts weren't close to substantial performance with the agreement and ordered all new taxicabs to accommodate wheelchairs until the 50% mark was met... In February 2025, about 45% of the active medallions were accessible."
Context: Landmark accessibility achievement
Confidence: High

Claim: TLC's Green Rides Initiative requires 100% of high-volume for-hire service trips (Uber/Lyft) to be in zero-emission or wheelchair accessible vehicles by 2030, with benchmarks increasing from 5% in 2024 to 15% in 2025, 25% in 2026, 40% in 2027, 60% in 2028, 80% in 2029, and 100% in 2030. [^568^] [^569^]
Source: NYC TLC
URL: https://www.nyc.gov/site/tlc/about/green-rides.page
Date: Current
Excerpt: "Beginning in 2024, five percent of all high-volume (Uber & Lyft) trips will need to be through vehicles that are either zero-emission or wheelchair accessible. The benchmark will then rise to 15% in 2025 and 25% in 2026. In 2027 it will increase to 40%, then rise yearly by 20 percentage points until the end of the decade."
Context: Aggressive timeline for fleet transformation
Confidence: High

Claim: As of February 2025, there were 7,514 wheelchair accessible FHVs in NYC, and TLC only accepts new FHV license applications for wheelchair accessible vehicles. [^574^]
Source: NYC Council Hearing
URL: https://citymeetings.nyc/meetings/new-york-city-council/2025-03-19/
Date: March 19, 2025
Excerpt: "There's actually 7,514 FHV wheelchair accessible as of February 2025... The only way to get a TLC vehicle license right now is to put on the road a wheelchair accessible FHV."
Context: New vehicle licenses restricted to WAVs only
Confidence: High

### 6.3 WAV Requirements — Federal Recommendations

Claim: The National Council on Disability recommends Congress pass legislation requiring all TNCs, taxi companies, and AV companies to provide and maintain an active percentage of WAVs in each community where they operate. As of November 2024, none of 42 state AV laws required TNCs to provide wheelchair-accessible AVs. [^517^]
Source: National Council on Disability
URL: https://unitedspinal.org/pdf_advocacy/NCD-ground-transportation-2025.pdf
Date: 2025
Excerpt: "Congress should pass legislation that requires all TNCs, taxi companies, and AV companies that deploy fleets of robotaxis to provide and maintain an active percentage of WAVs in each community where they operate... A review of these laws in November 2024 revealed that none of 42 state AV laws enacted as of November 2024 required TNCs to provide wheelchair-accessible AVs."
Context: Federal legislative recommendations, not yet binding law
Confidence: High

---

## 7. Driver Safety and Background Check Requirements

### 7.1 Uber Background Check Standards

Claim: Uber's screening process includes: identity verification (SSN validated with IRS), MVR check, and criminal background check through PBSA-accredited providers searching local, state, national, federal court, sex offender registry, and terrorist watchlist databases. Disqualifying offenses include sexual assault, sex crimes involving minors, murder, kidnapping, and terrorism (lifetime); felonies, robbery, fraud generally within 7 years. Uber re-runs checks annually and pioneered continuous monitoring in 2018. Since 2017, 3.5 million people were prevented from joining or remaining on the platform. [^591^]
Source: Uber Newsroom
URL: https://www.uber.com/us/en/newsroom/background-checks/
Date: December 21, 2025
Excerpt: "Since 2017, this approach has prevented 3.5 million people from joining or remaining on the platform, most before they ever completed a first trip... We reject applicants for a wide range of offenses, barring anyone convicted of the most serious crimes reported to us from any point in their lifetime."
Context: Industry-leading safety screening standards
Confidence: High

### 7.2 Emerging State Legislation

Claim: In Colorado, a February 2025 bill proposal would require fingerprint-based background checks every 6 months, biometric identity verification before each ride, continuous audio/video recording of all rides, 10-hour maximum shifts, and create private rights of action for violations. Uber stated the requirements are so onerous it would reconsider Colorado operations. [^596^] [^597^]
Source: CPR / TSS Colorado
URL: https://www.cpr.org/2025/02/28/ride-share-safety-security-requirements-bill/
Date: February 28, 2025 / March 3, 2025
Excerpt: "The bill would require that TNCs do criminal history checks on drivers before they begin to work with them and then at least once every six months afterward — and that the checks be fingerprint-based... Uber officials added that the specific requirements in the proposed bill are so onerous that the company would have to reconsider whether it would continue doing business in the state."
Context: Potential model for other states; industry strongly opposed
Confidence: High

---

## 8. Enforcement Actions and Penalties

Claim: The CPUC Transportation Enforcement Branch actively cites and fines operators. In a September 2025 citation, Uber was fined $20,000 for violations including failure to maintain required records of driver's personal insurance and failure to provide proper driver information disclosures to passengers. [^577^]
Source: CPUC
URL: https://www.cpuc.ca.gov/-/media/cpuc-website/divisions/consumer-protection-and-enforcement-division/documents/teb/safety-assurance/public-teb-citations/2025-citations/
Date: 2025
Excerpt: "Failure to maintain required records of driver's personal insurance, in violation of G.O. 157-E, Part 11.18 [1 count]; and Failure to provide the passenger with proper driver information disclosures, in violation of Pub. Util. Code Section 5445.1 [1 count]... Pay a fine of $20,000."
Context: Active enforcement with substantial penalties
Confidence: High

Claim: CCPA violations carry maximum fines of $7,500 per violation for intentional noncompliance and $2,500 for unintentional violations. Consumers have a private right of action for data breaches with statutory damages up to $750 per affected individual. [^487^]
Source: Kiteworks
URL: https://www.kiteworks.com/risk-compliance-glossary/ccpa/
Date: July 31, 2025
Excerpt: "Intentional noncompliance—such as purposefully ignoring CCPA mandates—carries maximum fines of $7,500 per violation. Unintentional violations, including failures to encrypt breached data, result in fines of $2,500 per violation."
Context: Significant financial exposure for non-compliance
Confidence: High

---

## 9. Key Trends and Signals

1. **Insurance Cost Escalation**: Commercial auto liability minimums are rising (CA AB-1807 to $2M), while rideshare-specific coverage is being reduced in some areas (CA SB-371). This creates divergent cost pressures for different platform models.

2. **Worker Classification Stabilizing**: With Prop 22 upheld and the DOL retreating from the 2024 IC rule, the political momentum has shifted toward accepting IC status for gig drivers with carve-out benefits rather than full employee classification.

3. **Accessibility Mandates Expanding**: NYC's 50% WAV taxi requirement and Green Rides Initiative represent the most aggressive accessibility requirements nationally. Other jurisdictions may follow.

4. **Safety Regulation Intensifying**: Colorado's proposed fingerprint checks, biometric verification, and mandatory ride recording signal a new wave of safety-focused TNC regulation.

5. **Data Privacy Scrutiny**: The EUR 290M Uber GDPR fine and CPPA connected vehicle review demonstrate that transportation platforms face intense data privacy oversight.

6. **SaaS vs. Marketplace Legal Distinction**: The regulatory framework increasingly distinguishes between platforms that "prescribe hours" or "control work" vs. those that provide referral/marketplace services. A pure SaaS scheduling tool model may face fewer classification obligations.

---

## 10. Controversies and Conflicting Claims

### Controversy 1: Insurance Adequacy
- **Industry position (Uber/Lyft)**: California's $1M UM/UIM requirement was excessive compared to taxis, buses, and personal vehicles, driving up costs for riders. [^513^]
- **Consumer advocate position**: SB 371 transfers financial risk from billion-dollar corporations to vulnerable passengers, especially with California's high uninsured driver rate (1 in 8). [^516^]

### Controversy 2: Worker Classification
- **Platform position**: IC status provides flexibility that drivers overwhelmingly prefer; 80% work part-time. Employee classification would increase costs 20-30% and reduce service availability. [^497^]
- **Labor advocate position**: Prop 22 creates a substandard "third category" of worker that denies basic protections like unemployment insurance, sick pay, and workers' comp. [^562^]

### Controversy 3: Safety vs. Privacy
- **Legislator position (Colorado)**: Fingerprint checks, biometric verification, and mandatory recording are necessary to prevent assaults and imposter drivers. [^596^]
- **Industry position**: Fingerprint-based checks are unreliable, incomplete, and discriminatory; the proposed requirements are so onerous they would force market exit. [^597^]

---

## 11. Critical Implications for Independent Chauffeur Platforms

### For a SaaS-Tool/Booking Platform Model:
1. **Licensing**: The platform itself may not need TCP/TLC licensing if it does not dispatch or control rides — but drivers likely still do.
2. **Insurance**: If drivers are independent operators setting their own rates and carrying their own commercial insurance, platform-provided insurance may not be necessary. However, gap coverage considerations may still apply.
3. **Classification**: A genuine SaaS tool that does not control pricing, routes, or hours and does not restrict drivers to the platform has stronger IC classification arguments under the DOL's Fact Sheet #13 and state marketplace contractor laws.
4. **Data**: PCI DSS compliance for payment processing is mandatory. CCPA applies if the platform handles California consumer data. GDPR applies if any EU drivers or passengers are served.
5. **Accessibility**: Unless contracting with public transit agencies or operating in NYC, federal ADA likely does not mandate WAV provision. However, state/local laws may.

### Recommended Deep-Dive Areas:
1. **SaaS platform legal liability**: Whether a pure SaaS scheduling/booking tool that does not dispatch rides creates any direct regulatory obligations beyond data privacy and PCI DSS.
2. **State-by-state licensing matrix**: Detailed mapping of chauffeur licensing, vehicle registration, and insurance requirements across top 20 US markets.
3. **Insurance product innovation**: Emerging rideshare endorsement products and whether new insurance products can be designed specifically for independent chauffeur platforms.
4. **AB5 safe harbor design**: Specific contractual and operational structures that strengthen IC classification arguments in California and ABC-test jurisdictions.
5. **Accessibility partnerships**: Strategies for meeting WAV demand without direct fleet ownership, including partnerships with existing accessible transportation providers.

---

## Sources Index

| Citation | Source | Type |
|----------|--------|------|
| [^471^] | Business Rocket - TCP License | Industry Service |
| [^475^] | FMCSA - CDL Program | Government |
| [^478^] | NYC TLC - FHV License | Government |
| [^479^] | Texas DPS - CDL | Government |
| [^481^] | Chicago Municipal Code | Government |
| [^482^] | Limo Anywhere - PortMiami | Industry |
| [^484^] | Norton Rose Fulbright - CCPA | Law Firm |
| [^485^] | Uber - Insurance Requirements | Company |
| [^487^] | Kiteworks - CCPA | Industry |
| [^488^] | MoneyGeek - Limo Insurance | Financial Media |
| [^490^] | Labor Law PC - AB5 | Law Firm |
| [^492^] | AutoInsurance.com - Rideshare | Financial Media |
| [^494^] | Akin Gump - CPPA | Law Firm |
| [^495^] | Lyft Help - Insurance | Company |
| [^497^] | SPUR - Prop 22 | Non-Profit |
| [^513^] | Uber Newsroom - CA Reform | Company |
| [^515^] | Chain Law - CA Rideshare | Law Firm |
| [^516^] | Attorney Jeff - CA Law | Law Firm |
| [^517^] | NCD - Ground Transportation | Government Advisory |
| [^520^] | ABP Insurance - Virginia | Insurance Agency |
| [^524^] | Inszone - CA Limo Insurance | Insurance Agency |
| [^525^] | Business.com - Commercial Auto | Business Media |
| [^535^] | NYC TLC - Driver License | Government |
| [^536^] | INSHUR - TLC Guide | Industry Service |
| [^537^] | NELP - Marketplace Platforms | Non-Profit |
| [^540^] | Kuiper Law - Marketplace Contractors | Law Firm |
| [^541^] | Scale Computing - PCI DSS | Industry |
| [^543^] | EPI - Marketplace Laws | Non-Profit |
| [^544^] | Goldberg Segalla - DOL | Law Firm |
| [^545^] | FTC - Policy Statement | Government |
| [^557^] | FedSoc - Prop 22 | Legal Organization |
| [^560^] | Amundsen Davis - Prop 22 | Law Firm |
| [^562^] | CalMatters - Prop 22 | News |
| [^564^] | Mega Insurance - FHV NYC | Insurance |
| [^565^] | Illinois Vehicle Safety | Legal Blog |
| [^566^] | Jackson Lewis - DOL Rule | Law Firm |
| [^568^] | NYC TLC - Green Rides | Government |
| [^569^] | NYC Rules - Green Rides | Government |
| [^571^] | NYC TLC Press Release | Government |
| [^574^] | NYC Council Hearing | Government |
| [^577^] | CPUC - Uber Citation | Government |
| [^578^] | Justice Counts - Uber/Lyft | Legal Blog |
| [^583^] | Uber Help - Vehicle Req | Company |
| [^585^] | Clearsurance - Limo Insurance | Financial Media |
| [^591^] | Uber Newsroom - Background | Company |
| [^593^] | Muse Limo - Chauffeur License | Industry |
| [^595^] | DRVN - Chauffeur Requirements | Industry |
| [^596^] | CPR - Colorado Bill | News |
| [^597^] | TSS Colorado - TNC Bill | News |
| [^598^] | ComplexDiscovery - Uber GDPR | Legal Media |

---

*Research completed: July 2025*
*Total independent searches performed: 20+*
*Sources reviewed: 50+*
