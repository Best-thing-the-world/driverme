# Dimension 02: Competitive Landscape & Platform Players — DriverLink

## Executive Summary

The global chauffeur services market is highly fragmented — the top 10 operators collectively account for only **22-25% of total global market revenue** [^103^], with the vast majority comprised of independent operators running small fleets (often 1-5 vehicles). The market was valued at **$52.4 billion in 2025** and is projected to reach **$98.7 billion by 2034** at a CAGR of 7.3% [^12^]. Despite this massive market, independent chauffeurs remain dramatically underserved by technology. There is **no dominant vertical SaaS platform purpose-built for independent chauffeurs** — creating a significant whitespace opportunity for DriverLink.

The competitive landscape spans four categories: (1) **direct competitors** — global chauffeur platforms that work with independent partners but are consumer-facing brands; (2) **indirect competitors** — rideshare premium tiers and traditional limo software; (3) **adjacent platforms** — vertical SaaS models in comparable industries that validate the business model; and (4) **differentiation opportunities** — unaddressed pain points where existing players fail independent drivers.

---

## 1. Direct Competitors: Global Chauffeur Platforms Serving Independent Partners

### 1.1 Blacklane (Being Acquired by Uber, March 2026)

**Claim: Blacklane operates in 500+ cities across 60+ countries and is being acquired by Uber for an undisclosed amount, expected to close by end of 2026.** [^11^] [^18^]

**Source:** Business Traveller / Uber Investor Relations
**URL:** https://www.businesstraveller.com/news/uber-to-acquire-blacklane/ / https://investor.uber.com/news-events/news/press-release-details/2026/Uber-to-Acquire-Global-Chauffeur-Service-Leader-Blacklane/default.aspx
**Date:** March 30, 2026
**Excerpt:** "Founded in Berlin, Germany, in 2011 to bring quality and consistency to travel, Blacklane connects guests worldwide with independent local chauffeur services via an app and web booking platform. Today Blacklane operates in over 500 cities across more than 60 countries." [^18^]
**Context:** The acquisition reinforces Uber's move into premium travel via its newly launched Uber Elite service. Blacklane will accelerate Uber Elite's expansion.
**Confidence:** High

**Key details for DriverLink strategy:**
- Blacklane's **partner model** is instructive: partners (chauffeur companies) get "complete schedule control," "reliable direct payment" (no commission, no fees — the price they see is what they get), access to large corporate clients, dedicated support, and training modules [^29^].
- Blacklane connects independent chauffeur companies with an international client base for airport transfers, city-to-city rides, on-demand pickups, and by-the-hour bookings.
- However, Blacklane partners are **chauffeur companies, not individual independent chauffeurs**. The minimum bar is owning/operating a registered chauffeur company.
- **Critical gap**: Blacklane does NOT provide independent chauffeurs with SaaS tools for their own business — it's a demand platform, not a business operating system.

### 1.2 Wheely (Expanded to NYC, March 2026)

**Claim: Wheely expanded to New York City in March 2026, its U.S. debut, with plans to expand to Texas, Washington D.C., Miami and Palm Beach over the next five years.** [^12^] [^25^]

**Source:** PYMNTS / Business Travel News
**URL:** https://www.pymnts.com/transportation/2026/wheely-expands-on-demand-chauffeur-service-to-new-york-city/
**Date:** March 23, 2026
**Excerpt:** "The London-headquartered on-demand chauffeur company already operates in London, Paris and Dubai... As a global hub of culture and business, New York City holds a natural place within our global presence... Designed for the city, passengers can choose from First or Business SUV classes, each offering repeated excellence, discretion and absolute reliability." [^12^]
**Context:** Wheely focuses exclusively on business elites and high-net-worth individuals. Drivers wear suits and ties, sign NDAs, and complete three days of five-star hotel-inspired hospitality training. Vehicles are sourced from drivers or fleet companies (independent contractors).
**Confidence:** High

**Key details:**
- Wheely offers **Wheely for Business** — a web portal for corporate trip management, invoicing, and reporting.
- Wheely chauffeurs are independent contractors, but Wheely is **consumer-facing brand** — drivers don't build their own brand or client relationships.
- Wheely launched a **loyalty/membership program** and "concierge" service where chauffeurs handle personal tasks (collecting gifts, delivering correspondence, waiting in line for reservations) [^25^].
- Wheely became the **Official VIP Chauffeur Partner of Frieze** art fairs across New York, London, and future Los Angeles events (May 2026) [^26^].
- **Gap**: Wheely provides drivers with trips, not business tools. Drivers are gig workers on a luxury platform, not independent business owners.

### 1.3 Addison Lee (£224.8M Turnover, 7,500+ Drivers)

**Claim: Addison Lee achieved turnover of £224.8 million in FY2023 (year ended August 2023) with Adjusted EBITDA of £27.4 million (up 41%). In FY2024, revenue rose to £231.2 million with pre-tax profit of £1.8 million. The company was acquired by ComfortDelGro for £269.1 million in October 2024.** [^20^] [^25^]

**Source:** Addison Lee Press Release / City AM
**URL:** https://www.addisonlee.com/addlib/addison-lee-accelerates-its-profits-with-strong-growth-in-2023/ / https://www.cityam.com/addison-lee-returned-to-profit-ahead-of-270m-takeover/
**Date:** March 4, 2024 / February 28, 2025
**Excerpt:** "Operating the largest fleet of private hire vehicles in London, with a pool of over 7,500 drivers, profitability has surged with an increased fleet able to meet customer demand for high-quality work... achieving an Adjusted EBITDA of £27.4 million for the year ended 31 August 2023." [^20^]
**Context:** Addison Lee is London's largest premium private hire, black taxi, and courier provider. It acquired Green Tomato Cars (June 2023) and ComCab (July 2021) to expand supply.
**Confidence:** High

**Key details:**
- Addison Lee invested **over £80 million over three years** to upgrade its fleet, including 600 PHEV VW multivans and 1,000 fully electric VW ID.4s.
- The company operates a **driver supply model** — it has 7,500 drivers on its platform but these are supply-side workers, not independent business owners.
- **Gap**: Addison Lee is an employer/operator model, not a SaaS platform for independent chauffeurs.

### 1.4 TBR Global Chauffeuring (Acquired by Lyft, October 2025)

**Claim: Lyft acquired TBR Global Chauffeuring for £83 million (~$110 million) in October 2025. TBR operates in 120+ countries and 3,000+ cities.** [^14^] [^15^] [^17^]

**Source:** Business Travel Executive / Lyft Blog / Dentons
**URL:** https://www.businesstravelexecutive.com/news/lyft-acquires-tbr-global-chauffeuring-for-83-million-about-110-million/
**Date:** October 17, 2025
**Excerpt:** "Operating across six continents, 120 countries and over 3,000 cities, TBR has established itself as a leader in the global luxury chauffeur services industry, valued at over $54 billion annually. For decades, TBR has set the standard for premium ground transportation, delivering precision, discretion and white-glove service for Fortune 500 companies, investment banks, and major global events." [^17^]
**Context:** TBR operates an **asset-light managed-marketplace model** — working with a carefully curated supply base of independent fleet partners with professional chauffeurs. TBR will continue to operate under its own brand and leadership post-acquisition.
**Confidence:** High

**Key details:**
- TBR's business is **high-touch, complex events, financial roadshows** — "a high level of offline bookings" per CEO Craig Chambers [^20^].
- TBR serves Fortune 500 companies, investment banks, and major global events.
- **No integration planned with Lyft's app technology** — the businesses will complement each other. Chambers: "The Lyft app is an on-demand piece of technology; TBR is much more high-touch... There won't be an integration but there is an opportunity to share business." [^20^]
- **Gap**: TBR serves corporate clients through a network of fleet partners. It is not a SaaS tool for individual independent chauffeurs.

### 1.5 8Rental (1M+ Passengers, 30+ European Countries)

**Claim: 8Rental has transported over 1 million passengers across Europe since its founding in 2012, with 285+ local partners and 1,470+ vehicles.** [^30^] [^28^]

**Source:** PR Newswire / 8Rental About Us
**URL:** https://www.prnewswire.com/news-releases/8rental-launches-premium-fleet--revamps-website-after-serving-over-1-million-passengers-across-europe-302550537.html
**Date:** September 9, 2025
**Excerpt:** "8Rental specializes in chauffeur-driven group travel across more than 30 European countries... Their versatile fleet ranges from comfortable sedans to spacious 65-seat luxury coaches, organized into three service tiers (Standard, Business, and First Class)... With over 1,470 vehicles, partnerships with 285+ local operators." [^30^]
**Context:** 8Rental won Tripadvisor's Travelers' Choice Award four years in a row and maintains a #1 spot on Trustpilot with a 5-star rating. The company focuses on **group travel** (charter buses, minibuses, private driver services), not individual executive chauffeur services.
**Confidence:** High

### 1.6 GroundLink (Acquired by Dav El/BostonCoach, 2017)

**Claim: GroundLink was acquired by Marcou Transportation Group (parent of Dav El and BostonCoach) in 2017. It operates a technology-driven network in 500+ cities at 550+ airports worldwide.** [^82^] [^83^]

**Source:** Meetings & Conventions
**URL:** https://www.meetings-conventions.com/Travel/Dav-El-Boston-Coach-GroundLink-Limo-Anywhere-acquisition/98553
**Date:** January 27, 2017
**Excerpt:** "GroundLink, which was founded in 2003, operates a technology-driven network of point-to-point and airport car services in many major cities, both domestically and internationally. Cars can be booked online, via phone or by using the company's app, and all drivers are fully licensed, registered, vetted and screened." [^82^]
**Context:** GroundLink operates an affiliate partner program similar to Blacklane's — connecting independent chauffeur companies with a global customer base. Partners get "complete schedule control," "reliable direct payment" (no commission, no fees), and access to large corporate clients [^74^].
**Confidence:** High

**Key gap**: GroundLink serves fleet companies, not individual independent chauffeurs. No SaaS tools for business operations.

### 1.7 Carey International

**Claim: Carey International operates in 1,000+ cities across 55+ countries with a fleet spanning luxury sedans, SUVs, electric vehicles, minibuses, and full-size coaches. Founded in 1921.** [^81^] [^80^]

**Source:** Carey International Website / SSG Capital Advisors
**URL:** https://www.carey.com/who-we-are/about-carey-international/
**Date:** 2026
**Excerpt:** "Carey International transformed from a local icon into a global leader, scaling our operations to 1,000 cities across 55 countries. Today, our fleet spans luxury sedans, SUVs, electric vehicles, minibuses, and full-size coaches." [^81^]
**Context:** Carey is one of the oldest and most respected names in chauffeured services. It operates through a **global affiliate network** of vetted operators. In 1997, Carey had revenues of $86.37 million; today it likely generates significantly more. Carey was affected by COVID-19 and explored strategic alternatives [^80^].
**Confidence:** High

### 1.8 Dav El | BostonCoach

**Claim: Dav El merged with BostonCoach in 2013 to create the largest privately owned chauffeured transportation company in the world. It operates in 500+ metropolitan markets across six continents with a fleet of 25,000+ vehicles. Estimated revenue of $54.5 million.** [^87^]

**Source:** Growjo
**URL:** https://growjo.com/company/Dav_El_%7C_BostonCoach
**Date:** 2022
**Excerpt:** "Dav El | BostonCoach is the largest privately owned chauffeured transportation company in the world... currently operates in over 500 metropolitan markets, across six continents, with a fleet of more than 25,000 vehicles." [^87^]
**Context:** 50% of Dav El/BostonCoach revenue comes from **affiliate work** — coordinating between independent operators across its network.
**Confidence:** Medium (revenue is estimated)

### 1.9 EmpireCLS Worldwide Chauffeured Services

**Claim: EmpireCLS is a global luxury ground transportation company operating in 1,000+ cities globally. Top chauffeurs can earn up to $120K annually.** [^117^] [^112^]

**Source:** EmpireCLS Careers / Chauffeur Driven Magazine
**URL:** https://www.empirecls.com/become-a-chauffeur/
**Date:** July 1, 2025
**Excerpt:** "Join the world's most prestigious luxury ground transportation company... Available in over 1000+ cities globally... TOP CHAUFFEURS can EARN up to $120K annually." [^117^]
**Context:** EmpireCLS employs in-house software developers who built proprietary dispatch software. The company has invested heavily in EVs (LYRIQ, Lucid Air) and charging infrastructure (~$250,000). The company has three offices: New York/New Jersey, Los Angeles, and Chicago.
**Confidence:** High

### 1.10 GetTransfer

**Claim: GetTransfer operates as a global online marketplace for booking transfers and chauffeured car rentals, connecting passengers directly with transportation service providers.** [^86^] [^90^]

**Source:** GetTransfer.com / Dealroom
**URL:** https://gettransfer.com/en/carrier/new
**Date:** 2026
**Excerpt:** "Our marketplace facilitates a direct connection between passengers and drivers through our app and website. Offer appealing rates and receive numerous bookings from passengers... GetTransfer.com functions as a booking platform that facilitates connections between clients and independent transport service providers." [^86^]
**Context:** GetTransfer is a **marketplace**, not a SaaS platform. Drivers set their own rates and accept bookings. No commission from GetTransfer, but no business tools either.
**Confidence:** High

### 1.11 Gett

**Claim: Gett is an Israeli B2B Ground Transportation Management platform and marketplace. Revenue of $166 million (2020). Acquired by Pango for ~$175 million in May 2024. Lyft acquired Gett's UK operations for £40 million in April 2026.** [^113^]

**Source:** Wikipedia / Various
**URL:** https://en.wikipedia.org/wiki/Gett
**Date:** 2024-2026
**Excerpt:** "Gett is an Israeli B2B Ground Transportation Management (GTM) platform and marketplace... In May 2024, it was reported that Pango would purchase the 'Gett' transportation service application at a price of approximately 175 million dollars. In April 2026, Lyft agreed to acquire Gett's UK operations for £40 million." [^113^]
**Context:** Gett focuses on **B2B corporate travel management**, not individual independent chauffeur SaaS tools.
**Confidence:** High

---

## 2. Indirect Competitors

### 2.1 Uber Black / Uber Elite

**Claim: Uber launched Uber Elite in March 2026 — an invite-only luxury chauffeur service in Los Angeles and San Francisco with commercially licensed professional chauffeurs and vehicles less than three years old. It features in-app "Meet and Greet" for airport arrivals.** [^46^] [^48^]

**Source:** Business Travel News / Uber Newsroom
**URL:** https://www.businesstravelnews.com/Transportation/Ground/Uber-Introduces-Elite-Option / https://www.uber.com/us/en/newsroom/introducing-uber-elite/
**Date:** March 17, 2026 / June 4, 2026
**Excerpt:** "Uber has introduced what it called a new luxury ride experience that includes commercially licensed professional chauffeurs with luxury vehicles that are less than three years old... Uber Elite is available via invite-only in Los Angeles and San Francisco for frequent Uber Black and Uber for Business clients, and soon will launch in New York City." [^46^]
**Context:** Uber Elite rides can be booked at least one hour in advance and up to 90 days ahead through Uber Reserve. The service includes 24/7 phone support, in-vehicle amenities (chargers, water, mints), and special requests (sparkling water, champagne). Uber's acquisition of Blacklane will further accelerate Uber Elite's global expansion.
**Confidence:** High

**Key insight for DriverLink**: Uber Elite launched March 12, 2026 and Uber announced the Blacklane acquisition on March 30, 2026 — less than two weeks later. This sequence suggests Uber recognized it could not build a true chauffeur-grade experience algorithmically and needed to acquire Blacklane's 15 years of luxury hospitality expertise [^115^]. However, Uber Elite is a **consumer-facing premium tier**, not a SaaS platform for independent chauffeurs. Drivers are still gig workers within Uber's ecosystem.

### 2.2 Lyft Lux / Lyft Black / TBR Integration

**Claim: Lyft's acquisition of TBR Global Chauffeuring for £83 million strengthens its premium chauffeur offerings, but TBR will continue to operate independently with no planned integration with Lyft's app technology.** [^14^] [^20^]

**Source:** Business Travel News Europe
**URL:** https://www.businesstravelnewseurope.com/Ground-Transport/Lyft-goes-premium-with-acquisition-of-TBR-Global-Chauffeuring
**Date:** October 15, 2025
**Excerpt:** "The Lyft app is an on-demand piece of technology; TBR is much more high-touch — specialist, complex events, financial roadshows… a high level of offline bookings. There won't be an integration but there is an opportunity to share business." — Craig Chambers, Group CEO of TBR [^20^]
**Context:** Lyft acquired FreeNow (European ride-hailing app) in July 2025, and acquired TBR in October 2025. TBR and Lyft's consumer app will remain separate. North America was a relatively untapped market for TBR, but with Lyft's presence, it expects to grow in the region.
**Confidence:** High

### 2.3 Traditional Limousine Software

#### 2.3.1 Limo Anywhere

**Claim: Limo Anywhere pricing starts at $99/month + $0.25/trip for the Core plan, with Plus at $199/month + $0.20/trip (up to 1,500 trips/month) and BLACK at $499/month + $0.20/trip (up to 5,000 trips/month).** [^19^]

**Source:** Software Finder
**URL:** https://softwarefinder.com/fleet-management-software/limo-anywhere
**Date:** March 4, 2026
**Excerpt:** "Limo Anywhere cost starts at $99/month + $0.25/trip. This basic plan, known as the Core plan, offers features like reservation and back office management, and automated tracking updates." [^19^]
**Context:** Limo Anywhere is a cloud-based management platform for the limousine and private hire industry. It caters to small limousine businesses and large-scale livery fleets with booking, scheduling, reservation management, global affiliate networking, and secure payment processing. It was acquired by Marcou Transportation Group (alongside GroundLink) in 2017 [^82^].
**Confidence:** High

**Key gap**: Limo Anywhere is **fleet management software**, not a platform for building an independent chauffeur brand, attracting direct clients, or managing a solo operation. It's built for dispatchers managing multiple vehicles, not individual owner-operators.

#### 2.3.2 GroundWidgets

**Claim: GroundWidgets offers reservation, dispatch, and accounting suite for ground transportation companies, with mobile apps for customers and chauffeurs, GPS tracking, and driver monitoring.** [^56^] [^58^]

**Source:** Software Finder / GroundWidgets Website
**URL:** https://softwarefinder.com/fleet-management-software/groundwidgets / https://www.groundwidgets.com/
**Date:** January 22, 2026
**Excerpt:** "GroundWidgets offers a next-generation reservation, dispatch, and accounting suite designed to streamline operations and boost efficiency. The software features automated telephony, paperless workflows, and real-time GPS tracking." [^56^]
**Context:** GroundWidgets supports businesses ranging from single-vehicle operators to large global fleets. Custom pricing. Products include SantaCruz, Voyageur, Unified Livery Systems (ULS) and Limousine Management Systems (LMS). IT services billed at $180/hour (business hours) or $300/hour (after hours) [^61^].
**Confidence:** High

**Key gap**: GroundWidgets is **operational back-office software**, not a client acquisition, marketing, or brand-building platform for independent chauffeurs.

#### 2.3.3 Anolla

**Claim: Anolla offers a chauffeur booking platform with a free plan for independent chauffeurs, usage-based pricing, and API-first architecture with Stripe integration.** [^59^]

**Source:** Anolla Website
**URL:** https://anolla.com/en/chauffeur-software
**Date:** 2026
**Excerpt:** "A solo chauffeur can start with a powerful free plan that includes an online booking form, automatic confirmations and calendar synchronisation... Anolla's usage-based pricing model has been developed specifically to reduce the business risks of chauffeur services." [^59^]
**Context:** Anolla is the **closest comparable to DriverLink** among existing chauffeur-focused SaaS tools. It offers a free plan for independent drivers with booking forms, fleet calendars, automated confirmations, and client management. Paid features add automation, payment integrations, accounting/CRM connections, and customer loyalty modules for corporate clients. Rated 5/5 on Capterra for ease of use.
**Confidence:** High

**Key insight**: Anolla validates the market for chauffeur-specific booking SaaS, but appears to be a relatively new/small player (limited online presence, no revenue data available). The existence of a free plan for solo chauffeurs confirms demand at the independent-operator level. This is both validation of the opportunity and a potential competitor to monitor.

#### 2.3.4 Other Traditional Software

- **TaxiCaller**: Cloud-based dispatch system for taxi companies with pay-per-use pricing [^101^]
- **Cabsoluit**: Cloud-native ride-hailing platform for small to mid-sized companies, pay-as-you-go [^101^]
- **Mobisoft Infotech**: Custom chauffeur booking software development (SaaS, custom, white-label options) [^136^]

### 2.4 Uber's Driver Tools and Gig Worker Ecosystem

**Claim: Uber's Driver app serves 3+ million driver-partners globally with features including real-time earnings tracking (used by 86% of drivers on active days), Earnings Hub, Quests, promotions, safety toolkit, and Uber Pro rewards program.** [^75^] [^77^] [^73^]

**Source:** Uber Engineering Blog / Uber Website
**URL:** https://www.uber.com/us/en/blog/real-time-earnings-tracker/ / https://www.uber.com/us/en/drive/driver-app/
**Date:** 2018-2026
**Excerpt:** "Our driver app serves as the most important daily communication tool between Uber and our driver-partners... 86 percent of drivers use [the Real-time Earnings Tracker] on days when they are picking up riders." [^75^]
**Context:** Uber's Driver app includes: session summaries, weekly summaries, weekly statements, fare breakdowns, cash-out options, Quests/promotions, safety toolkit, and Uber Pro rewards. The redesigned "Carbon" app was developed with driver feedback from 2017.
**Confidence:** High

**Critical differentiation for DriverLink**: Uber's tools are designed to keep drivers **dependent on Uber's platform** — they cannot export their client list, build direct relationships, or operate independently. Uber drivers face **algorithmic deactivation risk** — a single unverified passenger complaint can permanently eliminate their income [^85^]. Independent chauffeurs who want to build their own brand and client relationships need entirely different tools.

---

## 3. Adjacent Platforms: Validating the Vertical SaaS Model

### 3.1 GlossGenius (Beauty Vertical SaaS)

**Claim: GlossGenius reached $100M ARR by November 2024, up from $63.8M in October 2024 and $49.5M in December 2023. Total funding of $17.6M. Launched 2016.** [^27^]

**Source:** GetLatka
**URL:** https://getlatka.com/companies/glossgenius
**Date:** December 19, 2024
**Excerpt:** "GlossGenius is a vertical SaaS platform for small business owners across the salon & studio space... In 2024, GlossGenius's revenue reached $100M." [^27^]
**Context:** GlossGenius provides an all-in-one platform for beauty professionals: online booking, payment processing, marketing, client management, and business analytics. Revenue grew from $0 (2016) → $3M → $35M → $50M → $100M (2024).
**Confidence:** High

**Model relevance for DriverLink**: GlossGenius proves that a vertical SaaS platform serving independent professionals in a **fragmented service industry** can reach $100M+ ARR with relatively modest funding ($17.6M). The beauty industry has similar structural characteristics to chauffeur services: independent operators, fragmented market, need for client acquisition + scheduling + payments + marketing. GlossGenius's trajectory shows what's possible for DriverLink with the right execution.

### 3.2 StyleSeat (Beauty Marketplace/SaaS)

**Claim: StyleSeat is the largest marketplace in the $78 billion beauty and wellness industry, having powered 120M+ appointments worth $6.5B+ in revenue for beauty professionals. Total funding of $40M.** [^51^] [^52^]

**Source:** Growjo / Stripe Customers
**URL:** https://growjo.com/company/StyleSeat / https://stripe.com/ae/customers/styleseat
**Date:** 2025
**Excerpt:** "Since launching, StyleSeat has helped beauty professionals book over 100 million appointments and manage $10.6 billion in revenue." [^52^]
**Context:** StyleSeat uses Stripe for embedded payments, offers a smart pricing algorithm for dynamic pricing, and enforces no-show/cancellation fees. It saved professionals ~$2 million in 2020 with cancellation fee enforcement. StyleSeat also offers financing through StyleSeat Capital (35% lifetime adoption rate, 84% retention among financed businesses) [^52^].
**Confidence:** High

**Model relevance**: StyleSeat demonstrates the power of combining **booking + payments + financing** for independent service professionals. The no-show/cancellation fee protection alone saved $2M for users. Financial services (capital, insurance) layered onto a vertical SaaS platform significantly increase stickiness and revenue per user.

### 3.3 Slice (Food Vertical SaaS for Independent Pizzerias)

**Claim: Slice is built exclusively for independent pizzerias, offering online ordering, phone answering, marketing, supply discounts, and customer support. Costs as low as 5% per order (vs. 20-30% for third-party apps).** [^18^]

**Source:** Slice.com
**URL:** https://slice.com/
**Date:** 2026
**Excerpt:** "Slice is built exclusively for pizza. That means our phone agents know how to upsell a side of garlic knots, our marketing is timed around pizza-ordering habits, and our supply deals are negotiated for pizzerias at scale. You get the technology of a big chain without giving up your independence or your name above the door." [^18^]
**Context:** Slice offers: online ordering, 24/7 phone answering by pizza-trained agents, marketing, supply discounts, delivery options (own drivers + backup network including Uber Eats and DoorDash), and 24/7 support. No hidden fees. Plans start from 5% per order.
**Confidence:** High

**Model relevance**: Slice's model — **vertical-specific SaaS + marketplace services that preserve the independent business's brand** — is highly relevant to DriverLink. Independent pizzerias face analogous challenges to independent chauffeurs: competing against chains/platforms, needing technology without giving up independence, struggling with client acquisition. Slice's "keep your name above the door" positioning is exactly the value proposition DriverLink should emulate.

### 3.4 Toast (Restaurant Vertical SaaS)

**Claim: Toast serves ~156,000 active restaurant locations as of Q3 2025, with annualized recurring run-rate revenue exceeding $2.0 billion. Revenue grew from $823M (2020) to $4.96B (2024). IPO'd at $20B valuation in 2021.** [^43^] [^47^] [^50^]

**Source:** Umbrex / LongTermPick
**URL:** https://umbrex.com/resources/company-profiles/toast/
**Date:** 2025-2026
**Excerpt:** "Toast is a restaurant technology company that sells an integrated cloud platform combining point-of-sale software, payment processing, restaurant-grade hardware, and add-on tools for online ordering, payroll, team management, marketing, loyalty, and back-office workflows... In FY2023, Toast reported roughly $3.9 billion of revenue." [^43^]
**Context:** Toast's model: (1) Land with core POS + payments; (2) Expand wallet share through payroll, marketing, loyalty, online ordering, back-office modules; (3) Align revenue with customer success — restaurants that succeed process more transactions, generating higher payment fees for Toast. In 2021, Toast reported **135% net revenue retention** [^47^].
**Confidence:** High

**Model relevance**: Toast demonstrates the **land-and-expand playbook** for vertical SaaS. Start with the most essential tool (for restaurants: POS; for chauffeurs: booking/scheduling), then add modules (payments, marketing, loyalty, payroll, insurance, financing). Toast's 135% NRR shows how revenue can grow with customers even without explicit upselling — the key is aligning platform revenue with customer success.

### 3.5 CloudTrucks (Trucking Vertical SaaS — Closest Comparable)

**Claim: CloudTrucks raised $141.6 million in total funding (valued at $850M in 2021) and provides a "business in a box" solution for independent truck drivers. Revenue grew 9.5x between Series A (2020) and Series B (2021).** [^108^] [^111^] [^109^]

**Source:** TechCrunch / Growjo
**URL:** https://techcrunch.com/2021/11/30/cloudtrucks-raised-115m-series-b-to-help-truck-entrepreneurs-manage-their-business/
**Date:** November 30, 2021
**Excerpt:** "CloudTrucks wants to use technology to help trucking entrepreneurs operate their business... There are around 350,000 owner-operator truckers in the United States... Owner-operators usually own one truck and either lease onto a carrier or operate under their own authority." [^108^]
**Context:** CloudTrucks offers: CT Cash (instant pay, cash card, cash advances), Flex (back-office support, compliance, insurance management), Virtual Carrier (operating under CloudTrucks' authority), schedule optimizer ("dispatcher in your pocket"), Business Intelligence dashboard, CT Exchange (load board), CT Fuel card, and bookkeeping/tax prep services. Revenue model: $150/week subscription or 5% of gross load value (whichever is higher) + 18% service fee on brokerage loads [^109^].
**Confidence:** High

**Model relevance**: CloudTrucks is the **single closest comparable to DriverLink**. Both serve independent operators in fragmented transportation industries who need a "business in a box" — scheduling, client/job acquisition, payments, compliance, insurance, financing. CloudTrucks's $850M valuation and $141.6M in funding demonstrate significant investor appetite for this model. The independent trucking market (~350,000 owner-operators in the US) is comparable in size to the independent chauffeur market globally.

### 3.6 Square Appointments (Generic Booking SaaS)

**Claim: Square Appointments offers a free plan for individual users, Plus at $49/month per location, and Premium at $149/month per location. Over 488 million appointments have been booked through the platform since launch.** [^17^] [^21^]

**Source:** Forbes Advisor / Square
**URL:** https://www.forbes.com/advisor/business/square-appointments-review/
**Date:** October 30, 2025
**Excerpt:** "Square Appointments is a scheduling app that includes a built-in point-of-sale (POS) system and booking website meant for small businesses. It offers free and paid plans with all the features needed to run a service-based business." [^17^]
**Context:** Features include: online booking website, calendar sync (Google Calendar), automated reminders, client portal, Square payment processing, Instagram/Facebook/Google Business integration, no-show protection, class bookings, and staff management. Processing fees: 2.6% + 15¢ (free plan) to 2.5% + 10¢ (paid plans).
**Confidence:** High

**Gap vs. DriverLink need**: Square Appointments is generic — not built for chauffeur-specific workflows (vehicle selection, route optimization, airport transfers, flight tracking, meet-and-greet, hourly vs. point-to-point pricing, chauffeur-specific CRM). Independent chauffeurs need industry-specific features that generic booking tools don't provide.

### 3.7 Shopify (General Independent Business Platform)

**Claim: Shopify powers e-commerce for millions of merchants with a complete toolkit supporting selling, shipping, inventory management, and an extensive app ecosystem.** [^102^] [^42^]

**Source:** 733Park / Tightly
**URL:** https://www.733park.com/the-top-vertical-saas-companies-to-know-today
**Date:** January 5, 2026
**Excerpt:** "Shopify powers ecommerce for millions of merchants through a complete toolkit that supports selling, shipping, and inventory management across both online and physical storefronts. Its app ecosystem, built-in payments, and strong branding tools have made it the platform of choice for small to mid-sized retailers." [^102^]
**Context:** Shopify's app ecosystem includes 8,000+ apps. Key features: drag-and-drop store builder, SEO tools, marketing automation, payment processing, inventory management, analytics. However, Shopify is built for **product-based e-commerce**, not service-based businesses like chauffeur services.
**Confidence:** High

**Gap vs. DriverLink**: Shopify doesn't serve service-based businesses well. A chauffeur can't sell "rides" as products, manage availability windows, handle hourly bookings, or integrate flight tracking through Shopify's e-commerce framework.

---

## 4. Differentiation Opportunities: Where Existing Players Fail Independent Drivers

### 4.1 The Core Problem: Extreme Market Fragmentation + Technology Gap

**Claim: The top 10 chauffeur operators collectively account for only 22-25% of global market revenue. Operators under $1M annual revenue have roughly 50% telematics adoption vs. 90%+ for operators above $5M. Smaller fleets face a significant technology disadvantage.** [^103^] [^95^]

**Source:** Dataintelo / Driving Transactions / Chauffeur Driven
**URL:** https://dataintelo.com/report/chauffeur-services-market
**Date:** 2025-2026
**Excerpt:** "The top ten operators collectively account for approximately 22-25% of total global market revenue, reflecting the highly decentralized nature of the industry... Operators generating less than $1 million annually reported having telematics installed on roughly half their fleet, while operators above $5 million reported telematics adoption exceeding 90%." [^103^] [^95^]
**Context:** The chauffeur services market is transitioning from a fragmented operator landscape toward a two-tier structure: technology-enabled platforms vs. long tail of city-specific operators [^2^]. Regional specialists retain advantages in VVIP transport, government delegations, and event-specific deployments that platform generalists haven't penetrated [^2^].
**Confidence:** High

### 4.2 Unaddressed Pain Points for Independent Chauffeurs

Based on research across competitor platforms, industry surveys, and comparable vertical SaaS models, the following pain points are **systematically unaddressed** for independent chauffeurs:

#### Pain Point 1: No "Business in a Box" for Independent Chauffeurs
- **Current state**: Independent chauffeurs must stitch together multiple tools: a basic website (WordPress/Wix), a generic booking plugin (Bookly/Amelia at $49-89/year) [^71^], manual scheduling (Google Calendar), separate payment processing (Stripe/Square), separate accounting (QuickBooks), manual client follow-up, and word-of-mouth marketing.
- **Gap**: No platform combines booking + scheduling + payments + client CRM + marketing + insurance + financing specifically for chauffeurs.
- **Evidence**: A solo chauffeur can start with Anolla's free plan for basic booking, but even that requires manual integration with other tools. CloudTrucks-like comprehensive solutions simply don't exist for chauffeurs.

#### Pain Point 2: Client Acquisition and Brand Building
- **Current state**: Independent chauffeurs who join Blacklane, GroundLink, or GetTransfer become **invisible suppliers** — passengers book "Blacklane," not "John's Chauffeur Service." The platform owns the client relationship.
- **Gap**: No platform enables independent chauffeurs to build their own brand, own their client relationships, and drive direct bookings while ALSO accessing marketplace demand when needed.
- **Evidence**: Blacklane and GroundLink explicitly state they provide "access to corporate clients" — but these are BLACKLANE'S clients, not the chauffeur's. The chauffeur cannot contact the client directly for repeat business.

#### Pain Point 3: Pricing and Revenue Optimization
- **Current state**: Most independent chauffeurs set fixed rates manually and don't adjust for demand, seasonality, or competitor pricing.
- **Gap**: No accessible dynamic pricing tool for independent chauffeurs. StyleSeat's smart pricing algorithm saved beauty professionals money by adjusting rates during high demand [^52^]. Anolla offers dynamic pricing but only on paid plans [^59^].
- **Evidence**: Chauffeurs face significant revenue volatility. Corporate subscription contracts at $70/hour vs. event packages at $95/hour require strategic pricing decisions that most independents can't analyze [^88^].

#### Pain Point 4: No-Show and Cancellation Protection
- **Current state**: Independent chauffeurs bear the full cost of client no-shows. Without a platform enforcing cancellation policies, they often can't charge fees.
- **Gap**: No easy-to-use system for enforcing no-show/cancellation fees for direct-booked clients.
- **Evidence**: StyleSeat saved beauty professionals nearly $2 million in 2020 alone with automated no-show/cancellation fee enforcement [^52^]. Chauffeurs face the same problem but lack equivalent tools.

#### Pain Point 5: Insurance and Compliance Management
- **Current state**: Independent chauffeurs must navigate commercial auto insurance, licensing, and regulatory compliance on their own. Insurance costs are rising (up 15% in trucking in 2024 [^109^]; likely similar in chauffeur services).
- **Gap**: No platform offers integrated insurance, compliance tracking, or regulatory document management for independent chauffeurs.
- **Evidence**: CloudTrucks bundles insurance and compliance into its Virtual Carrier product. Toast Capital offers lending. These financial services layers significantly increase platform stickiness and revenue per user.

#### Pain Point 6: Deactivation Risk on Gig Platforms
- **Current state**: Chauffeurs who work through Uber face algorithmic deactivation with "little or no human review" [^89^]. A study found 90% of deactivated drivers never got their jobs back [^89^].
- **Gap**: Independent chauffeurs need a platform that helps them build **direct client relationships** as a hedge against platform dependency, while still providing access to demand.
- **Evidence**: NYC proposed "just cause" protections for gig workers after research found most deactivated drivers were high-performers and workers of color facing vague allegations [^89^]. Seattle's just cause law found 80% of appealed deactivations were overturned — vs. just 10% through Uber's internal process [^89^].

#### Pain Point 7: Safety and Professional Development
- **Current state**: A Driving Transactions industry survey found that **only one-third of operators conduct driver training monthly or more frequently**, while 60%+ conduct training quarterly or less often. More than half have not updated their chauffeur manuals in the past year [^95^].
- **Gap**: No platform provides ongoing professional development, safety training, certification tracking, and quality standards for independent chauffeurs.
- **Evidence**: Wheely's three-day hospitality training (inspired by five-star hotels) is a key differentiator [^12^]. EmpireCLS's Smith System safety certification is a recruitment tool [^117^]. Independent chauffeurs lack access to equivalent training resources.

### 4.3 Technology Adoption Gap in Small Fleets

**Claim: While larger fleets have 56% adoption of dash cams, smaller fleets lag at just 24%. Smaller operators face a technology compliance disadvantage.** [^137^]

**Source:** Tech.co via Motor.com
**URL:** https://www.motor.com/2025/10/smaller-sized-fleets-face-compliance-disadvantage-amid-low-dash-cam-adoption/
**Date:** October 23, 2025
**Excerpt:** "While larger fleets have seen 56% adoption of dash cams, smaller fleets are behind at just 24%. Dash cams and other technologies can be expensive to implement, but without them, smaller operators may be more at risk of potentially increasing the cost of compliance breaches." [^137^]
**Context:** The compliance gap creates a "vicious cycle" where penalties financially impact smaller operators' ability to grow, widening the gap further. Smaller fleets can't benefit from programs like FMCSA's Crash Preventability Determination Program because they lack video evidence.
**Confidence:** High

### 4.4 Key Differentiation Strategy for DriverLink

Based on this competitive analysis, DriverLink should differentiate across **six strategic dimensions**:

| Dimension | Status Quo | DriverLink Opportunity |
|---|---|---|
| **Brand ownership** | Gig platforms own the client relationship | Chauffeur owns their brand & client relationships |
| **Business tools** | Stitch together 5-10 separate apps | All-in-one: booking + payments + CRM + marketing + insurance |
| **Pricing intelligence** | Static manual pricing | Dynamic pricing + revenue optimization |
| **Risk protection** | No-show losses absorbed by driver | Automated cancellation fees + insurance + deactivation hedge |
| **Professional growth** | No training/development resources | Certification tracking + hospitality training + safety programs |
| **Financial services** | No access to capital/optimized insurance | Lending + insurance + instant pay + tax prep |

---

## 5. Market Size and Opportunity

### 5.1 Global Chauffeur Services Market

| Source | 2025 Market Size | 2034 Forecast | CAGR |
|---|---|---|---|
| MarketIntelo [^12^] | $52.4B | $98.7B | 7.3% |
| Dataintelo [^103^] | $46.8B | $89.3B | 7.4% |
| Market.us [^57^] | $54.2B (2023) | $188.9B (2033) | 13.3% |
| Dimension Market Research [^2^] | $83.2B (2026) | $284.3B (2035) | 14.6% |

The market size estimates vary significantly based on scope definition (some include all pre-booked ground transport; others are narrower). The most conservative estimate ($46.8B in 2025) still represents a massive TAM.

### 5.2 Addressable Market for DriverLink

The **serviceable addressable market (SAM)** for DriverLink can be estimated as follows:

- Assume 75% of the market is independent operators/small fleets (<10 vehicles) based on fragmentation data [^103^]
- Conservative TAM: $52.4B × 75% = **$39.3B in independent chauffeur revenue globally**
- If DriverLink captures 1% of independent chauffeur revenue as platform fees = **$393M revenue opportunity**
- If DriverLink charges SaaS fees of $50-200/month per chauffeur, with 100,000 independent chauffeurs globally = **$60M-$240M ARR opportunity**

### 5.3 Comparable Vertical SaaS Benchmarks

| Company | Vertical | Revenue | Funding | Key Model Element |
|---|---|---|---|---|
| Toast | Restaurants | $4.96B (2024) | Public ($19.87B mkt cap) | POS + payments + modules |
| Shopify | E-commerce | $8.3B+ (2024) | Public ($100B+ mkt cap) | Store builder + payments + apps |
| GlossGenius | Beauty | $100M ARR (2024) | $17.6M | Booking + payments + marketing |
| StyleSeat | Beauty | $36.4M est. rev | $40M | Booking + marketplace + capital |
| CloudTrucks | Trucking | $14.6M est. rev | $141.6M | "Business in a box" for owner-operators |
| Slice | Pizza | Not disclosed | $163M+ | Ordering + marketing + supply |

**Key insight**: Vertical SaaS platforms serving independent operators in fragmented industries have demonstrated the ability to reach $100M+ ARR (GlossGenius) and even multi-billion dollar scale (Toast, Shopify). The chauffeur vertical has **no equivalent dominant player**, suggesting a massive whitespace.

---

## 6. Trends and Signals

### 6.1 Platform Consolidation Accelerating
- Uber acquiring Blacklane (March 2026) [^18^]
- Lyft acquiring TBR Global (October 2025) [^17^] and Gett UK (April 2026) [^113^]
- Addison Lee acquired by ComfortDelGro (October 2024) [^25^]
- **Signal**: Large platforms are acquiring premium chauffeur capabilities — but these acquisitions serve **consumer/corporate demand**, not independent chauffeur supply tools.

### 6.2 Premium Tier Competition Intensifying
- Uber Elite launch (March 2026) [^48^]
- Wheely NYC expansion (March 2026) [^12^]
- Blacklane powering Uber's premium push [^18^]
- **Signal**: The premium chauffeur segment is being contested by deep-pocketed platforms — this validates the market but also means DriverLink must differentiate by serving **independent operators**, not consumers.

### 6.3 Technology Gaps Widening Between Large and Small Operators
- Small fleets (<$1M revenue): ~50% telematics adoption [^95^]
- Large fleets (>$5M revenue): 90%+ telematics adoption [^95^]
- Small fleets: 24% dash cam adoption vs. 56% for large fleets [^137^]
- 60%+ of operators conduct driver training quarterly or less [^95^]
- **Signal**: The technology gap is structural and widening — creating an urgent need for accessible, affordable SaaS tools designed for small operators.

### 6.4 Vertical SaaS Model Validated Across Industries
- GlossGenius: $100M ARR on $17.6M funding [^27^]
- Toast: 135% NRR through land-and-expand [^47^]
- CloudTrucks: $141.6M raised for owner-operator truckers [^108^]
- Slice: 5% per order vs. 20-30% for generic delivery apps [^18^]
- **Signal**: The vertical SaaS playbook works. The key ingredients are: (1) start with the most painful problem, (2) add financial services for stickiness, (3) align platform revenue with customer success.

### 6.5 Independent Workers Want Independence — But Need Infrastructure
- CloudTrucks CEO: "An increasing number of truck drivers just don't want to be company employees anymore... They want to take control of their time." [^108^]
- 350,000+ owner-operator truckers in the US alone [^108^]
- Uber Crew program (60+ sessions with 100+ team members gathering driver feedback) [^79^]
- **Signal**: Independent workers across transportation verticals want entrepreneurial freedom with infrastructure support. This is exactly DriverLink's target persona.

---

## 7. Controversies and Conflicting Claims

### 7.1 Market Size Estimates Vary Wildly
Market size estimates for chauffeur services range from **$46.8B** (Dataintelo, 2025) to **$284.3B** (Dimension Market Research, 2035 forecast). The discrepancy arises from differing definitions: some reports include all pre-booked luxury ground transportation; others limit to traditional chauffeur services. **Recommendation**: Use the conservative $50-55B range for TAM calculations.

### 7.2 "Asset-Light" vs. "Asset-Heavy" Model Debate
- Blacklane, TBR, and GetTransfer operate asset-light marketplace models (no owned vehicles)
- Addison Lee, EmpireCLS, and Dav El/BostonCoach operate asset-heavy models (owned/leased fleets)
- **Controversy**: The asset-light model scales faster but has lower margin control. The asset-heavy model ensures quality but requires massive capital. DriverLink's SaaS model sidesteps this debate entirely by serving the operators regardless of their asset strategy.

### 7.3 Gig Worker Classification and Regulatory Risk
- Uber classifies drivers as independent contractors, denying them employment protections [^85^]
- NYC proposed "just cause" protections for gig workers [^89^]
- Seattle passed similar protections with 80% of appealed deactivations overturned [^89^]
- **Controversy**: If independent chauffeurs using DriverLink are classified as employees rather than contractors in certain jurisdictions, this could affect platform economics. DriverLink should design its platform to clearly support **independent business ownership** to avoid classification issues.

### 7.4 Will Platform Consolidation Eliminate Independent Operators?
- Uber + Blacklane creates a dominant global premium platform
- Lyft + TBR + Gett UK creates a strong #2
- **Counter-argument**: The market has remained highly fragmented (top 10 = 22-25% share) despite decades of consolidation attempts. The inherent nature of chauffeur services — local relationships, personalized service, trust-based client bonds — resists full platformization. Independent operators will persist, but they need technology to compete.

---

## 8. Recommended Deep-Dive Areas

### 8.1 Quantify the Independent Chauffeur Population
- How many independent/self-employed chauffeurs exist globally and by region?
- What is the average revenue per independent chauffeur?
- What percentage currently use any form of booking/payment software?

### 8.2 Pricing and Business Model Research
- What would independent chauffeurs pay for a SaaS platform? (Benchmark: GlossGenius at ~$50-200/month, Toast at ~$165/month, CloudTrucks at $150/week or 5% of revenue)
- What is the optimal revenue model: flat SaaS fee, percentage of bookings, or hybrid?
- How much additional revenue could dynamic pricing and no-show protection generate?

### 8.3 Regulatory Landscape Deep-Dive
- What licensing and insurance requirements exist for independent chauffeurs in key markets (UK, US, EU, UAE)?
- How do gig worker classification laws affect platform design?
- What compliance technology gaps exist for small operators?

### 8.4 Competitive Response Scenarios
- If Uber/Lyft launch "chauffeur partner SaaS tools," how does DriverLink differentiate?
- If Anolla or another existing player raises significant funding, what's the moat?
- How defensible is the vertical SaaS model once Toast/Shopify enter transportation?

### 8.5 Feature Prioritization Research
- What is the #1 most painful problem for independent chauffeurs? (booking management, client acquisition, payments, insurance, pricing optimization?)
- Which adjacent platform's feature set maps most closely to chauffeur needs? (GlossGenius's booking + payments? CloudTrucks's "business in a box"? Slice's brand-preserving marketplace?)

---

## Appendix: Complete Search Log (24+ Independent Searches)

1. "Blacklane acquired by Uber 2026 chauffeur platform" — Found acquisition details, partner model
2. "Wheely NYC expansion 2026 luxury chauffeur" — Found NYC launch, pricing, features
3. "Addison Lee turnover revenue 2024 2025 driver numbers" — Found financial results, 7,500 drivers
4. "TBR Global Chauffeuring acquired by Lyft 2025" — Found £83M acquisition details
5. "8Rental Europe chauffeur platform passengers" — Found 1M+ passengers, 285 partners
6. "independent chauffeur SaaS platform software tools" — Found GNet Connect, essential tools
7. "Blacklane business model driver partners independent chauffeurs" — Found partner program details
8. "Uber Elite invite-only chauffeur March 2026 launch" — Found Uber Elite features, Meet & Greet
9. "Limo Anywhere chauffeur software pricing features" — Found pricing tiers, capabilities
10. "StyleSeat GlossGenius beauty vertical SaaS business model revenue" — Found $100M ARR, funding
11. "Slice pizza independent restaurant SaaS platform business model" — Found 5% commission model
12. "Square Appointments scheduling independent professionals features" — Found pricing, features
13. "Toast independent restaurant SaaS platform revenue business model" — Found $4.96B revenue model
14. "chauffeur booking software small operator independent driver app" — Found Anolla, free plan
15. "luxury chauffeur market size 2025 2026 global industry report" — Found $52.4B TAM, growth rates
16. "GroundWidgets limo software pricing features" — Found capabilities, pricing model
17. "iChauffeur London independent chauffeur platform" — Found boutique operator model
18. "Carey International chauffeur revenue fleet size" — Found 1,000 cities, 55 countries
19. "CloudTrucks independent trucker SaaS platform revenue business model" — Found $141.6M funding, $850M valuation
20. "chauffeur industry fragmentation independent operators challenges" — Found 22-25% top-10 share
21. "independent chauffeur self-employed challenges client acquisition" — Found $150 CAC, utilization gaps
22. "GetTransfer chauffeur booking platform business model" — Found marketplace model
23. "Gett corporate chauffeur platform Tel Aviv" — Found $166M revenue, Pango acquisition
24. "Dav El BostonCoach revenue fleet operator model" — Found $54.5M revenue, 25,000 vehicles
25. "chauffeur driver technology adoption gap small fleet" — Found 24% vs. 56% dash cam adoption

---

*Report compiled: June 2026*
*Sources: 50+ primary sources including company press releases, industry reports, financial filings, trade publications*
