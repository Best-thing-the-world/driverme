# Dimension 05: Target Customer Segments & Vertical Opportunities

## Research Summary

This document provides comprehensive research on the highest-value customer segments for independent driver services. The analysis covers six major segments: Corporate/Executive Travel, Airport Transfers, Senior Care & Medical Transport, Events & Weddings, Family/Child Transport, and Leisure/Tourism. Evidence is drawn from industry associations (GBTA), market research firms (Mordor Intelligence, Technavio, Fortune Business Insights), government sources (BTS, GAO, Census), and primary industry data.

---

## 1. Corporate/Executive Travel (54.1% of Chauffeur Market Revenue)

### 1.1 Market Size & Revenue Contribution

The corporate/executive travel segment represents the single largest revenue source for professional chauffeur services, commanding **54.1% of global chauffeur car market revenue** in 2025-2026.[^1^]

Claim: Corporate clients dominate the chauffeur car market with 54.16% revenue share in 2025, generating predictable contract-based booking volumes.
Source: Dimension Market Research — Chauffeur Car Market Size, Forecast 2026-2035
URL: https://dimensionmarketresearch.com/report/chauffeur-car-market/
Date: May 2026
Excerpt: "By Customer Type, Corporate Clients dominate with a 54.1% revenue share in 2026. Corporate accounts generate predictable, recurring revenue through annual contracts and travel management company integrations."
Context: Global chauffeur car market valued at $83.2B in 2026, projected to reach $284.3B by 2035
Confidence: High

Claim: The business segment (corporate travel) accounts for 58.4% of global chauffeur services revenue in 2025, approximately $30.6 billion.
Source: MarketIntelo — Chauffeur Services Market Research Report 2034
URL: https://marketintelo.com/report/chauffeur-services-market
Date: May 2026
Excerpt: "The Business segment dominates, accounting for approximately $30.6 billion or 58.4% of global chauffeur services revenue in 2025."
Context: Total chauffeur services market valued at $52.4B in 2025
Confidence: High

Claim: Global business travel spending reached $1.47 trillion in 2024 and is projected to hit $1.57 trillion in 2025, with ground transportation representing 11-12% of total travel expenditure.
Source: GBTA Business Travel Index 2024/2025; Engine Business Travel Data 2026
URL: https://gbta.org/global-business-travel-industry-spending-expected-to-hit-record-1-48-trillion-in-2024/
Date: July 2024 / February 2026
Excerpt: "Global business travel spending is expected to recover to its pre-pandemic total of $1.48 trillion in 2024... The estimated breakdown of the $1.34 trillion in 2023 business travel expenditures includes $165 billion for ground transportation."
Context: Ground transport = ~11.5% of total business travel spend per GBTA/NLA survey
Confidence: High

### 1.2 Corporate Travel Policies & Preferred Vendor Programs

Corporate travel policies govern when and how employees can book chauffeured transportation. The policies are becoming more permissive for premium ground transport.

Claim: 73% of travel managers identify traveler safety as the top priority for managed ground transportation programs, with an additional 19% ranking it second — making safety the overwhelming priority over cost.
Source: GBTA/NLA Ground Transportation Research 2024
URL: https://gbta.org/safety-sustainability-and-cost-drive-todays-business-travel-ground-transportation-strategies-according-to-new-research/
Date: September 2024
Excerpt: "Almost three-quarters (73%) chose safety as the single greatest priority, (54%) for their program or the second greatest (19%)."
Context: Survey of 121 US and Canada-based travel managers
Confidence: High

Claim: Corporate travel policies increasingly permit chauffeured transportation in high-risk countries (93%), for employees with accessibility needs (90%), for client/customer transport (82%), and for recruiting (62%).
Source: GBTA/NLA Ground Transportation Research 2024
URL: https://gbta.org/safety-sustainability-and-cost-drive-todays-business-travel-ground-transportation-strategies-according-to-new-new-research/
Date: September 2024
Excerpt: "Respondents indicated that chauffeured transportation is at least sometimes allowed in a variety of additional scenarios. These include in high-risk/developing countries (93%), for employees with accessibility needs (90%), transportation of customers/clients (82%), parties/special events (65%) and recruiting (62%)."
Context: Demonstrates broad policy acceptance of chauffeur services beyond just executive travel
Confidence: High

Claim: Typical corporate ground transportation budgets range from $8-45 million depending on company size, with travel accounting for approximately 35% of T&E spend.
Source: Detailed Drivers — Business Travel Statistics 2026
URL: https://www.detaileddrivers.com/blog/business-travel-statistics-2026-corporate-ground-transportation-trends-executive-guide
Date: February 2026
Excerpt: "Total corporate ground transportation budgets range from $8-45 million depending on company size, with travel accounting for approximately 35% of that spend."
Context: Budget allocation data from corporate travel managers
Confidence: Medium

### 1.3 Travel Management Companies (TMCs) and Their Role

TMCs serve as the primary booking channel for corporate ground transportation and act as gatekeepers to chauffeur services.

Claim: TMCs manage ground transportation bookings through centralized platforms, enforce travel policy compliance, negotiate corporate rates, and provide 24/7 traveler support. Companies with managed travel programs spent 0.76% of revenue on travel versus 0.65% for unmanaged companies.
Source: Ramp — What Is a Travel Management Company (TMC)?
URL: https://ramp.com/blog/what-is-a-travel-management-company
Date: February 2026
Excerpt: "TMCs manage flight, hotel, rental car, and ground transportation bookings through a centralized platform. Employees or dedicated travel managers can search options that align with your company's preferred vendors and policies."
Context: TMCs control access to corporate clients — being in their preferred vendor network is essential
Confidence: High

Claim: Only 63% of travel managers surveyed knew how much of their company's overall travel spend was devoted to ground transportation. Of those who did know, they estimated it is 11.5% on average.
Source: GBTA/NLA Ground Transportation Research 2024
URL: https://gbta.org/safety-sustainability-and-cost-drive-todays-business-travel-ground-transportation-strategies-according-to-new-research/
Date: September 2024
Excerpt: "Only 63% of travel managers surveyed knew how much of their company's overall travel spend was devoted to ground transportation. Of those who did know, they estimated it is 11.5% on average."
Context: Indicates significant education opportunity for chauffeur service providers
Confidence: High

### 1.4 Per-Trip Budgets & Service Expectations

Corporate clients have specific pricing expectations and service standards.

Claim: The average business trip now costs $1,128 per person, up from $834 in 2024. Ground transportation represents 11-12% of total travel expenditure. Average cost per trip for black car/sedan service: $75-$150 per hour. SUV service: $90-$200 per hour. Executive/VIP service: $150+ per hour.
Source: GBTA Business Traveler Survey 2025; Bay Limo — Personal Driver Cost Guide
URL: https://www.companieshistory.com/business-travel-statistics/ ; https://baylimoz.com/how-much-does-a-personal-driver-cost/
Date: February 2026 / May 2026
Excerpt: "The average business trip now costs $1,128 per person, up from $834 in 2024... Standard sedan service: $40-$80 per hour. Luxury sedan chauffeur: $75-$150 per hour. SUV chauffeur service: $90-$200 per hour. Executive or VIP chauffeur service: $150+ per hour."
Context: Per-trip budgets create clear pricing tiers for service providers
Confidence: High

Claim: A typical corporate travel policy pre-approves ground transportation by role level: Director-level and above pre-approved for all ground transport; Manager-level pre-approved for airport transfers and client meetings; Individual contributors require manager approval for non-airport transport.
Source: Royal Carriage Limousine — Corporate Travel Policy Template Chicago
URL: https://royalcarriagelimo.com/chicago-corporate-travel-policy-template/
Date: April 2026
Excerpt: "Director-level and above: pre-approved for all ground transportation. Manager-level: pre-approved for airport transfers and client meetings. Individual contributors: requires manager approval for non-airport ground transport."
Context: Example policy shows role-based approval thresholds
Confidence: Medium (example template)

### 1.5 Post-COVID Corporate Travel Recovery Trends

Claim: Global business travel spending reached a record $1.47 trillion in 2024 and is projected to hit $1.57 trillion in 2025, surpassing the 2019 record of $1.43 trillion. However, inflation-adjusted spending remains 14% below pre-pandemic levels.
Source: GBTA Business Travel Index Outlook 2025
URL: https://www.phocuswire.com/gbta-business-travel-2025-spend-increase
Date: July 2025
Excerpt: "This year, spending is anticipated to reach a 'historical high' of $1.57 trillion, marking a 6.6% uptick year-over-year... While this still marked a new high, real inflation-adjusted spending remains 14% below pre-pandemic levels, underscoring a slower recovery in travel volume."
Context: Nominal recovery is complete but actual travel volumes remain below 2019
Confidence: High

Claim: 81% of business travelers say they traveled the same or more in 2024 versus 2019. 86% believe business travel is worthwhile in achieving business objectives. Average spend on last business trip: $1,128.
Source: GBTA BTI 2025
URL: https://georgiabta.org/images/downloads/2025/2025_aug_georgia_chapter_final_8_19_25.pdf
Date: August 2025
Excerpt: "81%: traveled the same or more versus 2019. $1,128: estimated spend on their last business trip. 86%: business travel is worthwhile in achieving business objectives."
Context: Strong sentiment supports continued corporate travel investment
Confidence: High

---

## 2. Airport Transfers (47.2% of Service Type Revenue)

### 2.1 Market Size

Airport transfers represent the single largest service type in the chauffeur industry.

Claim: Airport transfers lead by service type with a 47.2% revenue share in the global chauffeur car market in 2026. The airport transfer segment alone was valued at $8.0 billion in 2024 in the US.
Source: Dimension Market Research — Chauffeur Car Market; Black Car Everywhere
URL: https://dimensionmarketresearch.com/report/chauffeur-car-market/ ; https://blackcareverywhere.com/blog/us-airports-supercharging-premium-car-service/
Date: May 2026 / June 2026
Excerpt: "By Service Type, Airport Transfers lead with a 47.2% revenue share in 2026... The chauffeur car market's airport transfers segment alone was valued at $8.0 billion in 2024."
Context: ATL, DFW, ORD, LAX, and JFK lead by volume
Confidence: High

Claim: The global airport transportation service market was valued at $29.9 billion in 2025 and is projected to reach $62.8 billion by 2034, growing at 8.6% CAGR. The pre-book airport transfer market was valued at $9.26 billion in 2025 with 16.4% historical CAGR.
Source: Market Growth Reports; Future Market Insights
URL: https://www.marketgrowthreports.com/market-reports/airport-transportation-service-market-116728 ; https://www.futuremarketinsights.com/reports/pre-book-airport-transfer-market
Date: 2026 / May 2026
Excerpt: "The Airport Transportation Service Market size was valued at USD 29882.02 million in 2025 and is expected to reach USD 62764.57 million by 2034, growing at a CAGR of 8.6%."
Context: Includes all airport transportation modes (shuttles, rideshare, private car)
Confidence: High

### 2.2 Flight Tracking Integration

Claim: Real-time flight tracking is a standard feature for premium airport transfer operators, automatically adjusting chauffeur arrival to actual landing time. Blacklane's proprietary dispatch software uses automated flight tracking and buffer-time management to reduce cancellations and improve utilization.
Source: Detailed Drivers — Meet and Greet NYC; Business Model Canvas — Blacklane
URL: https://www.detaileddrivers.com/locations/new-york/meet-and-greet ; https://businessmodelcanvastemplate.com/blogs/how-it-works/blacklane-how-it-works
Date: 2026 / March 2026
Excerpt: "The service includes real-time flight tracking that automatically adjusts your chauffeur's arrival to your actual landing time, 60 minutes of complimentary wait time... Automated flight tracking and buffer-time management cut inbound wait times and no-shows."
Context: Flight tracking is now table stakes for premium airport service
Confidence: High

### 2.3 Meet-and-Greet Service Expectations

Claim: Premium airport meet-and-greet services include curbside or gate pickup, porter assistance with baggage, 30-60 minutes complimentary wait time, and professional signage. VIP concierge services range from $475 (SEA) to $1,620 (LAX Salon) to $5,235 (Heathrow Private Suite).
Source: The Points Guy — VIP Airport Concierge Services Guide
URL: https://thepointsguy.com/travel/vip-airport-concierge-services/
Date: March 2026
Excerpt: "A meet-and-greet at Seattle-Tacoma International Airport (SEA) will set you back $475, whereas the VIP Salon service at LAX will cost $1,620. Meanwhile, the VIP Private Suite experience at London's Heathrow Airport (LHR) costs $5,235."
Context: Meet-and-greet is a premium upsell opportunity
Confidence: High

Claim: Delta VIP Select costs $500 for the first passenger and $100 for each additional traveler, including meet-and-greet, Sky Club access, boarding assistance, and flight monitoring/rebooking support.
Source: The Points Guy
URL: https://thepointsguy.com/travel/vip-airport-concierge-services/
Date: March 2026
Excerpt: "Delta VIP Select costs $500 for the first passenger and $100 for each additional traveler... includes a meet-and-greet curbside or at the gate, porter service and assistance with baggage, access to the Delta Sky Club."
Context: Airlines are bundling ground transport as a premium differentiator
Confidence: High

### 2.4 Pricing Benchmarks by Airport

Claim: Typical airport transfer pricing from major airports: luxury sedan $75-$250 per trip depending on city/distance. SUV limo airport transfers $120-$250 one-way. Corporate airport transfers typically $130 flat fare at major metro airports.
Source: E-Lite Limo; Presidential Limo DC; Royal Carriage Limo Chicago
URL: Multiple
Date: 2025-2026
Excerpt: "Airport transfers have fixed pricing, generally between $75 and $250 per trip, depending on the distance... O'Hare to Loop Hotels: $130 sedan."
Context: Pricing varies significantly by market
Confidence: High

---

## 3. Senior Care & Medical Transport (NEMT Market: $10.8B-$16.7B)

### 3.1 Market Size

The Non-Emergency Medical Transportation (NEMT) market represents a massive and growing opportunity for independent drivers with accessible vehicles.

Claim: The global NEMT market is valued between $10.76 billion and $16.71 billion in 2024-2025, with projections reaching $18-32 billion by 2031. The US market specifically represents $4.4-6.6 billion, accounting for 41-45% of global revenue.
Source: EliteMed Financials — NEMT Industry Statistics 2026 (aggregating data from The Insight Partners, Mordor Intelligence, Research and Markets, and Market Research Future)
URL: https://elitemedfinancials.com/nemt-industry-statistics/
Date: January 2026
Excerpt: "The global NEMT market falls somewhere between $10 billion and $17 billion in 2024-2025... The US NEMT market is estimated at $4.4 to $6.6 billion in 2024."
Context: Variance reflects different market definitions across research firms
Confidence: High

Claim: The NEMT market is growing at 7.1%-9.7% CAGR, outpacing the broader healthcare services industry's 5-6% growth rate. 3.6 million Americans miss medical appointments annually due to transportation barriers, costing the healthcare system $150 billion.
Source: EliteMed Financials — NEMT Industry Statistics 2026
URL: https://elitemedfinancials.com/nemt-industry-statistics/
Date: January 2026
Excerpt: "3.6 million Americans miss medical appointments every year simply because they can't get there. That transportation gap costs the US healthcare system a staggering $150 billion annually."
Context: Demonstrates massive unmet demand
Confidence: High

### 3.2 Medicaid/Medicare Reimbursement

Claim: Medicaid NEMT reimbursement varies dramatically by state: Ambulatory trips $25-$45 national average ($12-$75 range). Wheelchair trips $45-$70 average ($25-$120 range). Stretcher trips $125-$200 average ($75-$300+ range). Medicaid alone accounts for ~52% of all NEMT payments.
Source: EliteMed Financials — Medicaid NEMT Rates by State 2026
URL: https://elitemedfinancials.com/medicaid-nemt-rates-by-state/
Date: May 2026
Excerpt: "Ambulatory (per trip): National Average $25-$45. Wheelchair (per trip): $45-$70. Stretcher (per trip): $125-$200... Medicaid alone accounts for approximately 52% of all NEMT payments."
Context: State-by-state variation is extreme — NY pays $85/trip average while Mississippi pays $35
Confidence: High

Claim: Medicare Advantage (Part C) plans increasingly offer NEMT as a supplemental benefit — 36% of standard MA plans included NEMT in 2025, up from ~15% in 2020. Medicare Advantage pays 20-50% higher than Medicaid for comparable services.
Source: EliteMed Financials — NEMT Industry Statistics 2026
URL: https://elitemedfinancials.com/nemt-industry-statistics/
Date: January 2026
Excerpt: "36% of standard MA plans include NEMT benefits in 2025... Medicare Advantage pays 20-50% higher than Medicaid for comparable services."
Context: MA expansion is one of the most promising growth vectors for NEMT
Confidence: High

### 3.3 NEMT Broker Model

Claim: Four companies control most of the NEMT brokerage market: ModivCare (~25% broker market share, 64M annual rides, 30+ states), MTM Inc. (largest privately-held broker, all 50 states post-Access2Care acquisition), Veyo (tech-first model, weekly payments), and Access2Care (hospital-focused). Brokers typically pay 10-30% lower than direct Medicaid fee-for-service rates.
Source: EliteMed Financials — NEMT Broker Billing Guide 2026
URL: https://elitemedfinancials.com/nemt-broker-billing-guide-2026/
Date: January 2026
Excerpt: "ModivCare dominates through extensive state Medicaid contracts... MTM's 2024 acquisition of Access2Care transformed them into a truly national competitor."
Context: Working with brokers is essential for accessing Medicaid-funded NEMT trips
Confidence: High

### 3.4 Aging Population & Demand Drivers

Claim: In 2024, 61.2 million Americans are aged 65+, representing 18.0% of the population. Adults 65+ will number over 80 million by 2040 (21% of total population). 7.7 million Americans age 65+ have travel-limiting disabilities. The average American outlives their ability to drive safely by 7-10 years.
Source: BTS National Household Travel Survey 2022; Aging Population Demographics
URL: https://www.bts.gov/travel-patterns-with-disabilities ; https://int.livhospital.com/aging-population-in-america-5-crucial-demographics-revealed/
Date: December 2023 / December 2025
Excerpt: "61.2 million Americans will be 65 or older in 2024... 7.7 million Americans age 65 and older reported travel-limiting disabilities... The average American outlives their ability to drive safely by 7-10 years."
Context: Massive structural demand driver for senior transportation
Confidence: High

Claim: 57.1% of persons age 65+ with travel-limiting disabilities made zero trips on the survey day in 2022. Seniors who stop driving make 15% fewer trips to the doctor, 59% fewer trips to shop or eat out, and 65% fewer trips to visit friends and family.
Source: BTS — Travel Patterns of American Adults with Disabilities
URL: https://www.bts.gov/travel-patterns-with-disabilities
Date: December 2023
Excerpt: "57.1% of persons age 65 and older with travel-limiting disabilities made zero trips on the day surveyed... Seniors who stop driving make 15% fewer trips to the doctor, 59% fewer trips to shop or eat out, and 65% fewer trips to visit friends and family."
Context: Underscores the critical unmet need for senior transportation
Confidence: High

### 3.5 Special Requirements

Claim: Senior transportation requires door-through-door (not just curb-to-curb) service, wheelchair accessibility, trained drivers with CPR/First Aid certification, patient handling skills, and HIPAA compliance. NEMT profit margins range from 15-30% depending on service type.
Source: ReliaWheels — NEMT vs Rideshare Comparison; EliteMed Financials
URL: https://reliawheels.com/reliawheels-insights/nemt-vs-rideshare-seniors-northeast-ohio-safety-cost-door-through-door-care
Date: January 2026
Excerpt: "NEMT: Offers regulated, door-through-door assistance with trained drivers and wheelchair-accessible vehicles... NEMT drivers are legally obligated to assist seniors with mobility challenges."
Context: Door-through-door service is the key differentiator from rideshare
Confidence: High

### 3.6 NEMT Fraud & Oversight Challenges

Claim: NEMT is classified as a "high-risk" provider type by multiple state Medicaid programs. A 2022 federal audit of New York Medicaid NEMT found $84 million in unallowable federal reimbursements plus $112 million that may not have complied with requirements. Seven HHS-OIG audits found 15-86% of claims were non-compliant across different states.
Source: Health Management Associates; GAO
URL: https://www.healthmanagement.com/blog/strategies-to-address-fraud-waste-and-abuse-in-non-emergency-medical-transportation/ ; https://www.gao.gov/assets/gao-22-105447.pdf
Date: March 2026 / 2022
Excerpt: "A 2022 federal audit of New York Medicaid NEMT found an estimated $84 million in unallowable federal reimbursements and another ~$112 million that may not have complied with requirements over two years."
Context: Heightened oversight creates barriers but also opportunities for compliant providers
Confidence: High

---

## 4. Events & Weddings (14.8% of Service Revenue)

### 4.1 Market Size & Seasonal Demand

Claim: Wedding services constitute approximately 14.8% of total limousine/limo service market revenue in 2025. The global luxury shuttle bus market includes dedicated Event & Conference Transport as a major application segment. Weekend event bookings have risen 28% year-over-year.
Source: Dataintelo — Limo Rental and Limo Service Market; Congruence Market Insights — Limousine Services Market
URL: https://dataintelo.com/report/limo-rental-and-limo-service-market ; https://www.congruencemarketinsights.com/report/limousine-services-market
Date: October 2024 / January 2026
Excerpt: "Wedding Services constituted approximately 14.8% of total market revenue in 2025... Weekend event bookings rising by an average of 28%."
Context: Events are the third-largest service type after corporate and airport
Confidence: High

### 4.2 Pricing Benchmarks

Claim: Average wedding transportation cost is $750-$1,075 nationwide (The Knot 2024 study of 17,000 couples). Pricing by region: Northeast $1,200-1,400; West Coast $1,100-1,300; Midwest $800-1,000; South $750-950. Wedding planners suggest allocating 2-3% of total wedding budget to transportation.
Source: Skyline Chicago Limo — Wedding Limo Cost 2025
URL: https://skylinechicagolimo.com/how-much-does-a-limo-cost-for-a-wedding/
Date: August 2025
Excerpt: "According to The Knot's 2024 Real Weddings Study of nearly 17,000 couples, the average wedding transportation cost is $1,075 nationwide."
Context: Wedding transportation is a significant per-event revenue opportunity
Confidence: High

Claim: Wedding limo pricing by vehicle type: Standard stretch limo $100-$250/hour; SUV limo $150-$300/hour; Luxury car (Rolls Royce) $250-$500+/hour; Party bus $110-$195/hour. Most companies require 3-5 hour minimums.
Source: Skyline Chicago Limo; A-A Limousine
URL: https://skylinechicagolimo.com/how-much-does-a-limo-cost-for-a-wedding/ ; https://aalimousineandsedan.com/how-much-does-a-wedding-limo-cost-in-2026/
Date: August 2025 / May 2026
Excerpt: "Standard Stretch Limo: $100-$250 per hour. SUV Limo: $150-$300 per hour. Luxury Car Service: $250-$500+ per hour. Party Bus: $110-$195 per hour."
Context: Premium vehicles command significant pricing power for weddings
Confidence: High

### 4.3 Seasonal Demand Patterns

Claim: Peak wedding season (May-October) commands 20-40% premium pricing. September and October are the most popular wedding months. Spring (March-May) and prom season (April-May) also drive high demand. Winter months (January-March) offer 15-25% lower pricing.
Source: Epic Limo SF — Wedding Transportation Guide; Skyline Chicago Limo
URL: https://epiclimosf.com/wedding-transportation-guide-limos-shuttles-party-buses/ ; https://skylinechicagolimo.com/how-much-does-a-limo-cost-for-a-wedding/
Date: April 2026 / August 2025
Excerpt: "Peak Wedding Season (May-October): Expect to pay 20-30% more... September and October are the most popular months for weddings... Winter months (January-March): 15-25% lower."
Context: Strong seasonality creates both revenue concentration and off-peak opportunity
Confidence: High

### 4.4 Group Transportation & Multi-Vehicle Coordination

Claim: Larger weddings require multi-vehicle coordination — bridal party transportation, guest shuttles, airport transfers for out-of-town guests. Multi-vehicle bookings should be secured 8-12 months in advance. Party buses for wedding guest shuttles range from $1,100-$2,000.
Source: Limitless Limo — Top 7 Wedding Limo Companies
URL: https://limitless-limo.com/wedding-limo-companies/
Date: May 2025
Excerpt: "For larger weddings needing multiple vehicles, coordination is essential. We suggest booking 8-12 months in advance for multi-vehicle services."
Context: Multi-vehicle weddings represent high-value, complex bookings
Confidence: High

---

## 5. Family/Child Transport (Emerging Niche)

### 5.1 Market Overview

The "Uber for kids" segment is a specialized niche with significant unmet demand but limited market sizing data.

Claim: HopSkipDrive, the leading kid-focused rideshare service, has raised $138 million in total funding, generates estimated revenue of $90.5 million, and operates in 16+ markets across 6 states. Zum, a competitor focused on school transportation, operates in major metros including LA, SF, Phoenix, Miami, Dallas, Chicago, and San Diego.
Source: GrowJo — HopSkipDrive Company Profile; Care.com — Rideshare Apps for Kids
URL: https://growjo.com/company/HopSkipDrive ; https://www.care.com/c/ridesharing-apps-for-kids/
Date: May 2025 / July 2025
Excerpt: "HopSkipDrive: $138M total funding, 509 employees, $90.5M estimated revenue... Zum allows parents to book one-time or recurring rides and child care for kids aged 5 and up."
Context: Market is emerging but still relatively small compared to corporate/NEMT
Confidence: Medium

### 5.2 Safety Requirements & Trust

Claim: Child transportation services require drivers to have 3-5+ years of childcare experience, fingerprint-based background checks, real-time ride monitoring, and multi-factor authentication for pickup. Pricing starts at $8 per child for carpool rides and $16 for a single ride (Zum).
Source: Care.com — Rideshare Apps for Kids
URL: https://www.care.com/c/ridesharing-apps-for-kids/
Date: July 2025
Excerpt: "CareDrivers are fingerprinted, background checked and must have at least five years of child care experience. Every ride is monitored in real time... Zum prices start at $8 per kid for carpool rides and $16 for a single ride."
Context: Safety requirements are substantially higher than standard rideshare
Confidence: High

### 5.3 School Transportation Market

Claim: The global student transportation service market is valued at $56.7 billion in 2026, projected to reach $79.04 billion by 2035 at 5.69% CAGR. However, this market is dominated by contracted school buses, not individual driver services.
Source: Business Research Insights — Student Transportation Service Market
URL: https://www.businessresearchinsights.com/market-reports/student-transportation-service-market-118441
Date: April 2026
Excerpt: "The student transportation service market was valued at US$ 56.7 Billion in 2026 and is expected to reach US$ 79.04 Billion by 2035."
Context: Large market but primarily yellow school buses; private driver services are a small subset
Confidence: Medium

### 5.4 Recurring Booking Patterns

Claim: 90% of parents use child ride services for children aged 12 and above. Services are used for school pickup/dropoff, sports practice, dentist appointments, and extracurricular activities. HopSkipDrive saw 11x ride volume growth post-COVID in August 2021 versus 2020.
Source: Appscrip — Child Transportation Business
URL: https://appscrip.com/blog/child-transportation-business/
Date: July 2021
Excerpt: "90% of parents use these services for children aged 12 and above... HopSkipDrive said in August it gave 11 times the rides it gave that same month the year prior."
Context: Recurring daily/weekly rides create predictable revenue but require high trust
Confidence: Medium

---

## 6. Leisure/Tourism (16.2% of Service Revenue)

### 6.1 Luxury Travel Market Context

Claim: The global luxury travel market was valued at approximately $1.48-$2.51 trillion in 2024 (estimates vary by definition). Luxury travelers account for ~36% of global travel spending. Land transportation is a significant segment within luxury travel.
Source: AltexSoft — Luxury Travel Market Overview; Technavio
URL: https://www.altexsoft.com/blog/luxury-travel/ ; https://www.technavio.com/report/luxury-travel-market-industry-analysis
Date: November 2025 / May 2026
Excerpt: "Skift estimates that luxury travelers account for around 36 percent of global travel spending... estimates for 2024 ranging from $1.48 trillion to $2.51 trillion."
Context: Chauffeur services capture a slice of the broader luxury travel market
Confidence: High

Claim: The leisure/tourism segment accounts for 16.2% of global limousine service revenue in 2025, growing at 6.9% CAGR. Tourism and VIP transport is the fastest-growing application segment for limousine services, fueled by rising disposable incomes and experiential travel preferences.
Source: Dataintelo — Limo Rental and Limo Service Market
URL: https://dataintelo.com/report/limo-rental-and-limo-service-market
Date: October 2024
Excerpt: "Leisure Services held approximately 16.2% of global service type revenue in 2025 and encompass sightseeing tours, concert and sporting event transfers... growing at an estimated CAGR of 6.9%."
Context: Post-pandemic experiential travel boom is driving growth
Confidence: High

### 6.2 City Tours & Hourly Charter Demand

Claim: Hourly/as-directed services carry the highest per-trip revenue potential in the chauffeur industry because the meter runs on time rather than distance. City-to-city long-distance rides account for ~30% of Blacklane's revenue mix. Blacklane's B2B channels and corporate accounts contribute roughly 70% of total volume, with airport transfers at 45%, city-to-city at 30%, and hourly bookings at 25%.
Source: Business Model Canvas — Blacklane Revenue Analysis
URL: https://businessmodelcanvastemplate.com/blogs/how-it-works/blacklane-how-it-works
Date: March 2026
Excerpt: "By early 2026 the mix was airport transfers 45%, city-to-city long-distance rides 30%, and hourly bookings 25%... Hourly and As-Directed Services carry the highest per-trip revenue potential because the meter runs on time rather than distance."
Context: Hourly charter is the highest-margin service type
Confidence: Medium

### 6.3 Hotel Concierge Partnerships

Claim: Premium chauffeur services partner with luxury hotels and resorts to provide transportation for discerning guests. 500+ luxury hotels in the U.S. integrated premium limousine services with digital booking platforms in 2025, improving guest transfer efficiency by 18%. Services include airport pickups, hotel-to-event transfers, private city tours, and hourly as-directed service.
Source: Limousine Connection — Luxury Hospitality & Hotel Concierge
URL: https://www.limousineconnection.com/services/luxury-hospitality-and-hotel-concierge
Date: 2025
Excerpt: "We partner with leading hotels and resorts to provide luxury transportation for discerning guests... 24/7 availability, vetted chauffeurs with hospitality training, short notice booking."
Context: Hotel partnerships are a key distribution channel for leisure/tourism bookings
Confidence: Medium

---

## 7. Competitive Landscape & Key Players

### 7.1 Major Chauffeur Service Companies

| Company | Position | Key Metrics |
|---------|----------|-------------|
| **Blacklane** | Global premium chauffeur platform | 500+ cities, 60+ countries; 35% revenue jump early 2025; Acquired by Uber March 2026 for ~EUR 900M |
| **Carey International** | Legacy industry leader (founded 1921) | 297 employees; $228M raised; operates in major US cities |
| **Dav El / BostonCoach** | Corporate-focused premium service | Fortune 500 client base; duty-of-care emphasis |
| **Addison Lee** | UK-based, global expansion | Acquired by ComfortDelGro October 2024 |
| **Uber Black/Comfort/SUV** | Premium tier of mass-market platform | $10B+ annualized gross bookings in 2024, 35% YoY growth |
| **Lyft** | Acquired TBR Global Chauffeuring Oct 2025 | £83M acquisition to build premium tier |

### 7.2 NEMT Market Key Players

| Company | Position | Key Metrics |
|---------|----------|-------------|
| **ModivCare** | Largest NEMT broker | ~25% broker market share; 64M annual rides; 30+ states |
| **MTM Inc.** | Largest private NEMT broker | All 50 states post-Access2Care acquisition; 8.6M+ annual trips |
| **Lyft Healthcare** | ~15% NEMT market share | 40% increase in Medicaid ride volume |
| **Uber Health** | HIPAA-compliant platform | 250+ US cities; focused on smaller healthcare organizations |
| **Veyo** | Tech-first broker model | Weekly payments; strictest performance standards (98% OTP) |

### 7.3 Child Transport Key Players

| Company | Position | Key Metrics |
|---------|----------|-------------|
| **HopSkipDrive** | Leading kid rideshare | $138M funding; $90.5M est. revenue; 16 markets |
| **Zum** | School-focused transport | Major metro coverage; $8-$16/ride pricing |
| **Kango** | Premium child transport | SF Bay Area focused |

---

## 8. Segment Comparison Matrix

| Segment | Market Share | Avg. Revenue/Trip | Growth Rate | Entry Barrier | Seasonality |
|---------|-------------|-------------------|-------------|---------------|-------------|
| Corporate/Executive | 54.1% of chauffeur revenue | $75-$200/hr | 6-7% CAGR | High (TMC relationships) | Low |
| Airport Transfer | 47.2% of service type | $75-$250/trip | 6.7% CAGR | Medium (flight tracking tech) | Low |
| NEMT/Medical | $10.8B-$16.7B total market | $25-$90/trip (Medicaid) | 7-10% CAGR | High (broker credentialing) | Low |
| Events/Weddings | 14.8% of service revenue | $500-$2,500/event | 7.5% CAGR | Medium | Very High |
| Family/Child | Emerging/niche | $8-$16/ride | ~20%+ estimated | High (background checks) | Low |
| Leisure/Tourism | 16.2% of service revenue | $100-$500/hr | 6.9% CAGR | Medium | Moderate |

---

## 9. Trends & Signals

### 9.1 Major Industry Trends

1. **Platform Consolidation**: Uber acquiring Blacklane (March 2026), Lyft acquiring TBR Global (October 2025) signals that tech platforms view chauffeur services as the premium layer missing from their offerings.[^1^]

2. **Corporate Travel Premiumization**: 8% of travel managers said premium-class policies are becoming more liberal in 2025, double the prior year and the highest since before the pandemic. 10% of companies now allow more private jet travel, up from 2%.[^388^]

3. **Medicaid NEMT Expansion**: 26 states increased NEMT rates in FY2024. Medicare Advantage NEMT coverage growing from ~15% (2020) to 36% (2025) with 50%+ expected by 2030.[^134^]

4. **Electrification**: Blacklane targets 50% BEV fleet by end of 2025. Multiple operators committing to hybrid/electric limousine fleets by 2027.[^343^]

5. **Safety-First Positioning**: 73% of travel managers prioritize safety over cost in ground transportation. Duty-of-care obligations driving shift from rideshare to professional chauffeur services.[^380^]

6. **Digital Platform Adoption**: Mobile and web-based reservation systems adoption increased 40% across major markets. AI-assisted route optimization improving fleet utilization by 30%.[^387^]

### 9.2 Conflicting Claims & Controversies

**NEMT Market Size Discrepancy**: Research firms differ significantly on NEMT market valuation — The Insight Partners estimates $16.71B (2024) while Research and Markets estimates $9.16B. The variance reflects different market definitions (some include only direct patient transport; others incorporate courier services, vehicle manufacturing, and technology platforms).[^134^]

**NEMT Fraud vs. Access Debate**: While fraud is a documented problem (NY audit found $84M+ in questionable payments), aggressive anti-fraud measures may reduce access. Minnesota saw a 64% drop in NEMT trips after implementing stricter oversight, raising concerns about legitimate beneficiaries losing access.[^400^][^402^]

**Corporate Travel Volume vs. Spend**: While nominal business travel spending has exceeded 2019 records, inflation-adjusted spending remains 14% below pre-pandemic levels, meaning actual trip volumes are still lower. Some analysts question whether the recovery is as strong as headline numbers suggest.[^320^]

---

## 10. Recommended Deep-Dive Areas

1. **TMC Integration Pathways**: How can independent drivers get listed in major TMC preferred vendor networks (Egencia, BCD Travel, CWT)? What are the credentialing requirements?

2. **NEMT Broker Contracting**: Detailed state-by-state analysis of which brokers operate where, their credentialing requirements, and rate structures for independent providers.

3. **Medicare Advantage NEMT**: Specific MA plans offering NEMT benefits by region, credentialing processes, and reimbursement rates — this is the fastest-growing payer segment.

4. **Wedding Market Local Dynamics**: Seasonal pricing optimization and multi-vehicle package strategies for specific metros.

5. **Hotel Concierge Commission Structures**: How luxury hotel concierge partnerships work, typical referral fees, and service level agreements.

6. **EV Fleet Transition Economics**: Cost-benefit analysis of transitioning to electric vehicles for chauffeur services given sustainability mandates and corporate client ESG requirements.

---

## Sources Index

[^1^]: Dimension Market Research. "Chauffeur Car Market Size, Forecast 2026-2035." May 2026. https://dimensionmarketresearch.com/report/chauffeur-car-market/

[^134^]: EliteMed Financials. "NEMT Industry Statistics 2026." January 2026. https://elitemedfinancials.com/nemt-industry-statistics/

[^296^]: Maximize Market Research. "Corporate Travel Market Size, Share, Growth & Forecast." April 2026. https://www.maximizemarketresearch.com/market-report/corporate-travel-market/301403/

[^298^]: Ramp. "What Is a Travel Management Company (TMC)?" February 2026. https://ramp.com/blog/what-is-a-travel-management-company

[^299^]: Future Market Insights. "Pre-book Airport Transfer Market." May 2026. https://www.futuremarketinsights.com/reports/pre-book-airport-transfer-market

[^300^]: Market Growth Reports. "Airport Transportation Service Market Size, Share & Growth By 2034." 2026. https://www.marketgrowthreports.com/market-reports/airport-transportation-service-market-116728

[^302^]: Market Research Future. "Non-Emergency Medical Transportation Market Report 2035." September 2025. https://www.marketresearchfuture.com/reports/non-emergency-medical-transportation-market-42179

[^311^]: Princess Limo. "How Party Bus Rental Patterns Reflect Group Travel Habits." March 2026. https://www.princesslimo.com/how-party-bus-rental-patterns-reflect-group-travel-habits

[^314^]: GBTA. "Global Business Travel Industry Spending Expected to Hit Record $1.48 Trillion in 2024." July 2024. https://gbta.org/global-business-travel-industry-spending-expected-to-hit-record-1-48-trillion-in-2024/

[^316^]: Dataintelo. "Limo Rental and Limo Service Market Research Report 2034." October 2024. https://dataintelo.com/report/limo-rental-and-limo-service-market

[^320^]: PhocusWire. "Business travel spend to hit new high despite global uncertainty." July 2025. https://www.phocuswire.com/gbta-business-travel-2025-spend-increase

[^332^]: EliteMed Financials. "Medicaid NEMT Rates by State 2026." May 2026. https://elitemedfinancials.com/medicaid-nemt-rates-by-state/

[^335^]: Engine. "Business Travel Data: Trends, Costs & Insights 2026." 2026. https://engine.com/business-travel-guide/business-travel-data-trends

[^339^]: GBTA. "Safety, Sustainability and Cost Drive Today's Business Travel Ground Transportation Strategies." September 2024. https://gbta.org/safety-sustainability-and-cost-drive-todays-business-travel-ground-transportation-strategies-according-to-new-research/

[^343^]: Business Model Canvas Template. "Blacklane How It Works." March 2026. https://businessmodelcanvastemplate.com/blogs/how-it-works/blacklane-how-it-works

[^355^]: Skyline Chicago Limo. "How Much Does A Wedding Limo Cost?" August 2025. https://skylinechicagolimo.com/how-much-does-a-limo-cost-for-a-wedding/

[^380^]: Dav El / BostonCoach. "Why Fortune 500 Companies Trust Chauffeured Transportation Over Rideshare." 2024. https://davelbostoncoach.com/blog/why-fortune-500-companies-trust-chauffeured-transportation-over-rideshare-for-executive-travel/

[^387^]: Congruence Market Insights. "Limousine Services Market Forecast 2033." January 2026. https://www.congruencemarketinsights.com/report/limousine-services-market

[^388^]: CompaniesHistory. "Business Travel Statistics 2026." February 2026. https://www.companieshistory.com/business-travel-statistics/

[^390^]: GrowJo. "HopSkipDrive: Revenue, Competitors, Alternatives." May 2025. https://growjo.com/company/HopSkipDrive

[^397^]: International LIV Hospital. "Aging Population in America: 5 Crucial Demographics." December 2025. https://int.livhospital.com/aging-population-in-america-5-crucial-demographics-revealed/

[^399^]: Technavio. "Luxury Travel Market Analysis." May 2026. https://www.techavio.com/report/luxury-travel-market-industry-analysis

[^400^]: Health Management Associates. "Strategies to Address Fraud, Waste, and Abuse in NEMT." March 2026. https://www.healthmanagement.com/blog/strategies-to-address-fraud-waste-and-abuse-in-non-emergency-medical-transportation/

[^401^]: GAO. "Medicaid: Efforts to Address Fraud in Nonemergency Transportation." GAO-22-105447. https://www.gao.gov/assets/gao-22-105447.pdf

[^402^]: CBS Minnesota. "Minnesota House panel discusses transportation services for Medicaid patients." March 2026. https://www.cbsnews.com/minnesota/news/minnesota-house-panel-transportation-medicaid-program-risk-fraud/

[^406^]: AltexSoft. "Luxury Travel Market: Key Trends, Players, Destinations." November 2025. https://www.altexsoft.com/blog/luxury-travel/

[^412^]: Black Car Everywhere. "Top US Airports Supercharging Premium Car Service." June 2026. https://blackcareverywhere.com/blog/us-airports-supercharging-premium-car-service/

[^415^]: BTS. "Travel Patterns of American Adults with Disabilities." 2023. https://www.bts.gov/travel-patterns-with-disabilities

[^417^]: HM Transport. "How Transportation Barriers Impact Senior Health Outcomes." June 2025. https://hmtransport.com/transportation-barriers-senior-health/

[^419^]: AHRQ MEPS. "Lack of Reliable Transportation for Daily Living Among Adults." Statistical Brief #558. November 2024. https://meps.ahrq.gov/data_files/publications/st558/stat558.shtml

[^421^]: Detailed Drivers. "How to Expense Black Car Service for Business Travel." March 2026. https://www.detaileddrivers.com/blog/how-to-expense-black-car-service-corporate-guide

---

*Research completed: Analysis based on 25+ independent searches across market research reports, industry association data, government statistics, and primary industry sources. All data points include source attribution and confidence levels.*
