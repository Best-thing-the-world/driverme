import { HashRouter, Routes, Route, Outlet } from 'react-router-dom'
import Layout from './components/Layout'
import DashboardLayout from './components/DashboardLayout'

// Public pages
import Landing from './pages/Landing'
import Pricing from './pages/Pricing'
import Features from './pages/Features'
import Directory from './pages/Directory'
import Storefront from './pages/Storefront'
import Booking from './pages/Booking'
import Login from './pages/Login'
import Register from './pages/Register'

// Dashboard pages
import DashboardOverview from './pages/dashboard/DashboardOverview'
import DashboardBookings from './pages/dashboard/DashboardBookings'
import DashboardCRM from './pages/dashboard/DashboardCRM'
import DashboardServices from './pages/dashboard/DashboardServices'
import DashboardEarnings from './pages/dashboard/DashboardEarnings'
import DashboardStorefront from './pages/dashboard/DashboardStorefront'
import AdminDashboard from './pages/dashboard/AdminDashboard'

function PublicLayout() {
  return (
    <Layout>
      <Outlet />
    </Layout>
  )
}

function DriverLayout() {
  return (
    <DashboardLayout>
      <Outlet />
    </DashboardLayout>
  )
}

function App() {
  return (
    <HashRouter>
      <Routes>
        {/* Public routes with Navbar + Footer */}
        <Route element={<PublicLayout />}>
          <Route path="/" element={<Landing />} />
          <Route path="/pricing" element={<Pricing />} />
          <Route path="/features" element={<Features />} />
          <Route path="/drivers" element={<Directory />} />
          <Route path="/drivers/:id" element={<Storefront />} />
          <Route path="/book/:driverId" element={<Booking />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
        </Route>

        {/* Dashboard routes with sidebar + top bar */}
        <Route element={<DriverLayout />}>
          <Route path="/dashboard" element={<DashboardOverview />} />
          <Route path="/dashboard/bookings" element={<DashboardBookings />} />
          <Route path="/dashboard/crm" element={<DashboardCRM />} />
          <Route path="/dashboard/services" element={<DashboardServices />} />
          <Route path="/dashboard/earnings" element={<DashboardEarnings />} />
          <Route path="/dashboard/storefront" element={<DashboardStorefront />} />
          <Route path="/admin" element={<AdminDashboard />} />
        </Route>
      </Routes>
    </HashRouter>
  )
}

export default App
