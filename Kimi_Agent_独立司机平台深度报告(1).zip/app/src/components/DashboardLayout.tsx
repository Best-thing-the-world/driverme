import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Calendar,
  Users,
  Wallet,
  Car,
  Store,
  Settings,
  LogOut,
  Bell,
  Search,
  Menu,
  X,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { cn } from '@/lib/utils';

const sidebarNavItems = [
  {
    section: 'BUSINESS',
    items: [
      { label: 'Overview', icon: LayoutDashboard, path: '/dashboard' },
      { label: 'Bookings', icon: Calendar, path: '/dashboard/bookings' },
      { label: 'CRM', icon: Users, path: '/dashboard/crm' },
      { label: 'Earnings', icon: Wallet, path: '/dashboard/earnings' },
    ],
  },
  {
    section: 'PROFILE',
    items: [
      { label: 'Services', icon: Car, path: '/dashboard/services' },
      { label: 'Storefront', icon: Store, path: '/dashboard/storefront' },
    ],
  },
];

interface DashboardLayoutProps {
  children: React.ReactNode;
}

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  const location = useLocation();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  // Auto-collapse on tablet
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 640) {
        setCollapsed(false);
        setMobileOpen(false);
      } else if (window.innerWidth < 1024) {
        setCollapsed(true);
      } else {
        setCollapsed(false);
      }
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Close mobile drawer on route change
  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  const isActive = (path: string) => {
    if (path === '/dashboard') {
      return location.pathname === '/dashboard';
    }
    return location.pathname.startsWith(path);
  };

  const sidebarWidth = collapsed ? 'w-[72px]' : 'w-[260px]';

  return (
    <div className="min-h-[100dvh] bg-[#0A0A0F]">
      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-40 lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          'fixed top-0 left-0 h-full bg-[#0D0D12] border-r border-[#2A2A35] z-50 transition-all duration-300 flex flex-col',
          sidebarWidth,
          mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        )}
      >
        {/* Logo area */}
        <div className={cn('flex items-center justify-center py-6 border-b border-[#2A2A35]', collapsed && 'px-2')}>
          <Link to="/dashboard" className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gold-shine flex items-center justify-center flex-shrink-0">
              <span className="font-display font-bold text-[#0A0A0F] text-lg leading-none">DL</span>
            </div>
            {!collapsed && (
              <span className="font-display text-lg font-semibold text-[#F0EDE8]">
                DriverLink
              </span>
            )}
          </Link>
        </div>

        {/* Collapse toggle (desktop only) */}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="hidden lg:flex absolute -right-3 top-20 w-6 h-6 rounded-full bg-[#1E1E26] border border-[#2A2A35] items-center justify-center text-[#8A8A96] hover:text-[#F0EDE8] transition-colors z-10"
        >
          {collapsed ? <ChevronRight size={12} /> : <ChevronLeft size={12} />}
        </button>

        {/* Mobile close button */}
        <button
          onClick={() => setMobileOpen(false)}
          className="lg:hidden absolute top-4 right-4 text-[#8A8A96] hover:text-[#F0EDE8]"
        >
          <X size={20} />
        </button>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-4">
          {sidebarNavItems.map((section) => (
            <div key={section.section} className="mb-6">
              {!collapsed && (
                <h6 className="px-4 mb-2 text-[11px] font-medium text-[#5A5A66] uppercase tracking-[0.1em]">
                  {section.section}
                </h6>
              )}
              <ul className="space-y-0.5 px-2">
                {section.items.map((item) => {
                  const active = isActive(item.path);
                  return (
                    <li key={item.path}>
                      <Link
                        to={item.path}
                        className={cn(
                          'flex items-center rounded-lg transition-all duration-200 relative group',
                          collapsed ? 'justify-center px-2 py-3' : 'px-4 py-2.5',
                          active
                            ? 'bg-[#1E1E26] text-[#D4A853]'
                            : 'text-[#8A8A96] hover:bg-[#141419] hover:text-[#F0EDE8]'
                        )}
                        title={collapsed ? item.label : undefined}
                      >
                        {active && (
                          <div className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-5 bg-[#D4A853] rounded-r-full" />
                        )}
                        <item.icon size={18} className="flex-shrink-0" />
                        {!collapsed && (
                          <span className="ml-3 text-sm font-medium">{item.label}</span>
                        )}
                        {/* Tooltip for collapsed */}
                        {collapsed && (
                          <div className="absolute left-full ml-2 px-2 py-1 bg-[#1E1E26] border border-[#2A2A35] rounded-md text-xs text-[#F0EDE8] whitespace-nowrap opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-opacity z-50">
                            {item.label}
                          </div>
                        )}
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}
        </nav>

        {/* Bottom user area */}
        <div className={cn('border-t border-[#2A2A35] py-4', collapsed ? 'px-2' : 'px-4')}>
          <div className={cn('flex items-center', collapsed ? 'flex-col gap-2' : 'gap-3')}>
            <div className="relative flex-shrink-0">
              <div className="w-8 h-8 rounded-full bg-[#D4A853] flex items-center justify-center">
                <span className="text-xs font-semibold text-[#0A0A0F]">MJ</span>
              </div>
              <div className="absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full bg-[#22C55E] border-2 border-[#0D0D12]" />
            </div>
            {!collapsed && (
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-[#F0EDE8] truncate">Marcus J.</p>
                <p className="text-[11px] text-[#5A5A66]">Driver</p>
              </div>
            )}
            <div className={cn('flex items-center', collapsed ? 'flex-col gap-2' : 'gap-1')}>
              <button className="p-1.5 rounded-md text-[#5A5A66] hover:text-[#F0EDE8] hover:bg-[#1E1E26] transition-colors">
                <Settings size={16} />
              </button>
              <button className="p-1.5 rounded-md text-[#5A5A66] hover:text-[#EF4444] hover:bg-[#1E1E26] transition-colors">
                <LogOut size={16} />
              </button>
            </div>
          </div>
        </div>
      </aside>

      {/* Top Navbar */}
      <header
        className={cn(
          'fixed top-0 h-16 z-30 bg-[rgba(10,10,15,0.9)] backdrop-blur-[16px] border-b border-[#2A2A35] transition-all duration-300 flex items-center px-6',
          collapsed ? 'left-[72px] right-0' : 'left-[260px] right-0'
        )}
        style={{ left: collapsed ? '72px' : '260px' }}
      >
        <div className="flex items-center justify-between w-full">
          {/* Left: page title */}
          <div className="flex items-center gap-4">
            <button
              onClick={() => setMobileOpen(true)}
              className="lg:hidden p-2 rounded-lg text-[#8A8A96] hover:bg-[#1E1E26] hover:text-[#F0EDE8] transition-colors"
            >
              <Menu size={20} />
            </button>
            <h1 className="text-xl font-semibold text-[#F0EDE8]">
              {location.pathname === '/dashboard' && 'Overview'}
              {location.pathname === '/dashboard/bookings' && 'Bookings'}
              {location.pathname === '/dashboard/crm' && 'Customer CRM'}
              {location.pathname === '/dashboard/services' && 'Services'}
              {location.pathname === '/dashboard/earnings' && 'Earnings'}
              {location.pathname === '/dashboard/storefront' && 'Storefront'}
            </h1>
          </div>

          {/* Right: actions */}
          <div className="flex items-center gap-3">
            <button className="relative p-2 rounded-lg text-[#8A8A96] hover:bg-[#1E1E26] hover:text-[#F0EDE8] transition-colors">
              <Search size={18} />
            </button>
            <button className="relative p-2 rounded-lg text-[#8A8A96] hover:bg-[#1E1E26] hover:text-[#F0EDE8] transition-colors">
              <Bell size={18} />
              <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] flex items-center justify-center bg-[#D4A853] text-[#0A0A0F] text-[10px] font-bold rounded-full px-1">
                3
              </span>
            </button>
            <div className="relative ml-1">
              <div className="w-9 h-9 rounded-full bg-[#D4A853] flex items-center justify-center">
                <span className="text-xs font-semibold text-[#0A0A0F]">MJ</span>
              </div>
              <div className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-[#22C55E] border-2 border-[#0A0A0F]" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main
        className="min-h-[100dvh] pt-16 transition-all duration-300"
        style={{ marginLeft: collapsed ? '72px' : '260px' }}
      >
        <div className="p-8">
          {children}
        </div>
      </main>
    </div>
  );
}
