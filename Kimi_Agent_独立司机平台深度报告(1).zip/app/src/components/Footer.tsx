import { Link } from 'react-router-dom'
import { Linkedin, Twitter, Instagram } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="bg-[#0A0A0F] border-t border-[#2A2A35] py-16">
      <div className="max-w-[1280px] mx-auto px-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand Column */}
          <div className="flex flex-col gap-4">
            <Link to="/" className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gold-shine flex items-center justify-center">
                <span className="font-display font-bold text-[#0A0A0F] text-lg leading-none">DL</span>
              </div>
              <span className="font-display text-xl font-semibold text-[#F0EDE8]">
                DriverLink
              </span>
            </Link>
            <p className="text-sm text-[#5A5A66]">
              The platform for independent chauffeurs.
            </p>
            <div className="flex items-center gap-4 mt-2">
              <a href="#" className="text-[#5A5A66] hover:text-gold transition-colors">
                <Linkedin size={20} />
              </a>
              <a href="#" className="text-[#5A5A66] hover:text-gold transition-colors">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-[#5A5A66] hover:text-gold transition-colors">
                <Instagram size={20} />
              </a>
            </div>
          </div>

          {/* Product Column */}
          <div className="flex flex-col gap-4">
            <h5 className="text-base font-semibold text-[#F0EDE8]">Product</h5>
            <div className="flex flex-col gap-3">
              <Link to="/features" className="text-sm text-[#5A5A66] hover:text-gold transition-colors">Features</Link>
              <Link to="/pricing" className="text-sm text-[#5A5A66] hover:text-gold transition-colors">Pricing</Link>
              <Link to="/drivers" className="text-sm text-[#5A5A66] hover:text-gold transition-colors">Directory</Link>
              <Link to="/book/demo" className="text-sm text-[#5A5A66] hover:text-gold transition-colors">Booking</Link>
            </div>
          </div>

          {/* Company Column */}
          <div className="flex flex-col gap-4">
            <h5 className="text-base font-semibold text-[#F0EDE8]">Company</h5>
            <div className="flex flex-col gap-3">
              <a href="#" className="text-sm text-[#5A5A66] hover:text-gold transition-colors">About</a>
              <a href="#" className="text-sm text-[#5A5A66] hover:text-gold transition-colors">Blog</a>
              <a href="#" className="text-sm text-[#5A5A66] hover:text-gold transition-colors">Careers</a>
              <a href="#" className="text-sm text-[#5A5A66] hover:text-gold transition-colors">Press</a>
            </div>
          </div>

          {/* Support Column */}
          <div className="flex flex-col gap-4">
            <h5 className="text-base font-semibold text-[#F0EDE8]">Support</h5>
            <div className="flex flex-col gap-3">
              <a href="#" className="text-sm text-[#5A5A66] hover:text-gold transition-colors">Help Center</a>
              <a href="#" className="text-sm text-[#5A5A66] hover:text-gold transition-colors">Contact</a>
              <a href="#" className="text-sm text-[#5A5A66] hover:text-gold transition-colors">Privacy</a>
              <a href="#" className="text-sm text-[#5A5A66] hover:text-gold transition-colors">Terms</a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-[#2A2A35] flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-xs text-[#5A5A66]">&copy; 2025 DriverLink. All rights reserved.</p>
          <p className="text-xs text-[#5A5A66]">Made for independent drivers.</p>
        </div>
      </div>
    </footer>
  )
}
