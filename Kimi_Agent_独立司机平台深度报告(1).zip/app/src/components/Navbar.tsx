import { useState, useEffect } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { Menu, X } from 'lucide-react'

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const location = useLocation()

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    setMobileOpen(false)
  }, [location.pathname])

  const navLinks = [
    { label: 'Drivers', path: '/drivers' },
    { label: 'Features', path: '/features' },
    { label: 'Pricing', path: '/pricing' },
  ]

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 h-[72px] flex items-center border-b border-white/5 transition-all duration-300 ${
        scrolled
          ? 'bg-[rgba(10,10,15,0.95)] backdrop-blur-[20px]'
          : 'bg-[rgba(10,10,15,0.85)] backdrop-blur-[20px]'
      }`}
    >
      <div className="max-w-[1280px] mx-auto w-full px-6 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-3 group">
          <div className="w-10 h-10 rounded-full bg-gold-shine flex items-center justify-center">
            <span className="font-display font-bold text-[#0A0A0F] text-lg leading-none">DL</span>
          </div>
          <span className="font-display text-xl font-semibold text-[#F0EDE8] group-hover:text-gold transition-colors">
            DriverLink
          </span>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className="text-sm font-medium text-[#8A8A96] hover:text-[#F0EDE8] transition-colors duration-200"
            >
              {link.label}
            </Link>
          ))}
        </div>

        {/* Desktop CTAs */}
        <div className="hidden md:flex items-center gap-3">
          <Link
            to="/login"
            className="px-5 py-2.5 rounded-full text-sm font-semibold text-[#F0EDE8] border border-[#2A2A35] hover:bg-[#1E1E26] transition-all duration-200"
          >
            Log In
          </Link>
          <Link
            to="/register"
            className="px-5 py-2.5 rounded-full text-sm font-semibold text-[#0A0A0F] bg-gold-shine hover:scale-[1.02] hover:shadow-[0_4px_24px_rgba(212,168,83,0.3)] transition-all duration-200"
          >
            Join Waitlist
          </Link>
        </div>

        {/* Mobile Hamburger */}
        <button
          className="md:hidden text-[#F0EDE8] p-2"
          onClick={() => setMobileOpen(!mobileOpen)}
        >
          {mobileOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="absolute top-[72px] left-0 right-0 bg-[rgba(10,10,15,0.98)] backdrop-blur-[20px] border-b border-[#2A2A35] md:hidden">
          <div className="px-6 py-6 flex flex-col gap-4">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className="text-base font-medium text-[#8A8A96] hover:text-[#F0EDE8] transition-colors py-2"
              >
                {link.label}
              </Link>
            ))}
            <div className="flex flex-col gap-3 pt-4 border-t border-[#2A2A35]">
              <Link
                to="/login"
                className="px-5 py-2.5 rounded-full text-sm font-semibold text-[#F0EDE8] border border-[#2A2A35] hover:bg-[#1E1E26] transition-all text-center"
              >
                Log In
              </Link>
              <Link
                to="/register"
                className="px-5 py-2.5 rounded-full text-sm font-semibold text-[#0A0A0F] bg-gold-shine hover:scale-[1.02] transition-all text-center"
              >
                Join Waitlist
              </Link>
            </div>
          </div>
        </div>
      )}
    </nav>
  )
}
