import { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import {
  LayoutDashboard,
  CalendarDays,
  Users,
  Briefcase,
  DollarSign,
  Store,
  Settings,
  LogOut,
  Menu,
  X,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react'

const businessNav = [
  { label: 'Overview', path: '/dashboard', icon: LayoutDashboard },
  { label: 'Bookings', path: '/dashboard/bookings', icon: CalendarDays },
  { label: 'CRM', path: '/dashboard/crm', icon: Users },
  { label: 'Services', path: '/dashboard/services', icon: Briefcase },
  { label: 'Earnings', path: '/dashboard/earnings', icon: DollarSign },
]

const profileNav = [
  { label: 'Storefront', path: '/dashboard/storefront', icon: Store },
  { label: 'Settings', path: '/dashboard/settings', icon: Settings },
]

interface DashboardSidebarProps {
  collapsed?: boolean
  onCollapseChange?: (collapsed: boolean) => void
}

export default function DashboardSidebar({ collapsed = false, onCollapseChange }: DashboardSidebarProps) {
  const location = useLocation()
  const [mobileOpen, setMobileOpen] = useState(false)
  const [isCollapsed, setIsCollapsed] = useState(collapsed)

  const toggleCollapse = () => {
    const next = !isCollapsed
    setIsCollapsed(next)
    onCollapseChange?.(next)
  }

  const isActive = (path: string) => {
    if (path === '/dashboard') {
      return location.pathname === '/dashboard'
    }
    return location.pathname.startsWith(path)
  }

  const navItemClass = (active: boolean) =>
    [
      'flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-200',
      active
        ? 'bg-[#1E1E26] text-[#D4A853] border-l-[3px] border-[#D4A853]'
        : 'text-[#8A8A96] hover:bg-[#141419] hover:text-[#F0EDE8] border-l-[3px] border-transparent',
      isCollapsed ? 'justify-center px-2' : '',
    ].join(' ')

  const sidebarContent = (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className={["flex items-center gap-3 px-4 pt-6 pb-4", isCollapsed ? 'justify-center px-2' : ''].join(' ')}>
        <div className="w-10 h-10 rounded-full bg-gold-shine flex items-center justify-center flex-shrink-0">
          <span className="font-display font-bold text-[#0A0A0F] text-lg leading-none">DL</span>
        </div>
        {!isCollapsed && (
          <span className="font-display text-lg font-semibold text-[#F0EDE8]">DriverLink</span>
        )}
      </div>

      {/* Scrollable nav */}
      <div className="flex-1 overflow-y-auto px-3 py-4 space-y-6">
        {/* Business section */}
        <div>
          {!isCollapsed && (
            <p className="px-4 text-[10px] font-semibold text-[#5A5A66] uppercase tracking-[0.1em] mb-2">
              Business
            </p>
          )}
          {isCollapsed && <div className="border-t border-[#2A2A35] mb-3 mx-2" />}
          <div className="space-y-1">
            {businessNav.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={navItemClass(isActive(item.path))}
                title={isCollapsed ? item.label : undefined}
                onClick={() => setMobileOpen(false)}
              >
                <item.icon size={20} className="flex-shrink-0" />
                {!isCollapsed && <span>{item.label}</span>}
              </Link>
            ))}
          </div>
        </div>

        {/* Profile section */}
        <div>
          {!isCollapsed && (
            <p className="px-4 text-[10px] font-semibold text-[#5A5A66] uppercase tracking-[0.1em] mb-2">
              Profile
            </p>
          )}
          {isCollapsed && <div className="border-t border-[#2A2A35] mb-3 mx-2" />}
          <div className="space-y-1">
            {profileNav.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={navItemClass(isActive(item.path))}
                title={isCollapsed ? item.label : undefined}
                onClick={() => setMobileOpen(false)}
              >
                <item.icon size={20} className="flex-shrink-0" />
                {!isCollapsed && <span>{item.label}</span>}
              </Link>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom user section */}
      <div className="border-t border-[#2A2A35] px-3 py-4">
        <div className={["flex items-center gap-3 px-3 py-2", isCollapsed ? 'justify-center' : ''].join(' ')}>
          <div className="w-9 h-9 rounded-full bg-[#2A2A35] flex items-center justify-center flex-shrink-0">
            <span className="text-sm font-semibold text-[#D4A853]">MJ</span>
          </div>
          {!isCollapsed && (
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-[#F0EDE8] truncate">Marcus Johnson</p>
              <p className="text-xs text-[#5A5A66] truncate">marcus@driverlink.co</p>
            </div>
          )}
          {!isCollapsed && (
            <button className="text-[#5A5A66] hover:text-[#EF4444] transition-colors p-1">
              <LogOut size={18} />
            </button>
          )}
        </div>

        {/* Collapse toggle */}
        <button
          onClick={toggleCollapse}
          className={[
            "mt-3 flex items-center gap-2 text-xs text-[#5A5A66] hover:text-[#8A8A96] transition-colors",
            isCollapsed ? 'justify-center w-full' : 'px-3',
          ].join(' ')}
        >
          {isCollapsed ? <ChevronRight size={16} /> : <><ChevronLeft size={16} /> <span>Collapse</span></>}
        </button>
      </div>
    </div>
  )

  return (
    <>
      {/* Mobile hamburger */}
      <button
        className="lg:hidden fixed top-4 left-4 z-[60] p-2 rounded-lg bg-[#141419] border border-[#2A2A35] text-[#F0EDE8]"
        onClick={() => setMobileOpen(!mobileOpen)}
      >
        {mobileOpen ? <X size={20} /> : <Menu size={20} />}
      </button>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="lg:hidden fixed inset-0 z-[55] bg-black/60 backdrop-blur-sm"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Mobile drawer */}
      <div
        className={[
          'lg:hidden fixed top-0 left-0 z-[56] h-full bg-[#0D0D12] border-r border-[#2A2A35] transition-transform duration-300',
          mobileOpen ? 'translate-x-0' : '-translate-x-full',
          'w-[260px]',
        ].join(' ')}
      >
        {sidebarContent}
      </div>

      {/* Desktop sidebar */}
      <aside
        className={[
          'hidden lg:flex flex-col fixed top-0 left-0 h-full bg-[#0D0D12] border-r border-[#2A2A35] z-50 transition-all duration-300',
          isCollapsed ? 'w-[80px]' : 'w-[260px]',
        ].join(' ')}
      >
        {sidebarContent}
      </aside>
    </>
  )
}
