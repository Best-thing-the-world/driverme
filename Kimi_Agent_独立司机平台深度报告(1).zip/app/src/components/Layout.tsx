import type { ReactNode } from 'react'
import Navbar from './Navbar'
import Footer from './Footer'

interface LayoutProps {
  children: ReactNode
  showFooter?: boolean
}

export default function Layout({ children, showFooter = true }: LayoutProps) {
  return (
    <div className="min-h-[100dvh] bg-[#0A0A0F] text-[#F0EDE8]">
      <Navbar />
      <main className="pt-[72px]">
        {children}
      </main>
      {showFooter && <Footer />}
    </div>
  )
}
