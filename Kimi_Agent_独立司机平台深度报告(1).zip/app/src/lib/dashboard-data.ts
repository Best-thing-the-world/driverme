// Mock data for Driver Dashboard pages

export interface Booking {
  id: string;
  customer: {
    name: string;
    email: string;
    phone: string;
    avatar?: string;
  };
  service: {
    name: string;
    icon: string;
  };
  status: 'new' | 'accepted' | 'confirmed' | 'in_progress' | 'completed' | 'canceled';
  pickup: {
    location: string;
    date: string;
    time: string;
  };
  dropoff?: {
    location: string;
  };
  passengers: number;
  luggage?: number;
  notes?: string;
  price: number;
  gratuity?: number;
  company?: string;
  eventType?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Customer {
  initials: string;
  avatarColor: string;
  id: string;
  name: string;
  email: string;
  phone: string;
  type: 'corporate' | 'personal' | 'recurring';
  totalSpent: number;
  rides: number;
  lastRide: string;
  memberSince: string;
  tags: string[];
  avatar?: string;
  notes: Note[];
  bookings: string[];
  preferences?: string[];
}

export interface Note {
  id: string;
  content: string;
  createdAt: string;
  createdBy: string;
}

export interface KPIData {
  label: string;
  value: string;
  change: string;
  changeType: 'positive' | 'negative' | 'neutral';
  icon: string;
  iconBg: string;
}

export interface ActivityItem {
  id: string;
  icon: string;
  iconColor: string;
  iconBg: string;
  description: string;
  timestamp: string;
}

export interface TopClient {
  id: string;
  name: string;
  initials: string;
  totalSpent: string;
  rides: number;
  avatarColor: string;
}

export interface ChartDataPoint {
  date: string;
  revenue: number;
}

// KPI Cards Data
export const kpiData: KPIData[] = [
  {
    label: 'Total Revenue',
    value: '$12,450',
    change: '12%',
    changeType: 'positive',
    icon: 'Wallet',
    iconBg: 'rgba(212,168,83,0.1)',
  },
  {
    label: 'This Month',
    value: '$3,280',
    change: '8%',
    changeType: 'positive',
    icon: 'Calendar',
    iconBg: 'rgba(34,197,94,0.1)',
  },
  {
    label: 'Active Bookings',
    value: '7',
    change: '',
    changeType: 'neutral',
    icon: 'CalendarCheck',
    iconBg: 'rgba(59,130,246,0.1)',
  },
  {
    label: 'Total Rides',
    value: '245',
    change: '23%',
    changeType: 'positive',
    icon: 'Car',
    iconBg: 'rgba(139,92,246,0.1)',
  },
];

// Revenue Chart Data (30 days)
export const revenueChartData30D: ChartDataPoint[] = [
  { date: 'Feb 10', revenue: 120 },
  { date: 'Feb 11', revenue: 85 },
  { date: 'Feb 12', revenue: 0 },
  { date: 'Feb 13', revenue: 190 },
  { date: 'Feb 14', revenue: 245 },
  { date: 'Feb 15', revenue: 160 },
  { date: 'Feb 16', revenue: 95 },
  { date: 'Feb 17', revenue: 0 },
  { date: 'Feb 18', revenue: 180 },
  { date: 'Feb 19', revenue: 210 },
  { date: 'Feb 20', revenue: 150 },
  { date: 'Feb 21', revenue: 85 },
  { date: 'Feb 22', revenue: 230 },
  { date: 'Feb 23', revenue: 175 },
  { date: 'Feb 24', revenue: 0 },
  { date: 'Feb 25', revenue: 145 },
  { date: 'Feb 26', revenue: 200 },
  { date: 'Feb 27', revenue: 110 },
  { date: 'Feb 28', revenue: 95 },
  { date: 'Mar 1', revenue: 180 },
  { date: 'Mar 2', revenue: 250 },
  { date: 'Mar 3', revenue: 0 },
  { date: 'Mar 4', revenue: 165 },
  { date: 'Mar 5', revenue: 210 },
  { date: 'Mar 6', revenue: 145 },
  { date: 'Mar 7', revenue: 85 },
  { date: 'Mar 8', revenue: 220 },
  { date: 'Mar 9', revenue: 190 },
  { date: 'Mar 10', revenue: 155 },
  { date: 'Mar 11', revenue: 240 },
];

// Revenue Chart Data (7 days)
export const revenueChartData7D: ChartDataPoint[] = [
  { date: 'Mar 5', revenue: 210 },
  { date: 'Mar 6', revenue: 145 },
  { date: 'Mar 7', revenue: 85 },
  { date: 'Mar 8', revenue: 220 },
  { date: 'Mar 9', revenue: 190 },
  { date: 'Mar 10', revenue: 155 },
  { date: 'Mar 11', revenue: 240 },
];

// Revenue Chart Data (3 months - weekly)
export const revenueChartData3M: ChartDataPoint[] = [
  { date: 'Week 1', revenue: 850 },
  { date: 'Week 2', revenue: 1120 },
  { date: 'Week 3', revenue: 780 },
  { date: 'Week 4', revenue: 1350 },
  { date: 'Week 5', revenue: 980 },
  { date: 'Week 6', revenue: 1450 },
  { date: 'Week 7', revenue: 1100 },
  { date: 'Week 8', revenue: 1580 },
  { date: 'Week 9', revenue: 1220 },
  { date: 'Week 10', revenue: 1680 },
  { date: 'Week 11', revenue: 890 },
  { date: 'Week 12', revenue: 1420 },
];

// Revenue Chart Data (1 year - monthly)
export const revenueChartData1Y: ChartDataPoint[] = [
  { date: 'Apr', revenue: 4200 },
  { date: 'May', revenue: 5100 },
  { date: 'Jun', revenue: 4800 },
  { date: 'Jul', revenue: 6200 },
  { date: 'Aug', revenue: 5900 },
  { date: 'Sep', revenue: 7100 },
  { date: 'Oct', revenue: 7800 },
  { date: 'Nov', revenue: 6500 },
  { date: 'Dec', revenue: 9200 },
  { date: 'Jan', revenue: 8400 },
  { date: 'Feb', revenue: 9800 },
  { date: 'Mar', revenue: 11200 },
];

// Upcoming Bookings (Overview page)
export const upcomingBookings = [
  {
    id: 'DL-0345',
    time: 'Today, 3:00 PM',
    client: 'Thomas R.',
    service: 'Corporate Event',
    pickup: '200 Peachtree St',
    price: '$360',
    status: 'confirmed' as const,
  },
  {
    id: 'DL-0344',
    time: 'Tomorrow, 8:00 AM',
    client: 'Jennifer K.',
    service: 'Airport Transfer',
    pickup: '450 Ponce de Leon',
    price: '$85',
    status: 'confirmed' as const,
  },
  {
    id: 'DL-0343',
    time: 'Mar 14, 10:00 AM',
    client: 'Michael S.',
    service: 'Hourly Charter',
    pickup: 'Westin Buckhead',
    price: '$285',
    status: 'accepted' as const,
  },
  {
    id: 'DL-0350',
    time: 'Mar 15, 2:00 PM',
    client: 'Amanda L.',
    service: 'Airport Transfer',
    pickup: '789 Piedmont Ave',
    price: '$85',
    status: 'new' as const,
  },
  {
    id: 'DL-0347',
    time: 'Mar 16, 9:00 AM',
    client: 'Robert C.',
    service: 'Point-to-Point',
    pickup: 'Lenox Square',
    price: '$65',
    status: 'confirmed' as const,
  },
];

// Activity Feed
export const activityFeed: ActivityItem[] = [
  {
    id: '1',
    icon: 'CheckCircle',
    iconColor: '#22C55E',
    iconBg: 'rgba(34,197,94,0.1)',
    description: 'Booking DL-0345 completed',
    timestamp: '2 hours ago',
  },
  {
    id: '2',
    icon: 'UserPlus',
    iconColor: '#3B82F6',
    iconBg: 'rgba(59,130,246,0.1)',
    description: 'New client: Sarah M. added to CRM',
    timestamp: '5 hours ago',
  },
  {
    id: '3',
    icon: 'CreditCard',
    iconColor: '#D4A853',
    iconBg: 'rgba(212,168,83,0.1)',
    description: 'Payout of $2,840 processed',
    timestamp: '1 day ago',
  },
  {
    id: '4',
    icon: 'Star',
    iconColor: '#D4A853',
    iconBg: 'rgba(212,168,83,0.1)',
    description: 'New 5-star review from David L.',
    timestamp: '2 days ago',
  },
  {
    id: '5',
    icon: 'Calendar',
    iconColor: '#3B82F6',
    iconBg: 'rgba(59,130,246,0.1)',
    description: 'Booking DL-0348 rescheduled',
    timestamp: '2 days ago',
  },
];

// Top Clients
export const topClients: TopClient[] = [
  { id: '1', name: 'Thomas R.', initials: 'TR', totalSpent: '$4,250', rides: 28, avatarColor: '#D4A853' },
  { id: '2', name: 'Jennifer K.', initials: 'JK', totalSpent: '$2,180', rides: 15, avatarColor: '#3B82F6' },
  { id: '3', name: 'Michael S.', initials: 'MS', totalSpent: '$1,920', rides: 12, avatarColor: '#22C55E' },
  { id: '4', name: 'Amanda L.', initials: 'AL', totalSpent: '$1,450', rides: 9, avatarColor: '#8B5CF6' },
];

// Quick Actions
export const quickActions = [
  { icon: 'Plus', label: 'New Service' },
  { icon: 'UserPlus', label: 'Add Client' },
  { icon: 'CalendarPlus', label: 'Add Booking' },
  { icon: 'FileText', label: 'View Reports' },
  { icon: 'Settings', label: 'Edit Storefront' },
  { icon: 'HelpCircle', label: 'Get Help' },
];

// Bookings (full list for Bookings page)
export const bookings: Booking[] = [
  {
    id: 'DL-0350',
    customer: { name: 'Amanda L.', email: 'amanda@email.com', phone: '(678) 555-0156' },
    service: { name: 'Airport Transfer', icon: 'Plane' },
    status: 'new',
    pickup: { location: '789 Piedmont Ave', date: 'Mar 15, 2025', time: '2:00 PM' },
    dropoff: { location: 'ATL Airport' },
    passengers: 1,
    price: 85,
    createdAt: '2025-03-11T10:00:00Z',
    updatedAt: '2025-03-11T10:00:00Z',
  },
  {
    id: 'DL-0349',
    customer: { name: 'David C.', email: 'david@tech.com', phone: '(404) 555-0134' },
    service: { name: 'Hourly Charter', icon: 'Clock' },
    status: 'new',
    pickup: { location: 'Midtown Atlanta', date: 'Mar 14, 2025', time: '11:00 AM' },
    passengers: 2,
    price: 190,
    createdAt: '2025-03-10T14:30:00Z',
    updatedAt: '2025-03-10T14:30:00Z',
  },
  {
    id: 'DL-0348',
    customer: { name: 'Lisa W.', email: 'lisa@email.com', phone: '(770) 555-0134' },
    service: { name: 'Point-to-Point', icon: 'MapPin' },
    status: 'new',
    pickup: { location: 'Buckhead', date: 'Mar 13, 2025', time: '4:00 PM' },
    dropoff: { location: 'Downtown Atlanta' },
    passengers: 1,
    price: 65,
    createdAt: '2025-03-09T09:00:00Z',
    updatedAt: '2025-03-09T09:00:00Z',
  },
  {
    id: 'DL-0347',
    customer: { name: 'Robert C.', email: 'robert@email.com', phone: '(404) 555-0178' },
    service: { name: 'Point-to-Point', icon: 'MapPin' },
    status: 'accepted',
    pickup: { location: 'Lenox Square', date: 'Mar 16, 2025', time: '9:00 AM' },
    dropoff: { location: 'Hartsfield-Jackson ATL' },
    passengers: 2,
    price: 65,
    createdAt: '2025-03-08T11:00:00Z',
    updatedAt: '2025-03-10T16:00:00Z',
  },
  {
    id: 'DL-0346',
    customer: { name: 'Karen M.', email: 'karen@legal.com', phone: '(404) 555-0198' },
    service: { name: 'Airport Transfer', icon: 'Plane' },
    status: 'accepted',
    pickup: { location: '123 Peachtree St', date: 'Mar 17, 2025', time: '6:00 AM' },
    dropoff: { location: 'ATL Airport' },
    passengers: 1,
    luggage: 2,
    price: 85,
    createdAt: '2025-03-07T08:00:00Z',
    updatedAt: '2025-03-09T10:00:00Z',
  },
  {
    id: 'DL-0345',
    customer: { name: 'Thomas R.', email: 'thomas@company.com', phone: '(404) 555-0123' },
    service: { name: 'Corporate Event', icon: 'Briefcase' },
    status: 'confirmed',
    pickup: { location: '200 Peachtree St', date: 'Mar 12, 2025', time: '3:00 PM' },
    passengers: 4,
    price: 360,
    gratuity: 72,
    company: 'Meridian Consulting LLC',
    eventType: 'Client Meeting',
    notes: 'Please arrive 15 min early. Client is VIP.',
    createdAt: '2025-03-05T09:00:00Z',
    updatedAt: '2025-03-08T14:00:00Z',
  },
  {
    id: 'DL-0344',
    customer: { name: 'Jennifer K.', email: 'jennifer@email.com', phone: '(404) 555-0199' },
    service: { name: 'Airport Transfer', icon: 'Plane' },
    status: 'confirmed',
    pickup: { location: '450 Ponce de Leon', date: 'Mar 13, 2025', time: '8:00 AM' },
    dropoff: { location: 'ATL Airport - Domestic Terminal' },
    passengers: 2,
    luggage: 3,
    price: 85,
    createdAt: '2025-03-04T10:00:00Z',
    updatedAt: '2025-03-07T12:00:00Z',
  },
  {
    id: 'DL-0343',
    customer: { name: 'Michael S.', email: 'michael@firm.com', phone: '(678) 555-0145' },
    service: { name: 'Hourly Charter', icon: 'Clock' },
    status: 'accepted',
    pickup: { location: 'Westin Buckhead', date: 'Mar 14, 2025', time: '10:00 AM' },
    passengers: 3,
    price: 285,
    notes: 'Multiple stops for business meetings.',
    createdAt: '2025-03-03T11:00:00Z',
    updatedAt: '2025-03-06T15:00:00Z',
  },
  {
    id: 'DL-0342',
    customer: { name: 'Steve D.', email: 'steve@email.com', phone: '(678) 555-0112' },
    service: { name: 'Airport Transfer', icon: 'Plane' },
    status: 'in_progress',
    pickup: { location: '567 Collier Rd', date: 'Mar 11, 2025', time: '7:00 PM' },
    dropoff: { location: 'ATL Airport' },
    passengers: 1,
    price: 85,
    createdAt: '2025-03-01T10:00:00Z',
    updatedAt: '2025-03-11T19:05:00Z',
  },
  {
    id: 'DL-0341',
    customer: { name: 'Nancy P.', email: 'nancy@email.com', phone: '(404) 555-0167' },
    service: { name: 'Hourly Charter', icon: 'Clock' },
    status: 'completed',
    pickup: { location: 'Four Seasons Atlanta', date: 'Mar 11, 2025', time: '2:00 PM' },
    passengers: 2,
    price: 475,
    createdAt: '2025-02-28T09:00:00Z',
    updatedAt: '2025-03-11T18:00:00Z',
  },
  {
    id: 'DL-0340',
    customer: { name: 'James L.', email: 'james@email.com', phone: '(770) 555-0156' },
    service: { name: 'Airport Transfer', icon: 'Plane' },
    status: 'completed',
    pickup: { location: '890 Northside Dr', date: 'Mar 10, 2025', time: '5:00 AM' },
    dropoff: { location: 'ATL Airport' },
    passengers: 2,
    luggage: 4,
    price: 85,
    createdAt: '2025-02-27T10:00:00Z',
    updatedAt: '2025-03-10T07:00:00Z',
  },
  {
    id: 'DL-0339',
    customer: { name: 'Rachel G.', email: 'rachel@email.com', phone: '(404) 555-0189' },
    service: { name: 'Point-to-Point', icon: 'MapPin' },
    status: 'completed',
    pickup: { location: 'Atlantic Station', date: 'Mar 9, 2025', time: '12:00 PM' },
    dropoff: { location: 'Midtown' },
    passengers: 1,
    price: 65,
    createdAt: '2025-02-26T14:00:00Z',
    updatedAt: '2025-03-09T13:00:00Z',
  },
  {
    id: 'DL-0338',
    customer: { name: 'Brian T.', email: 'brian@email.com', phone: '(678) 555-0123' },
    service: { name: 'Corporate Event', icon: 'Briefcase' },
    status: 'completed',
    pickup: { location: 'Georgia Tech', date: 'Mar 8, 2025', time: '9:00 AM' },
    passengers: 6,
    price: 480,
    company: 'TechCorp Inc.',
    eventType: 'Conference',
    createdAt: '2025-02-25T10:00:00Z',
    updatedAt: '2025-03-08T15:00:00Z',
  },
  {
    id: 'DL-0337',
    customer: { name: 'Olivia H.', email: 'olivia@email.com', phone: '(404) 555-0176' },
    service: { name: 'Airport Transfer', icon: 'Plane' },
    status: 'canceled',
    pickup: { location: '234 14th St', date: 'Mar 7, 2025', time: '3:00 PM' },
    dropoff: { location: 'ATL Airport' },
    passengers: 1,
    price: 85,
    createdAt: '2025-02-24T09:00:00Z',
    updatedAt: '2025-03-06T10:00:00Z',
  },
  {
    id: 'DL-0336',
    customer: { name: 'Kevin B.', email: 'kevin@email.com', phone: '(770) 555-0190' },
    service: { name: 'Hourly Charter', icon: 'Clock' },
    status: 'completed',
    pickup: { location: 'Downtown Atlanta', date: 'Mar 6, 2025', time: '11:00 AM' },
    passengers: 2,
    price: 95,
    createdAt: '2025-02-23T11:00:00Z',
    updatedAt: '2025-03-06T14:00:00Z',
  },
  {
    id: 'DL-0335',
    customer: { name: 'Sarah M.', email: 'sarah@email.com', phone: '(404) 555-0145' },
    service: { name: 'VIP Service', icon: 'Star' },
    status: 'confirmed',
    pickup: { location: 'The St. Regis Atlanta', date: 'Mar 18, 2025', time: '7:00 PM' },
    passengers: 2,
    price: 350,
    notes: 'Anniversary dinner transportation.',
    createdAt: '2025-03-01T10:00:00Z',
    updatedAt: '2025-03-05T12:00:00Z',
  },
  {
    id: 'DL-0334',
    customer: { name: 'William P.', email: 'william@email.com', phone: '(678) 555-0167' },
    service: { name: 'Airport Transfer', icon: 'Plane' },
    status: 'completed',
    pickup: { location: 'Buckhead', date: 'Mar 5, 2025', time: '6:30 AM' },
    dropoff: { location: 'ATL Airport' },
    passengers: 1,
    price: 85,
    createdAt: '2025-02-22T09:00:00Z',
    updatedAt: '2025-03-05T09:00:00Z',
  },
  {
    id: 'DL-0333',
    customer: { name: 'Emma D.', email: 'emma@email.com', phone: '(404) 555-0180' },
    service: { name: 'Hourly Charter', icon: 'Clock' },
    status: 'canceled',
    pickup: { location: 'Sandy Springs', date: 'Mar 4, 2025', time: '1:00 PM' },
    passengers: 3,
    price: 150,
    createdAt: '2025-02-21T10:00:00Z',
    updatedAt: '2025-03-03T11:00:00Z',
  },
  {
    id: 'DL-0332',
    customer: { name: 'Daniel R.', email: 'daniel@email.com', phone: '(770) 555-0129' },
    service: { name: 'Point-to-Point', icon: 'MapPin' },
    status: 'completed',
    pickup: { location: 'Decatur', date: 'Mar 3, 2025', time: '4:30 PM' },
    dropoff: { location: 'Virginia Highlands' },
    passengers: 2,
    price: 75,
    createdAt: '2025-02-20T14:00:00Z',
    updatedAt: '2025-03-03T18:00:00Z',
  },
  {
    id: 'DL-0331',
    customer: { name: 'Grace H.', email: 'grace@email.com', phone: '(404) 555-0155' },
    service: { name: 'Corporate Event', icon: 'Briefcase' },
    status: 'confirmed',
    pickup: { location: 'Piedmont Hospital', date: 'Mar 19, 2025', time: '10:00 AM' },
    passengers: 8,
    price: 520,
    company: 'Healthcare Partners',
    eventType: 'Board Meeting',
    createdAt: '2025-02-28T09:00:00Z',
    updatedAt: '2025-03-02T16:00:00Z',
  },
  {
    id: 'DL-0330',
    customer: { name: 'Alex T.', email: 'alex@email.com', phone: '(678) 555-0188' },
    service: { name: 'Airport Transfer', icon: 'Plane' },
    status: 'completed',
    pickup: { location: 'Vinings', date: 'Mar 2, 2025', time: '8:00 AM' },
    dropoff: { location: 'ATL Airport' },
    passengers: 1,
    price: 85,
    createdAt: '2025-02-19T10:00:00Z',
    updatedAt: '2025-03-02T10:00:00Z',
  },
  {
    id: 'DL-0329',
    customer: { name: 'Michelle L.', email: 'michelle@email.com', phone: '(404) 555-0133' },
    service: { name: 'Senior Transport', icon: 'Heart' },
    status: 'completed',
    pickup: { location: 'Brookhaven', date: 'Mar 1, 2025', time: '2:00 PM' },
    passengers: 1,
    price: 55,
    notes: 'Assistance needed with walker.',
    createdAt: '2025-02-18T09:00:00Z',
    updatedAt: '2025-03-01T15:00:00Z',
  },
  {
    id: 'DL-0328',
    customer: { name: 'Chris W.', email: 'chris@email.com', phone: '(770) 555-0166' },
    service: { name: 'Hourly Charter', icon: 'Clock' },
    status: 'canceled',
    pickup: { location: 'Alpharetta', date: 'Feb 28, 2025', time: '9:00 AM' },
    passengers: 4,
    price: 220,
    createdAt: '2025-02-17T11:00:00Z',
    updatedAt: '2025-02-27T10:00:00Z',
  },
  {
    id: 'DL-0327',
    customer: { name: 'Patricia N.', email: 'patricia@email.com', phone: '(404) 555-0191' },
    service: { name: 'Airport Transfer', icon: 'Plane' },
    status: 'completed',
    pickup: { location: 'Dunwoody', date: 'Feb 27, 2025', time: '5:00 PM' },
    dropoff: { location: 'ATL Airport' },
    passengers: 2,
    price: 85,
    createdAt: '2025-02-16T10:00:00Z',
    updatedAt: '2025-02-27T19:00:00Z',
  },
];

// Customers (CRM)
export const customers: Customer[] = [
  {
    id: 'c1',
    name: 'Thomas R.',
    email: 'thomas@company.com',
    phone: '(404) 555-0123',
    type: 'corporate',
    totalSpent: 4250,
    rides: 28,
    lastRide: 'Mar 12',
    memberSince: 'Jan 2023',
    tags: ['VIP', 'Corporate', 'Recurring'],
    initials: 'TR',
    avatarColor: '#D4A853',
    preferences: ['Prefers front passenger seat', 'No strong scents', 'Always has 2 bags'],
    notes: [
      { id: 'n1', content: 'Prefers to be picked up at the front entrance, not the loading dock.', createdAt: 'Mar 1, 2025', createdBy: 'You' },
      { id: 'n2', content: 'Corporate account — invoices go to accounting@meridian.com', createdAt: 'Jan 15, 2025', createdBy: 'You' },
      { id: 'n3', content: 'VIP client — always arrive 10 min early.', createdAt: 'Nov 3, 2024', createdBy: 'You' },
      { id: 'n4', content: 'Allergic to lavender air fresheners.', createdAt: 'Sep 12, 2024', createdBy: 'You' },
    ],
    bookings: ['DL-0345', 'DL-0330', 'DL-0320'],
  },
  {
    id: 'c2',
    name: 'Jennifer K.',
    email: 'jennifer@email.com',
    phone: '(404) 555-0199',
    type: 'personal',
    totalSpent: 2180,
    rides: 15,
    lastRide: 'Mar 13',
    memberSince: 'Mar 2023',
    tags: ['Airport', 'Recurring'],
    initials: 'JK',
    avatarColor: '#3B82F6',
    notes: [
      { id: 'n5', content: 'Frequent airport runs — prefers early morning pickups.', createdAt: 'Feb 20, 2025', createdBy: 'You' },
    ],
    bookings: ['DL-0344', 'DL-0325'],
  },
  {
    id: 'c3',
    name: 'Michael S.',
    email: 'michael@firm.com',
    phone: '(678) 555-0145',
    type: 'corporate',
    totalSpent: 1920,
    rides: 12,
    lastRide: 'Mar 14',
    memberSince: 'Jun 2023',
    tags: ['Corporate', 'Hourly'],
    initials: 'MS',
    avatarColor: '#22C55E',
    notes: [],
    bookings: ['DL-0343'],
  },
  {
    id: 'c4',
    name: 'Amanda L.',
    email: 'amanda@email.com',
    phone: '(678) 555-0156',
    type: 'personal',
    totalSpent: 1450,
    rides: 9,
    lastRide: 'Mar 9',
    memberSince: 'Aug 2023',
    tags: ['Family'],
    initials: 'AL',
    avatarColor: '#8B5CF6',
    notes: [
      { id: 'n6', content: 'Travels with young children — needs car seat.', createdAt: 'Jan 10, 2025', createdBy: 'You' },
    ],
    bookings: ['DL-0350'],
  },
  {
    id: 'c5',
    name: 'David C.',
    email: 'david@tech.com',
    phone: '(404) 555-0134',
    type: 'corporate',
    totalSpent: 1280,
    rides: 8,
    lastRide: 'Mar 8',
    memberSince: 'Oct 2023',
    tags: ['VIP', 'Corporate'],
    initials: 'DC',
    avatarColor: '#EF4444',
    notes: [],
    bookings: ['DL-0349'],
  },
  {
    id: 'c6',
    name: 'Lisa W.',
    email: 'lisa@email.com',
    phone: '(770) 555-0134',
    type: 'personal',
    totalSpent: 980,
    rides: 6,
    lastRide: 'Mar 5',
    memberSince: 'Nov 2023',
    tags: ['Senior Care'],
    initials: 'LW',
    avatarColor: '#F59E0B',
    notes: [],
    bookings: ['DL-0348'],
  },
  {
    id: 'c7',
    name: 'Robert C.',
    email: 'robert@email.com',
    phone: '(404) 555-0178',
    type: 'recurring',
    totalSpent: 3640,
    rides: 22,
    lastRide: 'Mar 11',
    memberSince: 'Feb 2023',
    tags: ['VIP', 'Recurring'],
    initials: 'RC',
    avatarColor: '#14B8A6',
    notes: [
      { id: 'n7', content: 'Weekly shopping trips on Tuesdays.', createdAt: 'Mar 1, 2025', createdBy: 'You' },
    ],
    bookings: ['DL-0347'],
  },
  {
    id: 'c8',
    name: 'Karen M.',
    email: 'karen@legal.com',
    phone: '(404) 555-0198',
    type: 'corporate',
    totalSpent: 2750,
    rides: 18,
    lastRide: 'Feb 28',
    memberSince: 'Apr 2023',
    tags: ['Corporate'],
    initials: 'KM',
    avatarColor: '#EC4899',
    notes: [],
    bookings: ['DL-0346'],
  },
  {
    id: 'c9',
    name: 'Steve D.',
    email: 'steve@email.com',
    phone: '(678) 555-0112',
    type: 'personal',
    totalSpent: 720,
    rides: 5,
    lastRide: 'Mar 4',
    memberSince: 'Dec 2023',
    tags: ['Airport'],
    initials: 'SD',
    avatarColor: '#6366F1',
    notes: [],
    bookings: ['DL-0342'],
  },
  {
    id: 'c10',
    name: 'Nancy P.',
    email: 'nancy@email.com',
    phone: '(404) 555-0167',
    type: 'recurring',
    totalSpent: 4180,
    rides: 26,
    lastRide: 'Mar 11',
    memberSince: 'Jan 2023',
    tags: ['VIP', 'Recurring'],
    initials: 'NP',
    avatarColor: '#A855F7',
    preferences: ['Prefers bottled water in car', 'Likes classical music'],
    notes: [
      { id: 'n8', content: 'Long-time client — very particular about cleanliness.', createdAt: 'Feb 15, 2025', createdBy: 'You' },
    ],
    bookings: ['DL-0341'],
  },
];

// CRM Stats
export const crmStats = [
  { label: 'Total Clients', value: 34, icon: 'Users', color: '#D4A853' },
  { label: 'Corporate', value: 12, icon: 'Briefcase', color: '#3B82F6' },
  { label: 'Recurring', value: 18, icon: 'RotateCcw', color: '#22C55E' },
  { label: 'This Month', value: 5, icon: 'UserPlus', color: '#8B5CF6' },
];

// Status config
export const statusConfig: Record<string, { color: string; bg: string; label: string }> = {
  new: { color: '#3B82F6', bg: 'rgba(59,130,246,0.1)', label: 'New' },
  accepted: { color: '#F59E0B', bg: 'rgba(245,158,11,0.1)', label: 'Accepted' },
  confirmed: { color: '#22C55E', bg: 'rgba(34,197,94,0.1)', label: 'Confirmed' },
  in_progress: { color: '#8B5CF6', bg: 'rgba(139,92,246,0.1)', label: 'In Progress' },
  completed: { color: '#10B981', bg: 'rgba(16,185,129,0.1)', label: 'Completed' },
  canceled: { color: '#EF4444', bg: 'rgba(239,68,68,0.1)', label: 'Canceled' },
};

// Customer type config
export const customerTypeConfig: Record<string, { color: string; bg: string; label: string }> = {
  corporate: { color: '#3B82F6', bg: 'rgba(59,130,246,0.1)', label: 'Corporate' },
  personal: { color: '#8A8A96', bg: 'rgba(138,138,150,0.1)', label: 'Personal' },
  recurring: { color: '#22C55E', bg: 'rgba(34,197,94,0.1)', label: 'Recurring' },
};
