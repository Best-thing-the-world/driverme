import { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Link } from 'react-router-dom'
import {
  User, Mail, Phone, MapPin, Car, Clock, Plane, Briefcase, Crown, Heart,
  Check, X, ChevronLeft, ChevronRight, CheckCircle, Eye, EyeOff,
} from 'lucide-react'

/* ─────────────────────── animation helpers ─────────────────────── */

const easeSmooth = [0.4, 0, 0.2, 1] as [number, number, number, number]
const easeEnter = [0, 0, 0.2, 1] as [number, number, number, number]

const easeBounce = [0.34, 1.56, 0.64, 1] as [number, number, number, number]

/* ─────────────────────── types ─────────────────────── */

interface FormData {
  fullName: string
  email: string
  phone: string
  city: string
  bio: string
  vehicleMake: string
  vehicleModel: string
  vehicleYear: string
  vehicleColor: string
  passengerCapacity: string
  selectedServices: { id: string; price: string; unit: string }[]
  plan: 'starter' | 'pro' | 'premier'
  isAnnual: boolean
  password: string
  confirmPassword: string
  agreedToTerms: boolean
}

/* ─────────────────────── initial data ─────────────────────── */

const initialForm: FormData = {
  fullName: '',
  email: '',
  phone: '',
  city: '',
  bio: '',
  vehicleMake: '',
  vehicleModel: '',
  vehicleYear: '',
  vehicleColor: '',
  passengerCapacity: '4',
  selectedServices: [],
  plan: 'pro',
  isAnnual: false,
  password: '',
  confirmPassword: '',
  agreedToTerms: false,
}

const availableServices = [
  { id: 'airport', icon: Plane, name: 'Airport Transfer', description: 'Door-to-door airport rides', suggested: '$75-$95', defaultUnit: 'ride' },
  { id: 'hourly', icon: Clock, name: 'Hourly Charter', description: 'Flexible time-based service', suggested: '$75-$95/hr', defaultUnit: 'hour' },
  { id: 'pointtopoint', icon: MapPin, name: 'Point-to-Point', description: 'Direct A-to-B rides', suggested: '$50-$75', defaultUnit: 'ride' },
  { id: 'corporate', icon: Briefcase, name: 'Corporate Event', description: 'Business event transport', suggested: '$85-$125/hr', defaultUnit: 'hour' },
  { id: 'vip', icon: Crown, name: 'VIP Service', description: 'Premium white-glove service', suggested: '$125-$200/hr', defaultUnit: 'hour' },
  { id: 'senior', icon: Heart, name: 'Senior Transport', description: 'Safe senior care rides', suggested: '$45-$65/hr', defaultUnit: 'hour' },
]

const vehicleFeatureSuggestions = [
  'Leather Interior', 'Climate Control', 'WiFi', 'Phone Chargers', 'Bottled Water', 'Premium Sound', 'Tinted Windows',
]

const _planPrices = { starter: 49, pro: 99, premier: 199 }
const _planAnnualPrices = { starter: 39, pro: 79, premier: 159 }

/* ─────────────────────── password strength ─────────────────────── */

function getPasswordStrength(pw: string): { score: number; checks: { label: string; pass: boolean }[] } {
  const checks = [
    { label: 'At least 8 characters', pass: pw.length >= 8 },
    { label: 'One uppercase letter', pass: /[A-Z]/.test(pw) },
    { label: 'One number', pass: /\d/.test(pw) },
    { label: 'One special character', pass: /[^A-Za-z0-9]/.test(pw) },
  ]
  const score = checks.filter((c) => c.pass).length
  return { score, checks }
}

function strengthColor(score: number): string {
  if (score === 0) return '#2A2A35'
  if (score === 1) return '#EF4444'
  if (score === 2) return '#F59E0B'
  if (score === 3) return '#3B82F6'
  return '#22C55E'
}

/* ─────────────────────── main component ─────────────────────── */

export default function Register() {
  const [step, setStep] = useState(1)
  const [form, setForm] = useState<FormData>(initialForm)
  const [isComplete, setIsComplete] = useState(false)
  const [vehicleFeatures, setVehicleFeatures] = useState<string[]>([])
  const [featureInput, setFeatureInput] = useState('')
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [direction, setDirection] = useState(1)
  const _fileInputRef = useRef<HTMLInputElement>(null)

  const totalSteps = 4

  const update = (field: keyof FormData, value: unknown) => {
    setForm((prev) => ({ ...prev, [field]: value }))
    setErrors((prev) => ({ ...prev, [field]: '' }))
  }

  const validateStep = (s: number): boolean => {
    const e: Record<string, string> = {}
    if (s === 1) {
      if (!form.fullName.trim()) e.fullName = 'Full name is required'
      if (!form.email.trim()) e.email = 'Email is required'
      else if (!/^\S+@\S+\.\S+$/.test(form.email)) e.email = 'Invalid email format'
      if (!form.phone.trim()) e.phone = 'Phone is required'
      if (!form.city.trim()) e.city = 'City is required'
    }
    if (s === 2) {
      if (!form.vehicleMake.trim()) e.vehicleMake = 'Make is required'
      if (!form.vehicleModel.trim()) e.vehicleModel = 'Model is required'
      if (!form.vehicleYear.trim()) e.vehicleYear = 'Year is required'
    }
    if (s === 3) {
      if (form.selectedServices.length === 0) e.services = 'Select at least one service'
    }
    if (s === 4) {
      const strength = getPasswordStrength(form.password)
      if (strength.score < 3) e.password = 'Password is too weak'
      if (form.password !== form.confirmPassword) e.confirmPassword = 'Passwords do not match'
      if (!form.agreedToTerms) e.terms = 'You must agree to the terms'
    }
    setErrors(e)
    return Object.keys(e).length === 0
  }

  const nextStep = () => {
    if (!validateStep(step)) return
    if (step < totalSteps) {
      setDirection(1)
      setStep(step + 1)
    }
  }

  const prevStep = () => {
    if (step > 1) {
      setDirection(-1)
      setStep(step - 1)
    }
  }

  const handleSubmit = async () => {
    if (!validateStep(step)) return
    setIsComplete(true)
  }

  const toggleService = (serviceId: string) => {
    const exists = form.selectedServices.find((s) => s.id === serviceId)
    if (exists) {
      update(
        'selectedServices',
        form.selectedServices.filter((s) => s.id !== serviceId)
      )
    } else {
      const svc = availableServices.find((s) => s.id === serviceId)
      update('selectedServices', [
        ...form.selectedServices,
        { id: serviceId, price: '', unit: svc?.defaultUnit || 'ride' },
      ])
    }
    setErrors((prev) => ({ ...prev, services: '' }))
  }

  const updateServicePrice = (serviceId: string, price: string) => {
    update(
      'selectedServices',
      form.selectedServices.map((s) => (s.id === serviceId ? { ...s, price } : s))
    )
  }

  const updateServiceUnit = (serviceId: string, unit: string) => {
    update(
      'selectedServices',
      form.selectedServices.map((s) => (s.id === serviceId ? { ...s, unit } : s))
    )
  }

  const addFeature = (feat?: string) => {
    const val = feat !== undefined ? feat : featureInput
    if (val.trim() && !vehicleFeatures.includes(val.trim())) {
      setVehicleFeatures([...vehicleFeatures, val.trim()])
      if (!feat) setFeatureInput('')
    }
  }

  const removeFeature = (f: string) => {
    setVehicleFeatures(vehicleFeatures.filter((v) => v !== f))
  }

  /* ── completion state ── */
  if (isComplete) {
    return <CompletionState form={form} />
  }

  return (
    <div className="min-h-[100dvh] bg-[#0A0A0F] flex">
      {/* ── Left decorative panel ── */}
      <div className="hidden lg:flex lg:w-1/2 relative flex-col items-center justify-center">
        <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: 'url(/hero-bg.jpg)' }} />
        <div className="absolute inset-0 bg-gradient-to-br from-[rgba(10,10,15,0.7)] to-[rgba(10,10,15,0.95)]" />
        <div className="relative z-10 flex flex-col items-center text-center px-12">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[linear-gradient(135deg,#D4A853_0%,#E8C87A_50%,#D4A853_100%)] flex items-center justify-center">
              <span className="font-display font-bold text-[#0A0A0F] text-lg leading-none">DL</span>
            </div>
            <span className="font-display text-2xl font-semibold text-[#F0EDE8]">DriverLink</span>
          </div>
          <p className="text-[#8A8A96] text-lg mt-4 max-w-sm">
            The platform for independent chauffeurs.
          </p>
        </div>
      </div>

      {/* ── Right side: wizard ── */}
      <div className="flex-1 flex items-center justify-center px-6 py-12">
        <div className="w-full max-w-[560px] bg-[#141419] border border-[#2A2A35] rounded-2xl shadow-[0_20px_60px_rgba(0,0,0,0.3)] overflow-hidden">
          {/* Progress bar */}
          <div className="h-1 bg-[#1E1E26]">
            <motion.div
              animate={{ width: `${(step / totalSteps) * 100}%` }}
              transition={{ duration: 0.3, ease: easeSmooth }}
              className="h-full bg-[#D4A853]"
            />
          </div>

          <div className="p-8 md:p-10">
            {/* Step indicator */}
            <div className="text-center mb-6">
              <p className="text-xs text-[#5A5A66]">
                Step {step} of {totalSteps}
              </p>
              <div className="flex items-center justify-center gap-2 mt-3">
                {Array.from({ length: totalSteps }).map((_, i) => (
                  <div
                    key={i}
                    className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                      i + 1 <= step ? 'bg-[#D4A853]' : 'bg-[#2A2A35]'
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Form content */}
            <AnimatePresence mode="wait" initial={false}>
              <motion.div
                key={step}
                initial={{ opacity: 0, x: direction * 30 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: direction * -30 }}
                transition={{ duration: 0.4, ease: easeSmooth }}
              >
                {step === 1 && (
                  <Step1Personal
                    form={form}
                    update={update}
                    errors={errors}
                  />
                )}
                {step === 2 && (
                  <Step2Vehicle
                    form={form}
                    update={update}
                    errors={errors}
                    vehicleFeatures={vehicleFeatures}
                    setVehicleFeatures={setVehicleFeatures}
                    featureInput={featureInput}
                    setFeatureInput={setFeatureInput}
                    addFeature={addFeature}
                    removeFeature={removeFeature}
                    suggestions={vehicleFeatureSuggestions}
                  />
                )}
                {step === 3 && (
                  <Step3Services
                    form={form}
                    toggleService={toggleService}
                    updateServicePrice={updateServicePrice}
                    updateServiceUnit={updateServiceUnit}
                    errors={errors}
                  />
                )}
                {step === 4 && (
                  <Step4Account
                    form={form}
                    update={update}
                    errors={errors}
                  />
                )}
              </motion.div>
            </AnimatePresence>

            {/* Navigation */}
            <div className="flex items-center justify-between mt-8 pt-6 border-t border-[#2A2A35]">
              <button
                onClick={prevStep}
                disabled={step === 1}
                className={`flex items-center gap-1 px-4 py-2.5 rounded-full text-sm font-medium transition-all duration-200 ${
                  step === 1
                    ? 'text-[#5A5A66] cursor-not-allowed'
                    : 'text-[#F0EDE8] border border-[#2A2A35] hover:bg-[#1E1E26]'
                }`}
              >
                <ChevronLeft size={16} />
                Back
              </button>

              {step < totalSteps ? (
                <button
                  onClick={nextStep}
                  className="flex items-center gap-1 px-6 py-2.5 rounded-full text-sm font-semibold text-[#0A0A0F] bg-[linear-gradient(135deg,#D4A853_0%,#E8C87A_50%,#D4A853_100%)] hover:scale-[1.02] transition-all duration-200"
                >
                  Continue
                  <ChevronRight size={16} />
                </button>
              ) : (
                <button
                  onClick={handleSubmit}
                  className="flex items-center gap-1 px-6 py-2.5 rounded-full text-sm font-semibold text-[#0A0A0F] bg-[linear-gradient(135deg,#D4A853_0%,#E8C87A_50%,#D4A853_100%)] hover:scale-[1.02] transition-all duration-200"
                >
                  Complete Setup
                  <Check size={16} />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

/* ─────────────────────── step 1: personal ─────────────────────── */

function Step1Personal({
  form,
  update,
  errors,
}: {
  form: FormData
  update: (f: keyof FormData, v: unknown) => void
  errors: Record<string, string>
}) {
  return (
    <div>
      <h2 className="text-2xl font-bold text-[#F0EDE8] text-center">
        Let&apos;s Get to Know You
      </h2>
      <p className="text-sm text-[#8A8A96] text-center mt-2">
        Tell us about yourself. This information appears on your public storefront.
      </p>

      <div className="mt-6 flex flex-col gap-4">
        <FormInput
          icon={<User size={18} />}
          placeholder="Your full name"
          value={form.fullName}
          onChange={(v) => update('fullName', v)}
          error={errors.fullName}
        />
        <FormInput
          icon={<Mail size={18} />}
          placeholder="you@example.com"
          type="email"
          value={form.email}
          onChange={(v) => update('email', v)}
          error={errors.email}
        />
        <FormInput
          icon={<Phone size={18} />}
          placeholder="(555) 000-0000"
          type="tel"
          value={form.phone}
          onChange={(v) => {
            // Auto-format as (XXX) XXX-XXXX
            const raw = v.replace(/\D/g, '').slice(0, 10)
            let formatted = raw
            if (raw.length >= 6) formatted = `(${raw.slice(0, 3)}) ${raw.slice(3, 6)}-${raw.slice(6)}`
            else if (raw.length >= 3) formatted = `(${raw.slice(0, 3)}) ${raw.slice(3)}`
            update('phone', formatted)
          }}
          error={errors.phone}
        />
        <FormInput
          icon={<MapPin size={18} />}
          placeholder="e.g., Atlanta, GA"
          value={form.city}
          onChange={(v) => update('city', v)}
          error={errors.city}
        />

        {/* Bio */}
        <div>
          <textarea
            value={form.bio}
            onChange={(e) => {
              if (e.target.value.length <= 500) update('bio', e.target.value)
            }}
            placeholder="Tell clients about your experience, professionalism, and what makes you unique..."
            rows={4}
            className="w-full bg-[#1E1E26] border border-[#2A2A35] rounded-lg p-4 text-sm text-[#F0EDE8] placeholder:text-[#5A5A66] focus:outline-none focus:border-[#D4A853] focus:ring-[3px] focus:ring-[rgba(212,168,83,0.15)] transition-all duration-200 resize-none"
          />
          <p className="text-xs text-[#5A5A66] text-right mt-1">
            {form.bio.length}/500
          </p>
        </div>
      </div>
    </div>
  )
}

/* ─────────────────────── step 2: vehicle ─────────────────────── */

function Step2Vehicle({
  form,
  update,
  errors,
  vehicleFeatures,
  setVehicleFeatures,
  featureInput,
  setFeatureInput,
  addFeature,
  removeFeature,
  suggestions,
}: {
  form: FormData
  update: (f: keyof FormData, v: unknown) => void
  errors: Record<string, string>
  vehicleFeatures: string[]
  setVehicleFeatures: React.Dispatch<React.SetStateAction<string[]>>
  featureInput: string
  setFeatureInput: (v: string) => void
  addFeature: (feat?: string) => void
  removeFeature: (f: string) => void
  suggestions: string[]
}) {
  const unusedSuggestions = suggestions.filter((s) => !vehicleFeatures.includes(s))

  return (
    <div>
      <h2 className="text-2xl font-bold text-[#F0EDE8] text-center">Your Vehicle</h2>
      <p className="text-sm text-[#8A8A96] text-center mt-2">
        Clients want to know what they&apos;ll be riding in. Show off your vehicle.
      </p>

      <div className="mt-6 flex flex-col gap-4">
        <FormInput
          icon={<Car size={18} />}
          placeholder="e.g., Cadillac"
          label="Vehicle Make"
          value={form.vehicleMake}
          onChange={(v) => update('vehicleMake', v)}
          error={errors.vehicleMake}
        />
        <FormInput
          placeholder="e.g., Escalade"
          label="Vehicle Model"
          value={form.vehicleModel}
          onChange={(v) => update('vehicleModel', v)}
          error={errors.vehicleModel}
        />
        <div className="grid grid-cols-2 gap-4">
          <FormInput
            placeholder="2023"
            type="number"
            label="Year"
            value={form.vehicleYear}
            onChange={(v) => update('vehicleYear', v)}
            error={errors.vehicleYear}
            min={1990}
            max={2025}
          />
          <FormInput
            placeholder="e.g., Black"
            label="Color"
            value={form.vehicleColor}
            onChange={(v) => update('vehicleColor', v)}
          />
        </div>
        <div>
          <label className="text-xs text-[#5A5A66] uppercase tracking-wider">Passenger Capacity</label>
          <select
            value={form.passengerCapacity}
            onChange={(e) => update('passengerCapacity', e.target.value)}
            className="w-full mt-1 bg-[#1E1E26] border border-[#2A2A35] rounded-lg py-3 px-4 text-sm text-[#F0EDE8] focus:outline-none focus:border-[#D4A853] transition-all duration-200"
          >
            {Array.from({ length: 12 }).map((_, i) => (
              <option key={i + 1} value={i + 1}>
                {i + 1} {i === 0 ? 'passenger' : 'passengers'}
              </option>
            ))}
          </select>
        </div>

        {/* Vehicle features tag input */}
        <div>
          <label className="text-xs text-[#5A5A66] uppercase tracking-wider">Vehicle Features</label>
          <div className="flex gap-2 mt-1">
            <input
              value={featureInput}
              onChange={(e) => setFeatureInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addFeature() } }}
              placeholder="Type and press Enter"
              className="flex-1 bg-[#1E1E26] border border-[#2A2A35] rounded-lg py-3 px-4 text-sm text-[#F0EDE8] placeholder:text-[#5A5A66] focus:outline-none focus:border-[#D4A853] transition-all duration-200"
            />
            <button
              onClick={() => addFeature()}
              className="px-4 py-2.5 rounded-lg bg-[#1E1E26] border border-[#2A2A35] text-[#D4A853] hover:bg-[rgba(212,168,83,0.1)] transition-all"
            >
              Add
            </button>
          </div>
          {/* Suggestions */}
          {unusedSuggestions.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-2">
              {unusedSuggestions.map((s) => (
                <button
                  key={s}
                  onClick={() => addFeature(s)}
                  className="text-xs px-3 py-1 rounded-full bg-[#1E1E26] text-[#8A8A96] border border-[#2A2A35] hover:border-[#D4A853] hover:text-[#D4A853] transition-all"
                >
                  + {s}
                </button>
              ))}
            </div>
          )}
          {/* Tags */}
          {vehicleFeatures.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-3">
              {vehicleFeatures.map((f) => (
                <span
                  key={f}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-[rgba(212,168,83,0.1)] text-[#D4A853] text-xs border border-[rgba(212,168,83,0.2)]"
                >
                  {f}
                  <button onClick={() => removeFeature(f)} className="hover:text-[#EF4444]">
                    <X size={12} />
                  </button>
                </span>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

/* ─────────────────────── step 3: services ─────────────────────── */

function Step3Services({
  form,
  toggleService,
  updateServicePrice,
  updateServiceUnit,
  errors,
}: {
  form: FormData
  toggleService: (id: string) => void
  updateServicePrice: (id: string, price: string) => void
  updateServiceUnit: (id: string, unit: string) => void
  errors: Record<string, string>
}) {
  return (
    <div>
      <h2 className="text-2xl font-bold text-[#F0EDE8] text-center">Set Up Your Services</h2>
      <p className="text-sm text-[#8A8A96] text-center mt-2">
        Choose the services you want to offer and set your prices. You can always add more later.
      </p>

      {errors.services && (
        <p className="text-sm text-[#EF4444] text-center mt-3">{errors.services}</p>
      )}

      <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-3">
        {availableServices.map((service) => {
          const Icon = service.icon
          const selected = form.selectedServices.find((s) => s.id === service.id)
          const isSelected = !!selected

          return (
            <div key={service.id}>
              <button
                onClick={() => toggleService(service.id)}
                className={`w-full text-left p-4 rounded-xl border transition-all duration-300 relative ${
                  isSelected
                    ? 'border-[#D4A853] bg-[rgba(212,168,83,0.05)] shadow-[0_0_20px_rgba(212,168,83,0.08)]'
                    : 'border-[#2A2A35] bg-[#1E1E26] hover:border-[rgba(212,168,83,0.3)]'
                }`}
              >
                {isSelected && (
                  <div className="absolute top-2 right-2 w-5 h-5 rounded-full bg-[#D4A853] flex items-center justify-center">
                    <Check size={12} className="text-[#0A0A0F]" />
                  </div>
                )}
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    isSelected ? 'bg-[rgba(212,168,83,0.1)]' : 'bg-[#252530]'
                  }`}>
                    <Icon size={20} className={isSelected ? 'text-[#D4A853]' : 'text-[#8A8A96]'} />
                  </div>
                  <div>
                    <p className={`text-sm font-semibold ${isSelected ? 'text-[#F0EDE8]' : 'text-[#8A8A96]'}`}>
                      {service.name}
                    </p>
                    <p className="text-xs text-[#5A5A66]">{service.description}</p>
                  </div>
                </div>
              </button>

              {/* Price input when selected */}
              <AnimatePresence>
                {isSelected && selected && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3, ease: easeSmooth }}
                    className="overflow-hidden"
                  >
                    <div className="px-4 pb-4 pt-2 bg-[rgba(212,168,83,0.03)] rounded-b-xl border border-t-0 border-[#D4A853] -mt-2">
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-[#8A8A96]">Your price: $</span>
                        <input
                          type="number"
                          value={selected.price}
                          onChange={(e) => updateServicePrice(service.id, e.target.value)}
                          placeholder="0"
                          className="w-20 bg-[#1E1E26] border border-[#2A2A35] rounded-md py-1.5 px-2 text-sm text-[#F0EDE8] focus:outline-none focus:border-[#D4A853]"
                        />
                        <select
                          value={selected.unit}
                          onChange={(e) => updateServiceUnit(service.id, e.target.value)}
                          className="bg-[#1E1E26] border border-[#2A2A35] rounded-md py-1.5 px-2 text-sm text-[#F0EDE8] focus:outline-none"
                        >
                          <option value="ride">/ride</option>
                          <option value="hour">/hour</option>
                          <option value="mile">/mile</option>
                        </select>
                      </div>
                      <p className="text-xs text-[#5A5A66] mt-1">
                        Suggested: {service.suggested}
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )
        })}
      </div>
    </div>
  )
}

/* ─────────────────────── step 4: account ─────────────────────── */

function Step4Account({
  form,
  update,
  errors,
}: {
  form: FormData
  update: (f: keyof FormData, v: unknown) => void
  errors: Record<string, string>
}) {
  const [showPassword, setShowPassword] = useState(false)
  const strength = getPasswordStrength(form.password)

  const plans = [
    { id: 'starter' as const, name: 'Starter', price: 49, annualPrice: 39 },
    { id: 'pro' as const, name: 'Professional', price: 99, annualPrice: 79, highlight: true },
    { id: 'premier' as const, name: 'Premier', price: 199, annualPrice: 159 },
  ]

  return (
    <div>
      <h2 className="text-2xl font-bold text-[#F0EDE8] text-center">Create Your Account</h2>
      <p className="text-sm text-[#8A8A96] text-center mt-2">
        Choose your plan and set up your login credentials.
      </p>

      {/* Plan selection */}
      <div className="mt-6">
        {/* Billing toggle */}
        <div className="flex items-center justify-center gap-3 mb-4">
          <span className={`text-xs ${!form.isAnnual ? 'text-[#F0EDE8] font-semibold' : 'text-[#5A5A66]'}`}>Monthly</span>
          <button
            onClick={() => update('isAnnual', !form.isAnnual)}
            className="relative w-10 h-5 rounded-full bg-[#1E1E26] border border-[#2A2A35]"
          >
            <motion.div
              animate={{ x: form.isAnnual ? 20 : 2 }}
              transition={{ duration: 0.2 }}
              className="absolute top-0.5 w-4 h-4 rounded-full bg-[#D4A853]"
            />
          </button>
          <span className={`text-xs ${form.isAnnual ? 'text-[#F0EDE8] font-semibold' : 'text-[#5A5A66]'}`}>Annually</span>
          {form.isAnnual && <span className="text-xs text-[#22C55E]">Save 20%</span>}
        </div>

        <div className="grid grid-cols-3 gap-3">
          {plans.map((p) => {
            const isSelected = form.plan === p.id
            const displayPrice = form.isAnnual ? p.annualPrice : p.price
            return (
              <button
                key={p.id}
                onClick={() => update('plan', p.id)}
                className={`p-3 rounded-xl border text-center transition-all duration-300 ${
                  isSelected
                    ? p.highlight
                      ? 'border-[#D4A853] bg-[rgba(212,168,83,0.05)] shadow-gold-sm'
                      : 'border-[#D4A853] bg-[rgba(212,168,83,0.05)]'
                    : 'border-[#2A2A35] bg-[#1E1E26] hover:border-[rgba(212,168,83,0.3)]'
                }`}
              >
                <p className={`text-xs font-semibold ${isSelected ? 'text-[#F0EDE8]' : 'text-[#8A8A96]'}`}>
                  {p.name}
                </p>
                <p className="text-lg font-mono font-bold text-[#D4A853] mt-1">
                  ${displayPrice}
                </p>
                <p className="text-[10px] text-[#5A5A66]">/mo</p>
              </button>
            )
          })}
        </div>
      </div>

      {/* Password */}
      <div className="mt-6 flex flex-col gap-4">
        <div>
          <label className="text-xs text-[#5A5A66] uppercase tracking-wider">Password</label>
          <div className="relative mt-1">
            <div className="absolute left-3 top-1/2 -translate-y-1/2 text-[#5A5A66]">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#5A5A66" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
            </div>
            <input
              type={showPassword ? 'text' : 'password'}
              value={form.password}
              onChange={(e) => update('password', e.target.value)}
              placeholder="••••••••"
              className={`w-full bg-[#1E1E26] border rounded-lg py-3 pl-10 pr-10 text-sm text-[#F0EDE8] placeholder:text-[#5A5A66] focus:outline-none focus:ring-[3px] transition-all duration-200 ${
                errors.password ? 'border-[#EF4444]' : 'border-[#2A2A35] focus:border-[#D4A853] focus:ring-[rgba(212,168,83,0.15)]'
              }`}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-[#5A5A66] hover:text-[#8A8A96]"
            >
              {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
            </button>
          </div>

          {/* Strength bar */}
          <div className="flex gap-1 mt-2">
            {[1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className="flex-1 h-1 rounded-full transition-colors duration-300"
                style={{ backgroundColor: i <= strength.score ? strengthColor(strength.score) : '#2A2A35' }}
              />
            ))}
          </div>

          {/* Requirements checklist */}
          <div className="flex flex-col gap-1 mt-2">
            {strength.checks.map((c) => (
              <div key={c.label} className="flex items-center gap-2">
                {c.pass ? (
                  <Check size={12} className="text-[#22C55E]" />
                ) : (
                  <X size={12} className="text-[#5A5A66]" />
                )}
                <span className={`text-xs ${c.pass ? 'text-[#22C55E]' : 'text-[#5A5A66]'}`}>
                  {c.label}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Confirm password */}
        <div>
          <label className="text-xs text-[#5A5A66] uppercase tracking-wider">Confirm Password</label>
          <div className="relative mt-1">
            <div className="absolute left-3 top-1/2 -translate-y-1/2 text-[#5A5A66]">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#5A5A66" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
            </div>
            <input
              type="password"
              value={form.confirmPassword}
              onChange={(e) => update('confirmPassword', e.target.value)}
              placeholder="••••••••"
              className={`w-full bg-[#1E1E26] border rounded-lg py-3 pl-10 pr-4 text-sm text-[#F0EDE8] placeholder:text-[#5A5A66] focus:outline-none focus:ring-[3px] transition-all duration-200 ${
                errors.confirmPassword ? 'border-[#EF4444]' : 'border-[#2A2A35] focus:border-[#D4A853] focus:ring-[rgba(212,168,83,0.15)]'
              }`}
            />
          </div>
          {errors.confirmPassword && (
            <p className="text-xs text-[#EF4444] mt-1">{errors.confirmPassword}</p>
          )}
        </div>

        {/* Terms */}
        <div>
          <label className="flex items-start gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={form.agreedToTerms}
              onChange={(e) => update('agreedToTerms', e.target.checked)}
              className="w-4 h-4 mt-0.5 rounded border-[#2A2A35] bg-[#1E1E26] accent-[#D4A853] cursor-pointer"
            />
            <span className="text-sm text-[#8A8A96]">
              I agree to the{' '}
              <span className="text-[#D4A853] cursor-pointer hover:underline">Terms of Service</span>
              {' '}and{' '}
              <span className="text-[#D4A853] cursor-pointer hover:underline">Privacy Policy</span>
            </span>
          </label>
          {errors.terms && (
            <p className="text-xs text-[#EF4444] mt-1">{errors.terms}</p>
          )}
        </div>
      </div>
    </div>
  )
}

/* ─────────────────────── completion state ─────────────────────── */

function CompletionState({ form }: { form: FormData }) {
  const [visibleItems, setVisibleItems] = useState(0)

  const items = [
    { icon: 'check' as const, text: 'Your account has been created' },
    { icon: 'check' as const, text: 'Your storefront is now live' },
    { icon: 'spinner' as const, text: 'We\'re reviewing your profile (usually within 24 hours)' },
    { icon: 'clock' as const, text: 'Start receiving bookings' },
  ]

  useEffect(() => {
    const timers: ReturnType<typeof setTimeout>[] = []
    items.forEach((_, i) => {
      timers.push(setTimeout(() => setVisibleItems(i + 1), i * 500))
    })
    timers.push(setTimeout(() => setVisibleItems(4), 3500))
    return () => timers.forEach(clearTimeout)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <div className="min-h-[100dvh] bg-[#0A0A0F] flex items-center justify-center px-6">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, ease: easeEnter }}
        className="w-full max-w-[480px] bg-[#141419] border border-[#2A2A35] rounded-2xl p-10 text-center shadow-[0_20px_60px_rgba(0,0,0,0.3)]"
      >
        <div className="w-16 h-16 rounded-full bg-[rgba(212,168,83,0.1)] flex items-center justify-center mx-auto">
          <CheckCircle size={32} className="text-[#D4A853]" />
        </div>
        <h2 className="text-2xl font-bold text-[#F0EDE8] mt-4">
          Welcome to DriverLink!
        </h2>
        <p className="text-sm text-[#8A8A96] mt-2">
          Your storefront is live. Here&apos;s what happens next:
        </p>

        {/* Checklist */}
        <div className="mt-8 flex flex-col gap-4 text-left">
          {items.map((item, i) => {
            const isVisible = i < visibleItems
            const isChecked = item.icon === 'spinner' && visibleItems >= 4 ? true : item.icon === 'check'

            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={isVisible ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.4, ease: easeEnter }}
                className="flex items-center gap-3"
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={isVisible ? { scale: 1 } : {}}
                  transition={{ duration: 0.3, ease: easeBounce }}
                >
                  {item.icon === 'check' || (item.icon === 'spinner' && visibleItems >= 4) ? (
                    <div className="w-6 h-6 rounded-full bg-[rgba(34,197,94,0.1)] flex items-center justify-center">
                      <Check size={14} className="text-[#22C55E]" />
                    </div>
                  ) : item.icon === 'spinner' ? (
                    <div className="w-6 h-6 rounded-full bg-[rgba(245,158,11,0.1)] flex items-center justify-center">
                      <LoadingSpinnerSmall />
                    </div>
                  ) : (
                    <div className="w-6 h-6 rounded-full bg-[#2A2A35] flex items-center justify-center">
                      <Clock size={14} className="text-[#5A5A66]" />
                    </div>
                  )}
                </motion.div>
                <span className={`text-sm ${isChecked ? 'text-[#F0EDE8]' : 'text-[#8A8A96]'}`}>
                  {item.text}
                </span>
              </motion.div>
            )
          })}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2, duration: 0.5 }}
          className="mt-8"
        >
          <Link
            to="/dashboard"
            className="inline-block px-8 py-3 rounded-full text-sm font-semibold text-[#0A0A0F] bg-[linear-gradient(135deg,#D4A853_0%,#E8C87A_50%,#D4A853_100%)] hover:scale-[1.02] transition-all duration-200"
          >
            Go to Dashboard
          </Link>
          <p className="text-xs text-[#5A5A66] mt-4">
            Your storefront URL: driverlink.co/drivers/\
            {form.fullName.toLowerCase().replace(/\s+/g, '-') || 'you'}
          </p>
        </motion.div>
      </motion.div>
    </div>
  )
}

/* ─────────────────────── reusable components ─────────────────────── */

function FormInput({
  icon,
  placeholder,
  value,
  onChange,
  type = 'text',
  error,
  label,
  min,
  max,
}: {
  icon?: React.ReactNode
  placeholder: string
  value: string
  onChange: (v: string) => void
  type?: string
  error?: string
  label?: string
  min?: number
  max?: number
}) {
  return (
    <div>
      {label && (
        <label className="text-xs text-[#5A5A66] uppercase tracking-wider mb-1 block">
          {label}
        </label>
      )}
      <div className="relative">
        {icon && (
          <div className="absolute left-3 top-1/2 -translate-y-1/2 text-[#5A5A66]">
            {icon}
          </div>
        )}
        <input
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          min={min}
          max={max}
          className={`w-full bg-[#1E1E26] border rounded-lg py-3 ${icon ? 'pl-10' : 'pl-4'} pr-4 text-sm text-[#F0EDE8] placeholder:text-[#5A5A66] focus:outline-none focus:ring-[3px] transition-all duration-200 ${
            error
              ? 'border-[#EF4444] focus:ring-[rgba(239,68,68,0.15)]'
              : 'border-[#2A2A35] focus:border-[#D4A853] focus:ring-[rgba(212,168,83,0.15)]'
          }`}
        />
      </div>
      {error && <p className="text-xs text-[#EF4444] mt-1">{error}</p>}
    </div>
  )
}

function LockCustom() {
  return <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#5A5A66" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
}

function LoadingSpinnerSmall() {
  return (
    <svg className="animate-spin h-3 w-3 text-[#F59E0B]" viewBox="0 0 24 24">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
    </svg>
  )
}
