import { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { ArrowRight, Zap } from 'lucide-react'

function WaitlistModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [email, setEmail] = useState('')
  const [submitted, setSubmitted] = useState(false)

  if (!open) return null

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (email.trim()) setSubmitted(true)
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
      <div
        className="relative bg-[#141419] border border-[#2A2A35] rounded-2xl w-full max-w-md p-8 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {submitted ? (
          <div className="text-center py-4">
            <div className="w-14 h-14 rounded-full bg-emerald-500/10 flex items-center justify-center mx-auto mb-4">
              <Zap className="w-6 h-6 text-emerald-400" />
            </div>
            <h3 className="font-display text-xl font-bold text-[#F0EDE8] mb-2">You're on the list!</h3>
            <p className="text-sm text-[#8A8A96]">
              We'll be in touch soon with early access. Founding members get 50% off for life.
            </p>
            <button
              onClick={onClose}
              className="mt-6 px-6 py-2.5 rounded-full text-sm font-semibold bg-gold text-[#0A0A0F] hover:scale-[1.03] transition-transform"
            >
              Got it
            </button>
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-display text-xl font-bold text-[#F0EDE8]">Join the Waitlist</h3>
              <button onClick={onClose} className="text-[#5A5A66] hover:text-[#F0EDE8] transition-colors">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
              </button>
            </div>
            <p className="text-sm text-[#8A8A96] mb-6">
              Be the first to get access. Founding members receive <span className="text-gold font-semibold">50% off for life</span>.
            </p>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  required
                  className="w-full h-12 px-4 rounded-xl bg-[#0A0A0F] border border-[#2A2A35] text-[#F0EDE8] placeholder:text-[#5A5A66] text-sm focus:outline-none focus:border-gold/50 focus:ring-1 focus:ring-gold/20 transition-all"
                />
              </div>
              <button
                type="submit"
                className="w-full h-12 rounded-xl text-sm font-semibold text-[#0A0A0F] bg-gold-shine hover:shadow-[0_4px_24px_rgba(212,168,83,0.3)] transition-all duration-200"
              >
                Secure My Spot
              </button>
            </form>
            <p className="text-xs text-[#5A5A66] mt-4 text-center">
              847 drivers already joined. Limited to 1,000 founding members.
            </p>
          </>
        )}
      </div>
    </div>
  )
}

export default function HeroSection() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const [modalOpen, setModalOpen] = useState(false)

  useEffect(() => {
    const section = sectionRef.current
    if (!section) return
    const els = section.querySelectorAll('.animate-in')
    els.forEach((el, i) => {
      const htmlEl = el as HTMLElement
      htmlEl.style.opacity = '0'
      htmlEl.style.transform = 'translateY(30px)'
      htmlEl.style.transition = `opacity 0.6s ease, transform 0.6s ease`
      const delays = [0.2, 0.4, 0.6, 0.8, 1.0]
      setTimeout(() => {
        htmlEl.style.opacity = '1'
        htmlEl.style.transform = 'translateY(0)'
      }, (delays[i] || 0.4) * 1000)
    })
  }, [])

  return (
    <>
      <WaitlistModal open={modalOpen} onClose={() => setModalOpen(false)} />
      <section ref={sectionRef} className="relative min-h-[100dvh] flex items-end overflow-hidden">
        {/* Background Image with Ken Burns */}
        <div className="absolute inset-0 animate-ken-burns">
          <img
            src="/hero-bg.jpg"
            alt="Luxury vehicle"
            className="w-full h-full object-cover object-center"
          />
        </div>

        {/* Hero Overlay Gradient */}
        <div className="absolute inset-0 bg-hero-overlay" />

        {/* Gold Particle Overlay */}
        <div
          className="absolute inset-0 animate-float pointer-events-none"
          style={{
            backgroundImage: 'url(/gold-particle-texture.png)',
            backgroundSize: 'cover',
            opacity: 0.15,
          }}
        />

        {/* Content */}
        <div className="relative z-10 max-w-[1280px] mx-auto w-full px-6 pb-[120px]">
          <div className="max-w-[700px]">
            {/* Waitlist Badge */}
            <div className="animate-in mb-6">
              <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-gold/10 border border-gold/20 text-xs font-medium text-gold tracking-wide">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-gold opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-gold" />
                </span>
                Launching Summer 2026 — 153 spots left
              </span>
            </div>

            {/* Eyebrow */}
            <p className="animate-in text-xs font-medium tracking-[0.2em] text-gold uppercase mb-6">
              The Platform for Independent Chauffeurs
            </p>

            {/* Headline */}
            <h1 className="animate-in font-display text-4xl sm:text-5xl lg:text-[4.5rem] font-bold leading-[1.0] tracking-[-0.02em] text-[#F0EDE8] mb-6">
              <span className="block">Your Business.</span>
              <span className="block">Your Brand. Your Rules.</span>
            </h1>

            {/* Subheadline */}
            <p className="animate-in text-lg leading-relaxed text-[#8A8A96] max-w-[560px] mb-8">
              DriverLink gives independent chauffeurs everything they need — a branded booking storefront, CRM, earnings dashboard, and professional tools — all in one platform.
            </p>

            {/* CTA Row */}
            <div className="animate-in flex flex-wrap items-center gap-4 mb-8">
              <button
                onClick={() => setModalOpen(true)}
                className="inline-flex items-center gap-2 px-8 h-[52px] rounded-full text-sm font-semibold text-[#0A0A0F] bg-gold-shine hover:scale-[1.03] hover:shadow-[0_4px_24px_rgba(212,168,83,0.3)] transition-all duration-200 group cursor-pointer"
              >
                Join the Waitlist — 50% Off for Life
                <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </button>
              <Link
                to="/features"
                className="inline-flex items-center gap-2 px-6 h-[52px] rounded-full text-sm font-semibold text-gold border border-gold hover:bg-[rgba(212,168,83,0.1)] transition-all duration-200"
              >
                See How It Works
              </Link>
            </div>

            {/* Trust Bar — Updated */}
            <div className="animate-in flex flex-wrap items-center gap-4 sm:gap-6 text-xs text-[#5A5A66]">
              <span className="flex items-center gap-1.5">
                <svg className="w-3.5 h-3.5 text-emerald-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20 6L9 17l-5-5"/></svg>
                847 drivers waitlisted
              </span>
              <span className="hidden sm:inline text-[#2A2A35]">|</span>
              <span>$74.5B market opportunity</span>
              <span className="hidden sm:inline text-[#2A2A35]">|</span>
              <span>No credit card required</span>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
