import { useEffect, useRef, useState } from 'react'
import { Zap, ArrowRight } from 'lucide-react'

function WaitlistModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [email, setEmail] = useState('')
  const [submitted, setSubmitted] = useState(false)

  if (!open) return null

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (email.trim()) setSubmitted(true)
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
      <div
        className="relative bg-[#141419] border border-[#2A2A35] rounded-2xl w-full max-w-md p-8 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {submitted ? (
          <div className="text-center py-4">
            <div className="w-14 h-14 rounded-full bg-emerald-500/10 flex items-center justify-center mx-auto mb-4">
              <Zap className="w-6 h-6 text-emerald-400" />
            </div>
            <h3 className="font-display text-xl font-bold text-[#F0EDE8] mb-2">You're on the list!</h3>
            <p className="text-sm text-[#8A8A96]">
              We'll be in touch soon with early access. Founding members get 50% off for life.
            </p>
            <button
              onClick={onClose}
              className="mt-6 px-6 py-2.5 rounded-full text-sm font-semibold bg-gold text-[#0A0A0F] hover:scale-[1.03] transition-transform"
            >
              Got it
            </button>
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-display text-xl font-bold text-[#F0EDE8]">Join the Waitlist</h3>
              <button onClick={onClose} className="text-[#5A5A66] hover:text-[#F0EDE8] transition-colors">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
              </button>
            </div>
            <p className="text-sm text-[#8A8A96] mb-6">
              Be the first to get access. Founding members receive <span className="text-gold font-semibold">50% off for life</span>.
            </p>
            <form onSubmit={handleSubmit} className="space-y-4">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                required
                className="w-full h-12 px-4 rounded-xl bg-[#0A0A0F] border border-[#2A2A35] text-[#F0EDE8] placeholder:text-[#5A5A66] text-sm focus:outline-none focus:border-gold/50 focus:ring-1 focus:ring-gold/20 transition-all"
              />
              <button
                type="submit"
                className="w-full h-12 rounded-xl text-sm font-semibold text-[#0A0A0F] bg-gold-shine hover:shadow-[0_4px_24px_rgba(212,168,83,0.3)] transition-all duration-200"
              >
                Secure My Spot
              </button>
            </form>
            <p className="text-xs text-[#5A5A66] mt-4 text-center">
              847 drivers already joined. Limited to 1,000 founding members.
            </p>
          </>
        )}
      </div>
    </div>
  )
}

export default function CTASection() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const [modalOpen, setModalOpen] = useState(false)

  useEffect(() => {
    const section = sectionRef.current
    if (!section) return
    const els = section.querySelectorAll('.cta-animate')
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const el = entry.target as HTMLElement
            el.style.opacity = '1'
            el.style.transform = 'translateY(0)'
            observer.unobserve(entry.target)
          }
        })
      },
      { threshold: 0.15 }
    )
    els.forEach((el) => observer.observe(el))
    return () => observer.disconnect()
  }, [])

  return (
    <>
      <WaitlistModal open={modalOpen} onClose={() => setModalOpen(false)} />
      <section
        ref={sectionRef}
        className="py-24 bg-gradient-to-b from-[#0A0A0F] to-[#141419] relative overflow-hidden"
      >
        {/* Gold Glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] rounded-full bg-gold/8 blur-[100px] animate-pulse-glow pointer-events-none" />

        <div className="max-w-[1280px] mx-auto px-6 text-center relative z-10">
          <h2
            className="cta-animate font-display text-3xl sm:text-4xl lg:text-[3.5rem] font-bold text-[#F0EDE8] leading-[1.05] tracking-[-0.02em] mb-6 transition-all duration-700"
            style={{ opacity: 0, transform: 'translateY(30px)' }}
          >
            Don't Let Platforms Take Your Profits
          </h2>
          <p
            className="cta-animate text-lg text-[#8A8A96] mb-4 max-w-[560px] mx-auto transition-all duration-700"
            style={{ opacity: 0, transform: 'translateY(20px)', transitionDelay: '0.15s' }}
          >
            Uber takes 40%+. You keep 100% with DriverLink. Join 847 drivers securing their spot.
          </p>
          <p
            className="cta-animate text-sm text-gold mb-8 transition-all duration-700"
            style={{ opacity: 0, transform: 'translateY(20px)', transitionDelay: '0.2s' }}
          >
            Only 153 founding member spots remaining
          </p>
          <div
            className="cta-animate transition-all duration-700"
            style={{ opacity: 0, transform: 'translateY(15px)', transitionDelay: '0.3s' }}
          >
            <button
              onClick={() => setModalOpen(true)}
              className="inline-flex items-center gap-2 px-10 h-14 rounded-full text-base font-semibold text-[#0A0A0F] bg-gold-shine hover:scale-[1.03] hover:shadow-[0_4px_24px_rgba(212,168,83,0.3)] transition-all duration-200 cursor-pointer"
            >
              Join the Waitlist
              <ArrowRight size={18} />
            </button>
            <p className="text-xs text-[#5A5A66] mt-4">
              No credit card required. Cancel anytime.
            </p>
          </div>
        </div>
      </section>
    </>
  )
}
