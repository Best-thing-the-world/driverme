import { useEffect, useRef, useState, useCallback } from 'react'

interface StatData {
  prefix: string
  suffix: string
  numericValue: number
  decimals: number
  label: string
}

const stats: StatData[] = [
  { prefix: '$', suffix: 'B', numericValue: 74.5, decimals: 1, label: 'Global Chauffeur Market' },
  { prefix: '3-', suffix: 'x', numericValue: 7, decimals: 0, label: 'More Than Gig Platforms' },
  { prefix: '', suffix: ',000+', numericValue: 35, decimals: 0, label: 'Independent Drivers in the US' },
  { prefix: '', suffix: '%', numericValue: 70, decimals: 0, label: 'Run Fewer Than 5 Vehicles' },
]

function AnimatedNumber({ target, decimals, started }: { target: number; decimals: number; started: boolean }) {
  const [value, setValue] = useState(0)
  const rafRef = useRef<number>(0)
  const startRef = useRef<number>(0)

  const animate = useCallback(
    (timestamp: number) => {
      if (!startRef.current) startRef.current = timestamp
      const progress = Math.min((timestamp - startRef.current) / 1500, 1)
      const eased = 1 - Math.pow(1 - progress, 3)
      setValue(eased * target)
      if (progress < 1) {
        rafRef.current = requestAnimationFrame(animate)
      }
    },
    [target]
  )

  useEffect(() => {
    if (!started) return
    startRef.current = 0
    rafRef.current = requestAnimationFrame(animate)
    return () => cancelAnimationFrame(rafRef.current)
  }, [started, animate])

  const formatted = decimals > 0 ? value.toFixed(decimals) : Math.round(value).toString()

  return <>{formatted}</>
}

export default function StatsBarSection() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const [started, setStarted] = useState(false)
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setStarted(true)
          setTimeout(() => setVisible(true), 100)
          observer.disconnect()
        }
      },
      { threshold: 0.15 }
    )
    if (sectionRef.current) observer.observe(sectionRef.current)
    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} className="bg-[#0D0D12] py-16 border-y border-[#2A2A35]">
      <div className="max-w-[1280px] mx-auto px-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {stats.map((stat, i) => (
            <div
              key={stat.label}
              className={`flex flex-col items-center text-center transition-all duration-700 ${
                visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${i * 150}ms` }}
            >
              <span className="font-mono text-3xl lg:text-[2.5rem] font-bold text-[#D4A853] tabular-nums">
                {stat.prefix}
                <AnimatedNumber
                  target={stat.numericValue}
                  decimals={stat.decimals}
                  started={started}
                />
                {stat.suffix}
              </span>
              <span className="text-xs text-[#5A5A66] mt-2 tracking-wide uppercase">
                {stat.label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
