import { useEffect, useRef } from 'react'
import { Link } from 'react-router-dom'
import { Check } from 'lucide-react'

interface PricingTier {
  name: string
  price: number
  description: string
  features: string[]
  highlighted?: boolean
  cta: string
  ctaLink: string
  ctaStyle: 'primary' | 'secondary'
}

const tiers: PricingTier[] = [
  {
    name: 'Starter',
    price: 49,
    description: 'Perfect for getting started',
    features: [
      'Branded storefront page',
      'Up to 5 active services',
      'Booking management',
      'Basic CRM (25 clients)',
      'Earnings summary',
      'Email notifications',
      'Community support',
    ],
    highlighted: false,
    cta: 'Join Waitlist',
    ctaLink: '/register',
    ctaStyle: 'secondary',
  },
  {
    name: 'Professional',
    price: 99,
    description: 'Most popular choice',
    features: [
      'Unlimited services',
      'Advanced CRM (unlimited clients)',
      'Custom booking fields',
      'Recurring bookings',
      'Priority support',
      'Analytics dashboard',
      'Client reviews & ratings',
    ],
    highlighted: true,
    cta: 'Join Waitlist',
    ctaLink: '/register',
    ctaStyle: 'primary',
  },
  {
    name: 'Premier',
    price: 199,
    description: 'For scaling businesses',
    features: [
      'White-label domain',
      'Custom branding & colors',
      'API access',
      'Multi-vehicle support',
      'Team management',
      'Dedicated account manager',
      'Early access to new features',
    ],
    highlighted: false,
    cta: 'Join Waitlist',
    ctaLink: '/register',
    ctaStyle: 'secondary',
  },
]

export default function PricingSection() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const section = sectionRef.current
    if (!section) return
    const cards = section.querySelectorAll('.pricing-card')
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const el = entry.target as HTMLElement
            el.style.opacity = '1'
            el.style.transform = 'translateY(0) scale(1)'
            observer.unobserve(entry.target)
          }
        })
      },
      { threshold: 0.15 }
    )
    cards.forEach((card) => observer.observe(card))
    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} className="py-24 bg-[#0A0A0F]">
      <div className="max-w-[1280px] mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="text-xs font-medium tracking-[0.15em] text-gold uppercase mb-4">
            Pricing
          </p>
          <h2 className="font-display text-3xl lg:text-[2rem] font-semibold text-[#F0EDE8] tracking-[-0.01em] mb-4">
            Simple, Transparent Pricing
          </h2>
          <p className="text-base text-[#8A8A96]">
            Start free, upgrade when you're ready. No hidden fees, no commissions
            on your bookings.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-[1000px] mx-auto">
          {tiers.map((tier, i) => (
            <div
              key={tier.name}
              className={`pricing-card rounded-xl p-6 flex flex-col transition-all duration-700 ${
                tier.highlighted
                  ? 'border border-gold bg-[#141419] shadow-gold relative scale-[1.01] lg:scale-[1.02]'
                  : 'border border-[#2A2A35] bg-[#141419]'
              }`}
              style={{
                opacity: 0,
                transform: 'translateY(50px)',
                transitionDelay: `${i === 1 ? 0 : (i === 0 ? 0.15 : 0.3)}s`,
              }}
            >
              {/* Highlighted Badge */}
              {tier.highlighted && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="px-3 py-1 rounded-full bg-gold-shine text-[#0A0A0F] text-[10px] font-bold tracking-wide uppercase">
                    Most Popular
                  </span>
                </div>
              )}

              {/* Header */}
              <div className="mb-6 pt-2">
                <h3 className="text-xl font-semibold text-[#F0EDE8] mb-2">
                  {tier.name}
                </h3>
                <div className="flex items-baseline gap-1">
                  <span className="font-mono text-3xl font-bold text-gold">
                    ${tier.price}
                  </span>
                  <span className="text-xs text-[#5A5A66]">/month</span>
                </div>
              </div>

              {/* Features */}
              <ul className="flex-1 flex flex-col gap-3 mb-8">
                {tier.features.map((feature) => (
                  <li
                    key={feature}
                    className="flex items-start gap-3 text-sm text-[#8A8A96]"
                  >
                    <Check size={16} className="text-gold flex-shrink-0 mt-0.5" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>

              {/* CTA */}
              <Link
                to={tier.ctaLink}
                className={`block text-center py-3 rounded-full text-sm font-semibold transition-all duration-200 ${
                  tier.ctaStyle === 'primary'
                    ? 'text-[#0A0A0F] bg-gold-shine hover:scale-[1.02] hover:shadow-[0_4px_24px_rgba(212,168,83,0.3)]'
                    : 'text-gold border border-gold hover:bg-[rgba(212,168,83,0.1)]'
                }`}
              >
                {tier.cta}
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
