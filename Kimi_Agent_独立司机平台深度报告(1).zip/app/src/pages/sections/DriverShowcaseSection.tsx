import { useEffect, useRef } from 'react'
import { Link } from 'react-router-dom'
import { MapPin, ShieldCheck, Star, ArrowRight } from 'lucide-react'

interface Driver {
  name: string
  location: string
  vehicle: string
  vehicleImage: string
  avatar: string
  specialty: string[]
  rate: number
  rating: number
  link: string
}

const drivers: Driver[] = [
  {
    name: 'Marcus Johnson',
    location: 'Atlanta, GA',
    vehicle: 'Cadillac Escalade',
    vehicleImage: '/vehicle-escalade.jpg',
    avatar: '/driver-marcus.jpg',
    specialty: ['Corporate', 'VIP', 'Airport'],
    rate: 95,
    rating: 4.9,
    link: '/drivers/marcus',
  },
  {
    name: 'Sarah Mitchell',
    location: 'Denver, CO',
    vehicle: 'Subaru Outback',
    vehicleImage: '/vehicle-outback.jpg',
    avatar: '/driver-sarah.jpg',
    specialty: ['Family', 'Senior Care', 'Errands'],
    rate: 55,
    rating: 4.8,
    link: '/drivers/sarah',
  },
  {
    name: 'Elena Rodriguez',
    location: 'Miami, FL',
    vehicle: 'Tesla Model Y',
    vehicleImage: '/vehicle-tesla.jpg',
    avatar: '/driver-elena.jpg',
    specialty: ['Eco-Luxury', 'Events', 'Hourly'],
    rate: 75,
    rating: 5.0,
    link: '/drivers/elena',
  },
]

export default function DriverShowcaseSection() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const section = sectionRef.current
    if (!section) return
    const cards = section.querySelectorAll('.driver-card')
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const el = entry.target as HTMLElement
            el.style.opacity = '1'
            el.style.transform = 'translateY(0)'
            observer.unobserve(entry.target)
          }
        })
      },
      { threshold: 0.15 }
    )
    cards.forEach((card) => observer.observe(card))
    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} className="py-24 bg-[#0A0A0F]">
      <div className="max-w-[1280px] mx-auto px-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-12">
          <div>
            <p className="text-xs font-medium tracking-[0.15em] text-gold uppercase mb-4">
              Driver Showcase
            </p>
            <h2 className="font-display text-3xl lg:text-[2rem] font-semibold text-[#F0EDE8] tracking-[-0.01em]">
              Meet Drivers on DriverLink
            </h2>
          </div>
          <Link
            to="/drivers"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold text-gold border border-gold hover:bg-[rgba(212,168,83,0.1)] transition-all duration-200 self-start"
          >
            Browse All Drivers
            <ArrowRight size={14} />
          </Link>
        </div>

        {/* Driver Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {drivers.map((driver, i) => (
            <Link
              to={driver.link}
              key={driver.name}
              className="driver-card group bg-[#141419] border border-[#2A2A35] rounded-xl overflow-hidden transition-all duration-600 hover:border-[rgba(212,168,83,0.2)] hover:-translate-y-1"
              style={{
                opacity: 0,
                transform: 'translateY(40px)',
                transitionDelay: `${i * 0.15}s`,
              }}
            >
              {/* Vehicle Image */}
              <div className="aspect-[16/10] overflow-hidden">
                <img
                  src={driver.vehicleImage}
                  alt={driver.vehicle}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-400"
                />
              </div>

              {/* Content */}
              <div className="p-6">
                {/* Name Row */}
                <div className="flex items-center gap-3 mb-2">
                  <img
                    src={driver.avatar}
                    alt={driver.name}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <div className="flex items-center gap-2">
                    <h4 className="text-base font-semibold text-[#F0EDE8]">
                      {driver.name}
                    </h4>
                    <ShieldCheck size={16} className="text-gold" />
                  </div>
                </div>

                {/* Location */}
                <div className="flex items-center gap-1.5 mb-3">
                  <MapPin size={14} className="text-[#5A5A66]" />
                  <span className="text-xs text-[#5A5A66]">
                    {driver.location}
                  </span>
                </div>

                {/* Specialty Tags */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {driver.specialty.map((tag) => (
                    <span
                      key={tag}
                      className="px-2.5 py-1 rounded-full text-[10px] font-medium text-gold border border-gold/30"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Rate and Rating */}
                <div className="flex items-center justify-between">
                  <span className="font-mono text-lg font-bold text-gold">
                    ${driver.rate}/hr
                  </span>
                  <div className="flex items-center gap-1">
                    <Star size={14} className="text-gold fill-gold" />
                    <span className="text-xs text-[#8A8A96]">
                      {driver.rating}
                    </span>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
