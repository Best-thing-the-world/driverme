import { useEffect, useRef, useState } from 'react'
import { Briefcase, Plane, TrendingUp } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell } from 'recharts'

const chartData = [
  { name: 'Gig Platform', earnings: 22, color: '#2A2A35' },
  { name: 'Rideshare Premium', earnings: 35, color: '#3A3A45' },
  { name: 'DriverLink', earnings: 85, color: '#D4A853' },
]

const insights = [
  {
    icon: Briefcase,
    title: 'Corporate Travel is 49-58% of Revenue',
    description:
      'Business travelers prefer independent drivers for reliability, professionalism, and direct relationships.',
  },
  {
    icon: Plane,
    title: 'Airport Transfers are 47% of Bookings',
    description:
      'The most consistent, high-value booking type. Perfect for building a recurring client base.',
  },
  {
    icon: TrendingUp,
    title: 'No Dominant Platform Exists',
    description:
      'Unlike salons (GlossGenius, $100M ARR) or restaurants (Toast, $6B+ rev), chauffeurs have no vertical SaaS. DriverLink is first.',
  },
]

export default function MarketSection() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const [animateChart, setAnimateChart] = useState(false)
  const [cardsVisible, setCardsVisible] = useState(false)

  useEffect(() => {
    const section = sectionRef.current
    if (!section) return

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setAnimateChart(true)
          setTimeout(() => setCardsVisible(true), 400)
          observer.disconnect()
        }
      },
      { threshold: 0.15 }
    )
    observer.observe(section)
    return () => observer.disconnect()
  }, [])

  return (
    <section
      ref={sectionRef}
      className="py-24 bg-gradient-to-b from-[#0A0A0F] to-[#0D0D12]"
    >
      <div className="max-w-[1280px] mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="text-xs font-medium tracking-[0.15em] text-gold uppercase mb-4">
            Why Now
          </p>
          <h2 className="font-display text-3xl lg:text-[2rem] font-semibold text-[#F0EDE8] tracking-[-0.01em] mb-4">
            The $74.5B Opportunity
          </h2>
          <p className="text-lg text-[#8A8A96] max-w-[640px] mx-auto">
            Independent chauffeurs earn 3-7x more than gig drivers. The tools
            just haven't existed — until now.
          </p>
        </div>

        {/* Two Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Chart */}
          <div className="bg-[#141419] border border-[#2A2A35] rounded-xl p-6">
            <h4 className="text-base font-semibold text-[#F0EDE8] mb-6">
              Hourly Earnings Comparison
            </h4>
            <div className="h-[280px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} barSize={60}>
                  <XAxis
                    dataKey="name"
                    tick={{ fill: '#5A5A66', fontSize: 12 }}
                    axisLine={{ stroke: '#2A2A35' }}
                    tickLine={false}
                  />
                  <YAxis
                    tick={{ fill: '#5A5A66', fontSize: 12 }}
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(v) => `$${v}`}
                  />
                  <Bar dataKey="earnings" radius={[6, 6, 0, 0]}>
                    {chartData.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={entry.color}
                        opacity={animateChart ? 1 : 0}
                        style={{
                          transition: `opacity 0.8s ease ${index * 0.2}s`,
                          transformOrigin: 'bottom',
                          transform: animateChart ? 'scaleY(1)' : 'scaleY(0)',
                        }}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Insight Cards */}
          <div className="flex flex-col gap-4">
            {insights.map((insight, i) => {
              const Icon = insight.icon
              return (
                <div
                  key={insight.title}
                  className="bg-[#141419] border border-[#2A2A35] rounded-xl p-6 flex items-start gap-4 transition-all duration-700 hover:border-[rgba(212,168,83,0.2)] hover:-translate-y-0.5"
                  style={{
                    opacity: cardsVisible ? 1 : 0,
                    transform: cardsVisible
                      ? 'translateX(0)'
                      : 'translateX(30px)',
                    transitionDelay: `${i * 0.15}s`,
                  }}
                >
                  <div className="w-10 h-10 rounded-lg bg-[rgba(212,168,83,0.1)] flex items-center justify-center flex-shrink-0">
                    <Icon size={24} className="text-gold" />
                  </div>
                  <div>
                    <h4 className="text-base font-semibold text-[#F0EDE8] mb-1">
                      {insight.title}
                    </h4>
                    <p className="text-sm text-[#8A8A96] leading-relaxed">
                      {insight.description}
                    </p>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </section>
  )
}
