import { useEffect, useRef } from 'react'
import { Link } from 'react-router-dom'
import { Globe, CalendarCheck, Users, Wallet, Car, BarChart3 } from 'lucide-react'

const features = [
  {
    icon: Globe,
    title: 'Branded Storefront',
    description:
      'Your own professional booking page with your photo, vehicle, services, and reviews. Customizable and always on.',
  },
  {
    icon: CalendarCheck,
    title: 'Smart Booking System',
    description:
      'Clients book directly with real-time availability. Multi-step booking with service-specific fields.',
  },
  {
    icon: Users,
    title: 'Customer CRM',
    description:
      'Track every client, their preferences, notes, and complete booking history in one place.',
  },
  {
    icon: Wallet,
    title: 'Earnings Dashboard',
    description:
      "See your revenue, payouts, and growth trends. Know exactly what you've earned and what's coming.",
  },
  {
    icon: Car,
    title: 'Vehicle & Service Manager',
    description:
      'Add unlimited services — airport, hourly, VIP, senior care, errands. Customize each with its own pricing and fields.',
  },
  {
    icon: BarChart3,
    title: 'Business Analytics',
    description:
      'Understand your business with insights on bookings, revenue, peak times, and client retention.',
  },
]

export default function FeaturesSection() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const section = sectionRef.current
    if (!section) return

    const sticky = section.querySelector('.sticky-title')
    if (sticky) {
      const observer = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) {
            const el = entry.target as HTMLElement
            el.style.opacity = '1'
            el.style.transform = 'translateY(0)'
            observer.unobserve(el)
          }
        },
        { threshold: 0.15 }
      )
      observer.observe(sticky)
    }

    const cards = section.querySelectorAll('.feature-card')
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const el = entry.target as HTMLElement
            el.style.opacity = '1'
            el.style.transform = 'translateY(0)'
            observer.unobserve(entry.target)
          }
        })
      },
      { threshold: 0.15 }
    )
    cards.forEach((card) => observer.observe(card))
    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} className="py-24 bg-[#0A0A0F]">
      <div className="max-w-[1280px] mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-12 lg:gap-16">
          {/* Left Sticky Column */}
          <div className="lg:w-[35%]">
            <div
              className="sticky-title lg:sticky lg:top-[120px] transition-all duration-700"
              style={{ opacity: 0, transform: 'translateY(30px)' }}
            >
              <p className="text-xs font-medium tracking-[0.15em] text-gold uppercase mb-4">
                Features
              </p>
              <h2 className="font-display text-3xl lg:text-[2rem] font-semibold text-[#F0EDE8] tracking-[-0.01em] mb-4">
                Everything You Need to Run Your Business
              </h2>
              <p className="text-base text-[#8A8A96] mb-6">
                From booking management to earnings tracking, DriverLink replaces
                5+ tools with one seamless platform.
              </p>
              <Link
                to="/features"
                className="inline-flex items-center px-6 py-3 rounded-full text-sm font-semibold text-gold border border-gold hover:bg-[rgba(212,168,83,0.1)] transition-all duration-200"
              >
                Explore All Features
              </Link>
            </div>
          </div>

          {/* Right Scrolling Cards */}
          <div className="lg:w-[60%] flex flex-col gap-4">
            {features.map((feature, i) => {
              const Icon = feature.icon
              return (
                <div
                  key={feature.title}
                  className="feature-card bg-[#141419] border border-[#2A2A35] rounded-xl p-6 flex items-start gap-5 transition-all duration-500 hover:border-[rgba(212,168,83,0.2)] hover:-translate-y-0.5"
                  style={{
                    opacity: 0,
                    transform: 'translateY(40px)',
                    transitionDelay: `${i * 0.1}s`,
                  }}
                >
                  <div className="w-10 h-10 rounded-lg bg-[rgba(212,168,83,0.1)] flex items-center justify-center flex-shrink-0">
                    <Icon size={24} className="text-gold" />
                  </div>
                  <div>
                    <h4 className="text-xl font-semibold text-[#F0EDE8] mb-1">
                      {feature.title}
                    </h4>
                    <p className="text-sm text-[#8A8A96] leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </section>
  )
}
