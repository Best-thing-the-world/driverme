import { useEffect, useRef } from 'react'
import { Store, Settings, CalendarCheck } from 'lucide-react'

const steps = [
  {
    number: '01',
    icon: Store,
    title: 'Create Your Storefront',
    description:
      'Sign up, add your photo, bio, vehicle details, and services. Your branded page is live instantly.',
    image: '/feature-storefront.jpg',
  },
  {
    number: '02',
    icon: Settings,
    title: 'Set Your Services & Pricing',
    description:
      'Configure airport transfers, hourly charters, point-to-point rides, and more. Set your own rates — you keep what you earn.',
    image: '/feature-booking.jpg',
  },
  {
    number: '03',
    icon: CalendarCheck,
    title: 'Start Receiving Bookings',
    description:
      'Clients find you through the directory, book directly on your page, and pay upfront. You manage everything from one dashboard.',
    image: '/feature-crm.jpg',
  },
]

export default function HowItWorksSection() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const section = sectionRef.current
    if (!section) return
    const cards = section.querySelectorAll('.step-card')
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const el = entry.target as HTMLElement
            el.style.opacity = '1'
            el.style.transform = 'translateY(0)'
            observer.unobserve(entry.target)
          }
        })
      },
      { threshold: 0.15 }
    )
    cards.forEach((card) => observer.observe(card))
    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} className="py-24 bg-[#0A0A0F]">
      <div className="max-w-[1280px] mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="text-xs font-medium tracking-[0.15em] text-gold uppercase mb-4">
            How It Works
          </p>
          <h2 className="font-display text-3xl lg:text-[2rem] font-semibold text-[#F0EDE8] tracking-[-0.01em] mb-4">
            Three Steps to Your Own Booking Business
          </h2>
          <p className="text-sm text-[#8A8A96]">
            From signup to your first booking in under 24 hours.
          </p>
        </div>

        {/* Steps Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {steps.map((step, i) => {
            const Icon = step.icon
            return (
              <div
                key={step.number}
                className="step-card bg-[#141419] border border-[#2A2A35] rounded-xl p-6 transition-all duration-700 hover:border-[rgba(212,168,83,0.2)] hover:-translate-y-1"
                style={{
                  opacity: 0,
                  transform: 'translateY(50px)',
                  transitionDelay: `${i * 0.2}s`,
                }}
              >
                {/* Number Badge */}
                <span className="font-display text-6xl font-bold text-gold/20 block mb-4">
                  {step.number}
                </span>

                {/* Icon */}
                <div className="w-10 h-10 rounded-lg bg-[rgba(212,168,83,0.1)] flex items-center justify-center mb-4">
                  <Icon size={24} className="text-gold" />
                </div>

                {/* Title */}
                <h3 className="text-xl font-semibold text-[#F0EDE8] mb-2">
                  {step.title}
                </h3>

                {/* Description */}
                <p className="text-sm text-[#8A8A96] leading-relaxed mb-4">
                  {step.description}
                </p>

                {/* Image */}
                <div className="rounded-lg overflow-hidden mt-4">
                  <img
                    src={step.image}
                    alt={step.title}
                    className="w-full h-48 object-cover"
                  />
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
