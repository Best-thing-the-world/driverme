import { useEffect, useRef } from 'react'
import { Star } from 'lucide-react'

interface Testimonial {
  quote: string
  author: string
  location: string
  vehicle: string
  avatar: string
  rating: number
}

const testimonials: Testimonial[] = [
  {
    quote:
      'DriverLink transformed my business. I went from chasing clients through word-of-mouth to having a professional booking page that brings me 3-4 new corporate clients every week. The CRM helps me remember every client\'s preferences.',
    author: 'Marcus J.',
    location: 'Atlanta',
    vehicle: 'Cadillac Escalade',
    avatar: '/driver-marcus.jpg',
    rating: 5,
  },
  {
    quote:
      "I was using three different apps to manage my senior transport clients. Now everything is in one place — bookings, client notes, even medication reminders. My clients' families love being able to book online.",
    author: 'Sarah M.',
    location: 'Denver',
    vehicle: 'Subaru Outback',
    avatar: '/driver-sarah.jpg',
    rating: 5,
  },
  {
    quote:
      'The earnings dashboard alone is worth the subscription. I can see exactly how much I made, what\'s pending, and my growth month over month. In 6 months, my revenue increased 40%.',
    author: 'Elena R.',
    location: 'Miami',
    vehicle: 'Tesla Model Y',
    avatar: '/driver-elena.jpg',
    rating: 5,
  },
]

export default function TestimonialsSection() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const section = sectionRef.current
    if (!section) return
    const cards = section.querySelectorAll('.testimonial-card')
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const el = entry.target as HTMLElement
            el.style.opacity = '1'
            el.style.transform = 'translateX(0)'
            observer.unobserve(entry.target)
          }
        })
      },
      { threshold: 0.15 }
    )
    cards.forEach((card) => observer.observe(card))
    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} className="py-24 bg-[#0D0D12] border-t border-[#2A2A35]">
      <div className="max-w-[1280px] mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="text-xs font-medium tracking-[0.15em] text-gold uppercase mb-4">
            Testimonials
          </p>
          <h2 className="font-display text-3xl lg:text-[2rem] font-semibold text-[#F0EDE8] tracking-[-0.01em]">
            Trusted by Independent Drivers Nationwide
          </h2>
        </div>

        {/* Testimonial Cards */}
        <div className="flex flex-col lg:flex-row gap-6 overflow-x-auto pb-4">
          {testimonials.map((t, i) => (
            <div
              key={t.author}
              className="testimonial-card flex-shrink-0 lg:w-[400px] bg-[#141419] border border-[#2A2A35] rounded-2xl p-8 transition-all duration-800 hover:border-[rgba(212,168,83,0.2)]"
              style={{
                opacity: 0,
                transform: 'translateX(60px)',
                transitionDelay: `${i * 0.2}s`,
              }}
            >
              {/* Star Rating */}
              <div className="flex items-center gap-1 mb-4">
                {Array.from({ length: 5 }).map((_, j) => (
                  <Star
                    key={j}
                    size={16}
                    className={
                      j < t.rating
                        ? 'text-gold fill-gold'
                        : 'text-[#2A2A35] fill-[#2A2A35]'
                    }
                  />
                ))}
              </div>

              {/* Quote */}
              <p className="text-base text-[#F0EDE8] leading-[1.7] italic mb-6 relative">
                <span className="absolute -top-2 -left-2 text-gold/30 font-display text-5xl leading-none">
                  &ldquo;
                </span>
                <span className="relative z-10">{t.quote}</span>
              </p>

              {/* Divider */}
              <div className="h-px bg-[#2A2A35] my-6" />

              {/* Author */}
              <div className="flex items-center gap-3">
                <img
                  src={t.avatar}
                  alt={t.author}
                  className="w-12 h-12 rounded-full object-cover border-2 border-gold"
                />
                <div>
                  <p className="text-sm font-semibold text-[#F0EDE8]">
                    {t.author}
                  </p>
                  <p className="text-xs text-[#5A5A66]">
                    {t.location} —{' '}
                    <span className="text-gold">{t.vehicle}</span>
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
