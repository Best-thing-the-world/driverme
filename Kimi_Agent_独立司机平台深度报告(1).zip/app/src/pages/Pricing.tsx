import { useState, useRef, useEffect } from 'react'
import { motion, useInView, AnimatePresence } from 'framer-motion'
import { Link } from 'react-router-dom'
import {
  Check, X, ShieldCheck, CreditCard, RotateCcw, ChevronDown,
} from 'lucide-react'

/* ─────────────────────── animation helpers ─────────────────────── */

const easeEnter = [0, 0, 0.2, 1] as [number, number, number, number]
const easeSmooth = [0.4, 0, 0.2, 1] as [number, number, number, number]

function FadeIn({
  children,
  delay = 0,
  className = '',
}: {
  children: React.ReactNode
  delay?: number
  className?: string
}) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-60px' })
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 40 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.7, delay, ease: easeEnter }}
      className={className}
    >
      {children}
    </motion.div>
  )
}

/* ─────────────────────── data ─────────────────────── */

const starterFeatures = [
  { text: 'Branded booking page', included: true },
  { text: 'Mobile-optimized page', included: true },
  { text: 'Booking management', included: true },
  { text: 'Client reviews', included: true },
  { text: 'Automated emails', included: true },
  { text: 'Payment processing', included: true },
  { text: 'Payout tracking', included: true },
  { text: 'Email support', included: true },
  { text: '5 active services', included: false },
  { text: '25 CRM clients', included: false },
  { text: 'Basic earnings dashboard', included: false },
  { text: 'Custom domain', included: false },
]

const proFeatures = [
  'Everything in Starter, plus:',
  'Unlimited active services',
  'Unlimited CRM clients',
  'Custom booking fields',
  'Recurring bookings',
  'Client notes & tags',
  'Advanced earnings dashboard',
  'Revenue analytics',
  'CSV exports',
  'Priority support',
  'Custom colors & branding',
]

const premierFeatures = [
  'Everything in Professional, plus:',
  'Custom domain',
  'Remove DriverLink branding',
  'Dedicated account manager',
  'API access',
  'Team multi-user access',
  'White-label options',
]

const comparisonData = [
  { category: 'Storefront', rows: [
    { feature: 'Branded booking page', starter: true, pro: true, premier: true },
    { feature: 'Custom domain', starter: false, pro: false, premier: true },
    { feature: 'Custom colors & branding', starter: false, pro: true, premier: true },
    { feature: 'Remove DriverLink branding', starter: false, pro: false, premier: true },
    { feature: 'Mobile-optimized page', starter: true, pro: true, premier: true },
  ]},
  { category: 'Bookings & CRM', rows: [
    { feature: 'Active services', starter: '5', pro: 'Unlimited', premier: 'Unlimited' },
    { feature: 'Booking management', starter: true, pro: true, premier: true },
    { feature: 'Custom booking fields', starter: false, pro: true, premier: true },
    { feature: 'Recurring bookings', starter: false, pro: true, premier: true },
    { feature: 'CRM clients', starter: '25', pro: 'Unlimited', premier: 'Unlimited' },
    { feature: 'Client notes & tags', starter: false, pro: true, premier: true },
    { feature: 'Client reviews', starter: true, pro: true, premier: true },
    { feature: 'Automated emails', starter: true, pro: true, premier: true },
  ]},
  { category: 'Payments & Earnings', rows: [
    { feature: 'Payment processing', starter: true, pro: true, premier: true },
    { feature: 'Earnings dashboard', starter: 'Basic', pro: 'Advanced', premier: 'Advanced' },
    { feature: 'Payout tracking', starter: true, pro: true, premier: true },
    { feature: 'Revenue analytics', starter: false, pro: true, premier: true },
    { feature: 'CSV exports', starter: false, pro: true, premier: true },
  ]},
  { category: 'Support', rows: [
    { feature: 'Email support', starter: true, pro: true, premier: true },
    { feature: 'Priority support', starter: false, pro: true, premier: true },
    { feature: 'Dedicated account manager', starter: false, pro: false, premier: true },
    { feature: 'API access', starter: false, pro: false, premier: true },
  ]},
]

const faqData = [
  {
    q: 'Is there a free trial?',
    a: 'Yes! Every plan comes with a 14-day free trial. No credit card required. You get full access to all features in your chosen tier during the trial.',
  },
  {
    q: 'Do I pay commissions on bookings?',
    a: 'Absolutely not. You keep 100% of every booking you receive. DriverLink charges a flat monthly fee \u2014 that\'s it. No hidden fees, no percentage cuts, no booking fees.',
  },
  {
    q: 'Can I cancel anytime?',
    a: 'Yes, you can cancel your subscription at any time with no penalties. Your storefront stays active until the end of your billing period.',
  },
  {
    q: 'How do clients find me?',
    a: 'Your storefront appears in the DriverLink driver directory where clients can search by city, vehicle type, and service. You can also share your unique storefront URL directly with clients.',
  },
  {
    q: 'What payment methods can my clients use?',
    a: 'Clients can pay by credit card, debit card, or Apple Pay. All payments are processed securely through Stripe and deposited directly to your linked bank account.',
  },
  {
    q: 'Can I upgrade or downgrade my plan?',
    a: 'Yes, you can change your plan at any time. When upgrading, you\'ll get immediate access to new features. When downgrading, changes take effect at the next billing cycle.',
  },
]

/* ─────────────────────── components ─────────────────────── */

function PricingCard({
  name,
  price,
  annualPrice,
  description,
  features,
  highlighted = false,
  ctaText,
  isAnnual,
}: {
  name: string
  price: number
  annualPrice: number
  description: string
  features: { text: string; included: boolean }[] | string[]
  highlighted?: boolean
  ctaText: string
  isAnnual: boolean
}) {
  const displayPrice = isAnnual ? annualPrice : price
  const originalPrice = isAnnual ? price : null

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, ease: easeEnter }}
      className={`relative flex flex-col rounded-2xl border ${
        highlighted
          ? 'border-[#D4A853] shadow-gold bg-[linear-gradient(180deg,rgba(212,168,83,0.08)_0%,rgba(10,10,15,0)_100%)]'
          : 'border-[#2A2A35] bg-[#141419]'
      }`}
    >
      {highlighted && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2">
          <span className="px-4 py-1 rounded-full bg-[#D4A853] text-[#0A0A0F] text-xs font-bold tracking-wide">
            MOST POPULAR
          </span>
        </div>
      )}

      {/* Header */}
      <div className="p-8 pb-6 border-b border-[#2A2A35]">
        <h3 className="text-xl font-semibold text-[#F0EDE8]">{name}</h3>
        <div className="flex items-baseline gap-2 mt-3">
          <span className="text-4xl font-mono font-bold text-[#D4A853]">
            ${displayPrice}
          </span>
          <span className="text-sm text-[#5A5A66]">/month</span>
        </div>
        {originalPrice && (
          <p className="text-sm text-[#5A5A66] line-through mt-1">${originalPrice}/month</p>
        )}
        <p className="text-sm text-[#8A8A96] mt-3">{description}</p>
      </div>

      {/* Features */}
      <div className="p-8 flex-1">
        <ul className="flex flex-col gap-3">
          {features.map((f, i) => {
            if (typeof f === 'string') {
              return (
                <li key={i} className="flex items-start gap-3">
                  <Check size={16} className="text-[#D4A853] mt-0.5 shrink-0" />
                  <span className="text-sm text-[#F0EDE8]">{f}</span>
                </li>
              )
            }
            return (
              <li key={f.text} className="flex items-start gap-3">
                {f.included ? (
                  <Check size={16} className="text-[#D4A853] mt-0.5 shrink-0" />
                ) : (
                  <X size={16} className="text-[#5A5A66] mt-0.5 shrink-0" />
                )}
                <span className={`text-sm ${f.included ? 'text-[#F0EDE8]' : 'text-[#5A5A66] line-through'}`}>
                  {f.text}
                </span>
              </li>
            )
          })}
        </ul>
      </div>

      {/* CTA */}
      <div className="px-8 pb-8">
        <Link
          to="/register"
          className={`block text-center py-3 rounded-full text-sm font-semibold transition-all duration-200 ${
            highlighted
              ? 'bg-[linear-gradient(135deg,#D4A853_0%,#E8C87A_50%,#D4A853_100%)] text-[#0A0A0F] hover:scale-[1.02] hover:shadow-[0_4px_24px_rgba(212,168,83,0.3)]'
              : 'border border-[#D4A853] text-[#D4A853] hover:bg-[rgba(212,168,83,0.1)]'
          }`}
        >
          {ctaText}
        </Link>
      </div>
    </motion.div>
  )
}

function ComparisonTable() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-60px' })

  const renderCell = (val: boolean | string) => {
    if (typeof val === 'boolean') {
      return val ? (
        <div className="w-6 h-6 rounded-full bg-[rgba(212,168,83,0.1)] flex items-center justify-center mx-auto">
          <Check size={14} className="text-[#D4A853]" />
        </div>
      ) : (
        <X size={16} className="text-[#5A5A66] mx-auto" />
      )
    }
    return <span className="text-sm text-[#F0EDE8]">{val}</span>
  }

  return (
    <div ref={ref} className="max-w-[1000px] mx-auto overflow-x-auto">
      <table className="w-full min-w-[600px]">
        <thead>
          <tr className="bg-[#141419]">
            <th className="text-left px-5 py-4 text-xs font-semibold text-[#8A8A96] uppercase tracking-wider w-[40%]">
              Feature
            </th>
            <th className="text-center px-5 py-4 text-xs font-semibold text-[#8A8A96] uppercase tracking-wider">
              Starter
            </th>
            <th className="text-center px-5 py-4 text-xs font-semibold text-[#D4A853] uppercase tracking-wider border-b-2 border-[#D4A853]">
              Professional
            </th>
            <th className="text-center px-5 py-4 text-xs font-semibold text-[#8A8A96] uppercase tracking-wider">
              Premier
            </th>
          </tr>
        </thead>
        <tbody>
          {comparisonData.map((cat, catIdx) =>
            cat.rows.map((row, rowIdx) => {
              const globalIdx =
                comparisonData.slice(0, catIdx).reduce((a, c) => a + c.rows.length, 0) + rowIdx
              const isFirst = rowIdx === 0
              return (
                <motion.tr
                  key={`${cat.category}-${row.feature}`}
                  initial={{ opacity: 0, x: -20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.4, delay: globalIdx * 0.05, ease: easeEnter }}
                  className={`border-t border-[#2A2A35] ${globalIdx % 2 === 0 ? 'bg-transparent' : 'bg-[#141419]'}`}
                >
                  {isFirst && (
                    <td
                      rowSpan={cat.rows.length}
                      className="px-5 py-4 text-xs font-semibold text-[#5A5A66] uppercase tracking-wider align-top"
                    >
                      {cat.category}
                    </td>
                  )}
                  <td className="px-5 py-4 text-sm text-[#F0EDE8]">{row.feature}</td>
                  <td className="px-5 py-4 text-center">{renderCell(row.starter)}</td>
                  <td className="px-5 py-4 text-center">{renderCell(row.pro)}</td>
                  <td className="px-5 py-4 text-center">{renderCell(row.premier)}</td>
                </motion.tr>
              )
            })
          )}
        </tbody>
      </table>
    </div>
  )
}

function ROICalculator() {
  const [ridesPerWeek, setRidesPerWeek] = useState(15)
  const [avgRideValue, setAvgRideValue] = useState(85)
  const [plan, setPlan] = useState<'starter' | 'pro' | 'premier'>('pro')

  const planPrices = { starter: 49, pro: 99, premier: 199 }
  const monthlyFee = planPrices[plan]

  const weeklyEarnings = ridesPerWeek * avgRideValue
  const monthlyEarnings = weeklyEarnings * 4.33
  const annualEarnings = monthlyEarnings * 12
  const annualFee = monthlyFee * 12
  const takeHomeAnnual = annualEarnings - annualFee
  const _takeHomeMonthly = monthlyEarnings - monthlyFee

  const gigPlatformAnnual = annualEarnings * 0.75

  const barData = [
    { label: 'Gig platform (after 25% fee)', value: gigPlatformAnnual, color: '#2A2A35' },
    { label: `DriverLink ${plan.charAt(0).toUpperCase() + plan.slice(1)} (after $${monthlyFee}/mo)`, value: takeHomeAnnual, color: '#D4A853' },
  ]

  const maxVal = Math.max(barData[0].value, barData[1].value)

  return (
    <div className="max-w-[1280px] mx-auto px-6">
      <div className="grid grid-cols-1 lg:grid-cols-[45%_55%] gap-12 lg:gap-16">
        {/* Left — inputs */}
        <div className="flex flex-col gap-8">
          <div>
            <h2 className="font-body text-[28px] md:text-[32px] font-semibold text-[#F0EDE8] leading-tight tracking-tight">
              Calculate Your Earnings
            </h2>
            <p className="text-[#8A8A96] text-base leading-relaxed mt-4">
              See how much more you could earn as an independent driver with your own booking platform.
            </p>
          </div>

          {/* Sliders */}
          <div className="flex flex-col gap-6">
            <div>
              <label className="text-xs text-[#5A5A66] uppercase tracking-wider">Rides per week</label>
              <div className="flex items-center gap-4 mt-2">
                <input
                  type="range"
                  min={1}
                  max={50}
                  value={ridesPerWeek}
                  onChange={(e) => setRidesPerWeek(Number(e.target.value))}
                  className="flex-1 h-2 rounded-full appearance-none cursor-pointer"
                  style={{
                    background: `linear-gradient(to right, #D4A853 ${(ridesPerWeek / 50) * 100}%, #2A2A35 ${(ridesPerWeek / 50) * 100}%)`,
                  }}
                />
                <span className="text-lg font-mono font-bold text-[#D4A853] w-12 text-right">{ridesPerWeek}</span>
              </div>
            </div>

            <div>
              <label className="text-xs text-[#5A5A66] uppercase tracking-wider">Average ride value ($)</label>
              <div className="flex items-center gap-4 mt-2">
                <input
                  type="range"
                  min={30}
                  max={300}
                  value={avgRideValue}
                  onChange={(e) => setAvgRideValue(Number(e.target.value))}
                  className="flex-1 h-2 rounded-full appearance-none cursor-pointer"
                  style={{
                    background: `linear-gradient(to right, #D4A853 ${((avgRideValue - 30) / 270) * 100}%, #2A2A35 ${((avgRideValue - 30) / 270) * 100}%)`,
                  }}
                />
                <span className="text-lg font-mono font-bold text-[#D4A853] w-14 text-right">${avgRideValue}</span>
              </div>
            </div>

            <div>
              <label className="text-xs text-[#5A5A66] uppercase tracking-wider">Your plan</label>
              <div className="flex gap-2 mt-2">
                {(['starter', 'pro', 'premier'] as const).map((p) => (
                  <button
                    key={p}
                    onClick={() => setPlan(p)}
                    className={`flex-1 py-2.5 rounded-full text-sm font-semibold transition-all duration-200 ${
                      plan === p
                        ? 'bg-[#141419] text-[#D4A853] border border-[#D4A853]'
                        : 'bg-[#1E1E26] text-[#5A5A66] border border-[#2A2A35] hover:text-[#F0EDE8]'
                    }`}
                  >
                    {p.charAt(0).toUpperCase() + p.slice(1)}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Calculations */}
          <div className="bg-[#141419] border border-[#2A2A35] rounded-xl p-6 flex flex-col gap-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-[#8A8A96]">Weekly earnings</span>
              <span className="text-xl font-mono font-bold text-[#D4A853]">${weeklyEarnings.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-[#8A8A96]">Monthly earnings</span>
              <span className="text-xl font-mono font-bold text-[#D4A853]">${Math.round(monthlyEarnings).toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-[#8A8A96]">Annual earnings</span>
              <span className="text-2xl font-mono font-bold text-[#D4A853]">${Math.round(annualEarnings).toLocaleString()}</span>
            </div>
            <div className="border-t border-[#2A2A35] pt-3 mt-1">
              <div className="flex justify-between items-center">
                <span className="text-sm text-[#5A5A66]">Minus DriverLink fee (${monthlyFee}/mo)</span>
                <span className="text-sm text-[#5A5A66]">-${annualFee.toLocaleString()}/yr</span>
              </div>
              <div className="flex justify-between items-center mt-2">
                <span className="text-sm font-semibold text-[#F0EDE8]">Your take-home</span>
                <span className="text-2xl font-mono font-bold text-[#D4A853] underline underline-offset-4">
                  ${Math.round(takeHomeAnnual).toLocaleString()}
                </span>
              </div>
            </div>
            <p className="text-xs text-[#5A5A66] italic mt-2">
              Compare to gig platforms: you&apos;d keep ~75% less after their fees.
            </p>
          </div>
        </div>

        {/* Right — chart */}
        <div className="bg-[#141419] border border-[#2A2A35] rounded-2xl p-8 flex flex-col">
          <h4 className="text-lg font-semibold text-[#F0EDE8] mb-6">Your Earnings Comparison</h4>
          <div className="flex-1 flex flex-col justify-center gap-6">
            {barData.map((bar, i) => (
              <div key={bar.label}>
                <div className="flex justify-between text-sm mb-2">
                  <span className={i === 1 ? 'text-[#D4A853]' : 'text-[#8A8A96]'}>{bar.label}</span>
                  <span className={`font-mono font-bold ${i === 1 ? 'text-[#D4A853]' : 'text-[#F0EDE8]'}`}>
                    ${Math.round(bar.value).toLocaleString()}/yr
                  </span>
                </div>
                <div className="w-full h-10 bg-[#1E1E26] rounded-lg overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.max((bar.value / maxVal) * 100, 8)}%` }}
                    transition={{ duration: 0.8, ease: easeSmooth }}
                    className="h-full rounded-lg flex items-center justify-end px-3"
                    style={{ backgroundColor: bar.color }}
                  >
                    {bar.value > maxVal * 0.25 && (
                      <span className="text-xs font-mono font-bold text-[#0A0A0F]">
                        ${Math.round(bar.value / 1000)}K
                      </span>
                    )}
                  </motion.div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-6 pt-6 border-t border-[#2A2A35]">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[rgba(212,168,83,0.1)] flex items-center justify-center">
                <TrendingUpIcon />
              </div>
              <div>
                <p className="text-sm font-semibold text-[#F0EDE8]">
                  You keep ${Math.round(takeHomeAnnual - gigPlatformAnnual).toLocaleString()} more per year
                </p>
                <p className="text-xs text-[#5A5A66]">With DriverLink vs. gig platforms</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function TrendingUpIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#D4A853" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
      <polyline points="17 6 23 6 23 12" />
    </svg>
  )
}

function FAQItem({
  question,
  answer,
  isOpen,
  onToggle,
}: {
  question: string
  answer: string
  isOpen: boolean
  onToggle: () => void
}) {
  return (
    <div className="border-b border-[#2A2A35]">
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between py-5 text-left group"
      >
        <span className="text-[#F0EDE8] text-base font-medium pr-4 group-hover:text-[#D4A853] transition-colors">
          {question}
        </span>
        <motion.div
          animate={{ rotate: isOpen ? 180 : 0 }}
          transition={{ duration: 0.3, ease: easeSmooth }}
        >
          <ChevronDown size={20} className="text-[#5A5A66] shrink-0" />
        </motion.div>
      </button>
      <AnimatePresence initial={false}>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: easeSmooth }}
            className="overflow-hidden"
          >
            <p className="text-sm text-[#8A8A96] leading-relaxed pb-5">{answer}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

/* ─────────────────────── main page ─────────────────────── */

export default function Pricing() {
  const [isAnnual, setIsAnnual] = useState(false)
  const [openFaq, setOpenFaq] = useState<number | null>(null)

  return (
    <div className="bg-[#0A0A0F] min-h-screen">
      {/* ── Section 1: Hero ── */}
      <section className="pt-32 pb-20">
        <div className="max-w-[800px] mx-auto px-6 text-center">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: easeEnter }}
            className="text-[#D4A853] text-xs font-medium tracking-[0.15em] uppercase"
          >
            PRICING
          </motion.span>
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1, ease: easeEnter }}
            className="font-display text-[32px] md:text-[48px] lg:text-[56px] font-bold text-[#F0EDE8] leading-[1.05] tracking-tight mt-4"
          >
            Simple Pricing. No Commissions.
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: easeEnter }}
            className="text-[#8A8A96] text-lg leading-relaxed mt-6 max-w-[600px] mx-auto"
          >
            Keep 100% of what you earn. Pay one flat monthly fee. No booking fees, no hidden charges, no percentage cuts.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4, ease: easeEnter }}
            className="flex items-center justify-center gap-6 mt-8 flex-wrap"
          >
            <div className="flex items-center gap-2">
              <ShieldCheck size={16} className="text-[#D4A853]" />
              <span className="text-xs text-[#5A5A66]">Secure Payments</span>
            </div>
            <div className="flex items-center gap-2">
              <CreditCard size={16} className="text-[#D4A853]" />
              <span className="text-xs text-[#5A5A66]">No CC Required to Start</span>
            </div>
            <div className="flex items-center gap-2">
              <RotateCcw size={16} className="text-[#D4A853]" />
              <span className="text-xs text-[#5A5A66]">Cancel Anytime</span>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ── Section 2: Pricing Tiers ── */}
      <section className="pb-24">
        <div className="max-w-[1100px] mx-auto px-6">
          {/* Annual toggle */}
          <div className="flex items-center justify-center gap-4 mb-12">
            <span className={`text-sm ${!isAnnual ? 'text-[#F0EDE8] font-semibold' : 'text-[#5A5A66]'}`}>
              Monthly
            </span>
            <button
              onClick={() => setIsAnnual(!isAnnual)}
              className="relative w-14 h-7 rounded-full bg-[#1E1E26] border border-[#2A2A35] transition-colors duration-200"
            >
              <motion.div
                animate={{ x: isAnnual ? 28 : 2 }}
                transition={{ duration: 0.3, ease: easeSmooth }}
                className="absolute top-0.5 w-6 h-6 rounded-full bg-[#D4A853]"
              />
            </button>
            <span className={`text-sm ${isAnnual ? 'text-[#F0EDE8] font-semibold' : 'text-[#5A5A66]'}`}>
              Annually
            </span>
            {isAnnual && (
              <span className="text-xs text-[#22C55E] font-medium">Save 20%</span>
            )}
          </div>

          {/* Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <PricingCard
              name="Starter"
              price={49}
              annualPrice={39}
              description="Perfect for drivers just starting out with their independent business."
              features={starterFeatures}
              ctaText="Join Waitlist"
              isAnnual={isAnnual}
            />
            <motion.div
              initial={{ opacity: 0, y: 50, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 0.7, delay: 0.15, ease: easeEnter }}
              className="md:-mt-4"
            >
              <PricingCard
                name="Professional"
                price={99}
                annualPrice={79}
                description="For growing businesses that need advanced tools and unlimited everything."
                features={proFeatures}
                highlighted
                ctaText="Join Waitlist"
                isAnnual={isAnnual}
              />
            </motion.div>
            <PricingCard
              name="Premier"
              price={199}
              annualPrice={159}
              description="For established operators with multiple vehicles and team members."
              features={premierFeatures}
              ctaText="Contact Sales"
              isAnnual={isAnnual}
            />
          </div>
        </div>
      </section>

      {/* ── Section 3: Feature Comparison Table ── */}
      <section className="py-24 bg-[#0D0D12]">
        <div className="max-w-[1280px] mx-auto px-6">
          <FadeIn className="text-center mb-12">
            <h2 className="font-body text-[28px] md:text-[32px] font-semibold text-[#F0EDE8] leading-tight tracking-tight">
              Compare All Features
            </h2>
            <p className="text-[#8A8A96] text-base mt-3">
              See exactly what&apos;s included in each plan.
            </p>
          </FadeIn>
          <ComparisonTable />
        </div>
      </section>

      {/* ── Section 4: ROI Calculator ── */}
      <section className="py-24">
        <ROICalculator />
      </section>

      {/* ── Section 5: FAQ ── */}
      <section className="py-24 bg-[#0D0D12]">
        <div className="max-w-[720px] mx-auto px-6">
          <FadeIn className="text-center mb-12">
            <h2 className="font-body text-[28px] md:text-[32px] font-semibold text-[#F0EDE8] leading-tight tracking-tight">
              Frequently Asked Questions
            </h2>
          </FadeIn>
          <motion.div initial="hidden" animate="visible">
            {faqData.map((faq, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}>
                <FAQItem
                  question={faq.q}
                  answer={faq.a}
                  isOpen={openFaq === i}
                  onToggle={() => setOpenFaq(openFaq === i ? null : i)}
                />
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── Section 6: Final CTA ── */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-[600px] h-[600px] rounded-full bg-[#D4A853] opacity-[0.06] blur-[120px]" />
        </div>
        <div className="max-w-[800px] mx-auto px-6 text-center relative z-10">
          <FadeIn>
            <h2 className="font-display text-[32px] md:text-[48px] lg:text-[56px] font-bold text-[#F0EDE8] leading-[1.05] tracking-tight">
              Start Your 14-Day Free Trial
            </h2>
          </FadeIn>
          <FadeIn delay={0.15}>
            <p className="text-[#8A8A96] text-lg leading-relaxed mt-6 max-w-lg mx-auto">
              Join independent drivers who are building their own business, not someone else&apos;s.
            </p>
          </FadeIn>
          <FadeIn delay={0.3}>
            <div className="mt-10">
              <Link
                to="/register"
                className="inline-block px-8 py-4 rounded-full text-sm font-semibold text-[#0A0A0F] bg-[linear-gradient(135deg,#D4A853_0%,#E8C87A_50%,#D4A853_100%)] hover:scale-[1.02] hover:shadow-[0_4px_24px_rgba(212,168,83,0.3)] transition-all duration-200"
              >
                Get Started for Free
              </Link>
              <p className="text-[#5A5A66] text-xs mt-4">
                No credit card required. Cancel anytime.
              </p>
            </div>
          </FadeIn>
        </div>
      </section>
    </div>
  )
}
