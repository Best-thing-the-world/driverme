import { useState, useMemo, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Search,
  MapPin,
  Star,
  Car,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
  X,
  SearchX,
} from 'lucide-react'
import { drivers } from '@/lib/data'
import type { Driver } from '@/types'

const easeSmooth = [0.4, 0, 0.2, 1] as [number, number, number, number]
const easeEnter = [0, 0, 0.2, 1] as [number, number, number, number]

const LOCATIONS = [
  'Atlanta, GA',
  'Miami, FL',
  'Denver, CO',
  'San Francisco, CA',
  'Chicago, IL',
  'Houston, TX',
  'Seattle, WA',
  'New York, NY',
]

const VEHICLE_TYPES = [
  'Luxury Sedan',
  'SUV / Escalade',
  'Tesla / Electric',
  'SUV / Crossover',
  'Van / Shuttle',
  'Classic / Vintage',
]

const SERVICE_TYPES = [
  'Airport Transfer',
  'Hourly Charter',
  'Point-to-Point',
  'Corporate Event',
  'VIP Service',
  'Senior Transport',
]

const SORT_OPTIONS = [
  { label: 'Recommended', value: 'recommended' },
  { label: 'Highest Rated', value: 'rating' },
  { label: 'Most Rides', value: 'rides' },
  { label: 'Lowest Price', value: 'price-low' },
  { label: 'Highest Price', value: 'price-high' },
]

const CARD_STAGGER = 0.08

/* ------------------------------------------------------------------ */
/*  DriverCard                                                         */
/* ------------------------------------------------------------------ */
function DriverCard({ driver, index }: { driver: Driver; index: number }) {
  const vehicleInfo = `${driver.vehicle.make} ${driver.vehicle.model}`
  const vehicleMeta = `${vehicleInfo} \u2022 ${driver.vehicle.capacity} passengers \u2022 ${driver.vehicle.luggage} luggage`

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * CARD_STAGGER, ease: easeEnter }}
    >
      <Link
        to={`/drivers/${driver.id}`}
        className="group block bg-[#141419] border border-[#2A2A35] rounded-2xl overflow-hidden transition-all duration-300 hover:-translate-y-1.5 hover:border-[rgba(212,168,83,0.3)] hover:shadow-[0_12px_40px_rgba(0,0,0,0.4)]"
      >
        {/* Vehicle image */}
        <div className="relative aspect-video overflow-hidden">
          <img
            src={driver.vehicle.image}
            alt={vehicleInfo}
            className="w-full h-full object-cover transition-transform duration-400 group-hover:scale-105"
          />
          <div className="absolute top-3 right-3">
            <span
              className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium ${
                driver.isAvailable
                  ? 'bg-[rgba(34,197,94,0.15)] text-[#22C55E]'
                  : 'bg-[rgba(90,90,102,0.15)] text-[#5A5A66]'
              }`}
            >
              <span
                className={`w-1.5 h-1.5 rounded-full ${
                  driver.isAvailable ? 'bg-[#22C55E]' : 'bg-[#5A5A66]'
                }`}
              />
              {driver.isAvailable ? 'Available' : 'Book Ahead'}
            </span>
          </div>
        </div>

        {/* Content */}
        <div className="p-5">
          {/* Driver row */}
          <div className="flex items-center gap-3">
            <img
              src={driver.avatar}
              alt={driver.name}
              className="w-11 h-11 rounded-full object-cover border-2 border-[#D4A853]"
            />
            <div className="flex items-center gap-2">
              <h4 className="text-lg font-semibold text-[#F0EDE8]">{driver.name}</h4>
              <ShieldCheck size={16} className="text-[#D4A853]" />
            </div>
          </div>

          {/* Location */}
          <div className="flex items-center gap-1.5 mt-2 text-[#5A5A66] text-xs">
            <MapPin size={14} />
            <span>{driver.location}</span>
          </div>

          {/* Tags */}
          <div className="flex flex-wrap gap-2 mt-3">
            {driver.specialties.slice(0, 3).map((tag) => (
              <span
                key={tag}
                className="px-2.5 py-0.5 rounded-full text-xs font-medium border border-[#D4A853]/30 text-[#D4A853]"
              >
                {tag}
              </span>
            ))}
          </div>

          {/* Vehicle info */}
          <div className="flex items-center gap-1.5 mt-2.5 text-[#5A5A66] text-xs">
            <Car size={14} />
            <span>{vehicleMeta}</span>
          </div>

          {/* Bottom row */}
          <div className="flex items-center justify-between mt-4 pt-3 border-t border-[#2A2A35]">
            <div className="flex items-center gap-1.5">
              <Star size={14} className="text-[#D4A853] fill-[#D4A853]" />
              <span className="text-sm font-medium text-[#F0EDE8]">
                {driver.ratings.average}
              </span>
              <span className="text-xs text-[#5A5A66]">
                ({driver.ratings.count})
              </span>
            </div>
            <div className="font-mono text-lg font-bold text-[#D4A853]">
              ${driver.hourlyRate}
              <span className="text-xs font-normal text-[#5A5A66] ml-0.5">/hr</span>
            </div>
          </div>
          <div className="mt-2 text-xs text-[#D4A853] font-medium">
            View Profile &rarr;
          </div>
        </div>
      </Link>
    </motion.div>
  )
}

/* ------------------------------------------------------------------ */
/*  FilterSection (collapsible)                                        */
/* ------------------------------------------------------------------ */
function FilterSection({
  title,
  children,
  defaultOpen = true,
}: {
  title: string
  children: React.ReactNode
  defaultOpen?: boolean
}) {
  const [open, setOpen] = useState(defaultOpen)
  return (
    <div className="mb-4 pb-4 border-b border-[#2A2A35]">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center justify-between w-full text-left mb-3"
      >
        <h5 className="text-sm font-semibold text-[#F0EDE8]">{title}</h5>
        {open ? (
          <ChevronUp size={16} className="text-[#5A5A66]" />
        ) : (
          <ChevronDown size={16} className="text-[#5A5A66]" />
        )}
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            {children}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/*  CustomCheckbox                                                     */
/* ------------------------------------------------------------------ */
function CustomCheckbox({
  checked,
  onChange,
  label,
  count,
}: {
  checked: boolean
  onChange: () => void
  label: string
  count?: number
}) {
  return (
    <label className="flex items-center gap-3 py-1.5 cursor-pointer group">
      <button
        type="button"
        onClick={onChange}
        className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all duration-150 shrink-0 ${
          checked
            ? 'bg-[#D4A853] border-[#D4A853]'
            : 'border-[#2A2A35] bg-[#1E1E26] group-hover:border-[#5A5A66]'
        }`}
      >
        {checked && (
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
            <path
              d="M2.5 6L5 8.5L9.5 4"
              stroke="#0A0A0F"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        )}
      </button>
      <span className="text-sm text-[#8A8A96] group-hover:text-[#F0EDE8] transition-colors flex-1">
        {label}
      </span>
      {count !== undefined && (
        <span className="text-xs text-[#5A5A66]">({count})</span>
      )}
    </label>
  )
}

/* ------------------------------------------------------------------ */
/*  StarRating                                                         */
/* ------------------------------------------------------------------ */
function StarRating({
  value,
  onChange,
}: {
  value: number
  onChange: (v: number) => void
}) {
  return (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map((s) => (
        <button
          key={s}
          onClick={() => onChange(s === value ? 0 : s)}
          className="p-0.5 transition-transform hover:scale-110"
        >
          <Star
            size={22}
            className={
              s <= value
                ? 'text-[#D4A853] fill-[#D4A853]'
                : 'text-[#2A2A35]'
            }
          />
        </button>
      ))}
      <span className="ml-2 text-xs text-[#8A8A96]">{value > 0 ? `${value}.0+` : 'Any'}</span>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/*  Pagination                                                         */
/* ------------------------------------------------------------------ */
function Pagination({
  current,
  total,
  onChange,
}: {
  current: number
  total: number
  onChange: (p: number) => void
}) {
  if (total <= 1) return null
  const pages = Array.from({ length: total }, (_, i) => i + 1)
  return (
    <div className="flex items-center justify-center gap-2 mt-8">
      <button
        onClick={() => onChange(Math.max(1, current - 1))}
        disabled={current === 1}
        className="px-4 py-2 rounded-full text-sm font-medium text-[#8A8A96] border border-[#2A2A35] hover:bg-[#1E1E26] transition-all disabled:opacity-40 disabled:cursor-not-allowed"
      >
        &larr; Previous
      </button>
      {pages.map((p) => (
        <button
          key={p}
          onClick={() => onChange(p)}
          className={`w-10 h-10 rounded-full text-sm font-medium transition-all ${
            p === current
              ? 'bg-[#D4A853] text-[#0A0A0F]'
              : 'text-[#8A8A96] hover:bg-[#1E1E26]'
          }`}
        >
          {p}
        </button>
      ))}
      <button
        onClick={() => onChange(Math.min(total, current + 1))}
        disabled={current === total}
        className="px-4 py-2 rounded-full text-sm font-medium text-[#8A8A96] border border-[#2A2A35] hover:bg-[#1E1E26] transition-all disabled:opacity-40 disabled:cursor-not-allowed"
      >
        Next &rarr;
      </button>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/*  Main Directory Page                                                */
/* ------------------------------------------------------------------ */
export default function Directory() {
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedLocations, setSelectedLocations] = useState<string[]>([])
  const [selectedVehicleTypes, setSelectedVehicleTypes] = useState<string[]>([])
  const [selectedServices, setSelectedServices] = useState<string[]>([])
  const [minRating, setMinRating] = useState(0)
  const [availableOnly, setAvailableOnly] = useState(false)
  const [sortBy, setSortBy] = useState('recommended')
  const [page, setPage] = useState(1)
  const ITEMS_PER_PAGE = 9

  /* Reset page when filters change */
  useEffect(() => {
    setPage(1)
  }, [searchQuery, selectedLocations, selectedVehicleTypes, selectedServices, minRating, availableOnly, sortBy])

  const toggle = (val: string, arr: string[], setArr: (v: string[]) => void) => {
    setArr(arr.includes(val) ? arr.filter((v) => v !== val) : [...arr, val])
  }

  /* Location counts */
  const locationCounts = useMemo(() => {
    const counts: Record<string, number> = {}
    drivers.forEach((d) => {
      counts[d.location] = (counts[d.location] || 0) + 1
    })
    return counts
  }, [])

  /* Filter + sort */
  const filtered = useMemo(() => {
    let result = [...drivers]

    // Search
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase()
      result = result.filter(
        (d) =>
          d.name.toLowerCase().includes(q) ||
          d.location.toLowerCase().includes(q) ||
          d.specialties.some((s) => s.toLowerCase().includes(q)) ||
          d.vehicle.make.toLowerCase().includes(q) ||
          d.vehicle.model.toLowerCase().includes(q)
      )
    }

    // Location
    if (selectedLocations.length) {
      result = result.filter((d) => selectedLocations.includes(d.location))
    }

    // Vehicle type
    if (selectedVehicleTypes.length) {
      result = result.filter((d) => selectedVehicleTypes.includes(d.vehicle.type))
    }

    // Service
    if (selectedServices.length) {
      result = result.filter((d) =>
        d.services.some((s) => selectedServices.includes(s.name))
      )
    }

    // Rating
    if (minRating > 0) {
      result = result.filter((d) => d.ratings.average >= minRating)
    }

    // Availability
    if (availableOnly) {
      result = result.filter((d) => d.isAvailable)
    }

    // Sort
    switch (sortBy) {
      case 'rating':
        result.sort((a, b) => b.ratings.average - a.ratings.average)
        break
      case 'rides':
        result.sort((a, b) => b.totalRides - a.totalRides)
        break
      case 'price-low':
        result.sort((a, b) => a.hourlyRate - b.hourlyRate)
        break
      case 'price-high':
        result.sort((a, b) => b.hourlyRate - a.hourlyRate)
        break
    }

    return result
  }, [searchQuery, selectedLocations, selectedVehicleTypes, selectedServices, minRating, availableOnly, sortBy])

  const totalPages = Math.max(1, Math.ceil(filtered.length / ITEMS_PER_PAGE))
  const paginated = filtered.slice((page - 1) * ITEMS_PER_PAGE, page * ITEMS_PER_PAGE)

  const activeFiltersCount =
    selectedLocations.length +
    selectedVehicleTypes.length +
    selectedServices.length +
    (minRating > 0 ? 1 : 0) +
    (availableOnly ? 1 : 0)

  const clearAll = () => {
    setSelectedLocations([])
    setSelectedVehicleTypes([])
    setSelectedServices([])
    setMinRating(0)
    setAvailableOnly(false)
    setSearchQuery('')
  }

  return (
    <div className="min-h-[100dvh] bg-[#0A0A0F]">
      {/* ========== Section 1: Page Header ========== */}
      <section className="relative py-20 bg-[#0D0D12] border-b border-[#2A2A35] overflow-hidden">
        <img
          src="/map-bg.jpg"
          alt=""
          className="absolute inset-0 w-full h-full object-cover opacity-30"
          style={{ animation: 'ken-burns 10s ease-out forwards' }}
        />
        <div className="relative z-10 max-w-[1280px] mx-auto px-6">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: easeEnter }}
            className="text-xs font-medium tracking-[0.15em] text-[#D4A853] uppercase mb-4"
          >
            Driver Directory
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: easeEnter, delay: 0.1 }}
            className="font-display text-5xl md:text-6xl font-bold text-[#F0EDE8] leading-tight"
          >
            Find Your Perfect Driver
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: easeEnter, delay: 0.2 }}
            className="mt-4 text-lg text-[#8A8A96] max-w-[600px]"
          >
            Browse independent professional chauffeurs by location, vehicle, and
            service. Book directly in minutes.
          </motion.p>

          {/* Search bar */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: easeEnter, delay: 0.35 }}
            className="mt-8 max-w-[640px]"
          >
            <div className="flex items-center bg-[#1E1E26] border border-[#2A2A35] rounded-full h-[52px] px-2 focus-within:border-[#D4A853] focus-within:shadow-[0_0_0_3px_rgba(212,168,83,0.15)] transition-all">
              <Search size={20} className="text-[#5A5A66] ml-4 shrink-0" />
              <input
                type="text"
                placeholder="Search by name, city, or service..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 bg-transparent text-[#F0EDE8] placeholder-[#5A5A66] text-sm px-3 outline-none"
              />
              <button className="px-5 py-2 rounded-full text-sm font-semibold text-[#0A0A0F] bg-gold-shine hover:scale-[1.02] transition-all shrink-0">
                Search
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ========== Section 2: Filters + Results ========== */}
      <section className="max-w-[1280px] mx-auto px-6 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar filters */}
          <aside className="w-full lg:w-[280px] shrink-0">
            <div className="lg:sticky lg:top-[92px] bg-[#0D0D12] lg:border-r lg:border-[#2A2A35] lg:-ml-6 lg:pl-6 lg:-mr-0 lg:pr-6 lg:h-[calc(100vh-92px)] lg:overflow-y-auto pb-4">
              {/* Active filters */}
              {activeFiltersCount > 0 && (
                <div className="mb-4 pb-4 border-b border-[#2A2A35]">
                  <div className="flex items-center justify-between mb-3">
                    <h5 className="text-sm font-semibold text-[#F0EDE8]">
                      Active Filters
                    </h5>
                    <button
                      onClick={clearAll}
                      className="text-xs text-[#D4A853] hover:text-[#E8C87A] transition-colors"
                    >
                      Clear All
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {selectedLocations.map((loc) => (
                      <FilterPill
                        key={loc}
                        label={loc}
                        onRemove={() =>
                          toggle(loc, selectedLocations, setSelectedLocations)
                        }
                      />
                    ))}
                    {selectedVehicleTypes.map((vt) => (
                      <FilterPill
                        key={vt}
                        label={vt}
                        onRemove={() =>
                          toggle(vt, selectedVehicleTypes, setSelectedVehicleTypes)
                        }
                      />
                    ))}
                    {selectedServices.map((svc) => (
                      <FilterPill
                        key={svc}
                        label={svc}
                        onRemove={() =>
                          toggle(svc, selectedServices, setSelectedServices)
                        }
                      />
                    ))}
                    {minRating > 0 && (
                      <FilterPill
                        label={`${minRating}+ Stars`}
                        onRemove={() => setMinRating(0)}
                      />
                    )}
                    {availableOnly && (
                      <FilterPill
                        label="Available Now"
                        onRemove={() => setAvailableOnly(false)}
                      />
                    )}
                  </div>
                </div>
              )}

              <FilterSection title="Location">
                <div className="space-y-0.5 max-h-[220px] overflow-y-auto pr-1">
                  {LOCATIONS.map((loc) => (
                    <CustomCheckbox
                      key={loc}
                      checked={selectedLocations.includes(loc)}
                      onChange={() =>
                        toggle(loc, selectedLocations, setSelectedLocations)
                      }
                      label={loc}
                      count={locationCounts[loc] || 0}
                    />
                  ))}
                </div>
              </FilterSection>

              <FilterSection title="Vehicle Type">
                <div className="space-y-0.5">
                  {VEHICLE_TYPES.map((vt) => (
                    <CustomCheckbox
                      key={vt}
                      checked={selectedVehicleTypes.includes(vt)}
                      onChange={() =>
                        toggle(vt, selectedVehicleTypes, setSelectedVehicleTypes)
                      }
                      label={vt}
                    />
                  ))}
                </div>
              </FilterSection>

              <FilterSection title="Service">
                <div className="space-y-0.5">
                  {SERVICE_TYPES.map((svc) => (
                    <CustomCheckbox
                      key={svc}
                      checked={selectedServices.includes(svc)}
                      onChange={() =>
                        toggle(svc, selectedServices, setSelectedServices)
                      }
                      label={svc}
                    />
                  ))}
                </div>
              </FilterSection>

              <FilterSection title="Minimum Rating">
                <StarRating value={minRating} onChange={setMinRating} />
              </FilterSection>

              <FilterSection title="Availability">
                <label className="flex items-center gap-3 cursor-pointer">
                  <button
                    type="button"
                    onClick={() => setAvailableOnly(!availableOnly)}
                    className={`relative w-10 h-6 rounded-full transition-colors duration-200 ${
                      availableOnly ? 'bg-[#22C55E]' : 'bg-[#2A2A35]'
                    }`}
                  >
                    <span
                      className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform duration-200 ${
                        availableOnly ? 'translate-x-4' : 'translate-x-0'
                      }`}
                    />
                  </button>
                  <span className="flex items-center gap-1.5 text-sm text-[#8A8A96]">
                    <span className="w-2 h-2 rounded-full bg-[#22C55E]" />
                    Available Now
                  </span>
                </label>
              </FilterSection>
            </div>
          </aside>

          {/* Right content area */}
          <div className="flex-1 min-w-0">
            {/* Results bar */}
            <div className="flex items-center justify-between mb-6">
              <p className="text-sm text-[#F0EDE8]">
                Showing <span className="font-semibold">{filtered.length}</span>{' '}
                drivers
              </p>
              <div className="flex items-center gap-2">
                <span className="text-xs text-[#5A5A66]">Sort by:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="bg-[#1E1E26] border border-[#2A2A35] rounded-lg px-3 py-2 text-sm text-[#F0EDE8] outline-none focus:border-[#D4A853]"
                >
                  {SORT_OPTIONS.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Empty state */}
            {filtered.length === 0 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col items-center justify-center py-24"
              >
                <SearchX size={64} className="text-[#5A5A66] mb-4" />
                <h3 className="text-xl font-semibold text-[#F0EDE8] mb-2">
                  No drivers match your filters
                </h3>
                <p className="text-sm text-[#5A5A66] mb-6 text-center max-w-[400px]">
                  Try adjusting your search or filters to find more drivers.
                </p>
                <button
                  onClick={clearAll}
                  className="px-6 py-2.5 rounded-full text-sm font-semibold text-[#D4A853] border border-[#D4A853] hover:bg-[rgba(212,168,83,0.1)] transition-all"
                >
                  Clear All Filters
                </button>
              </motion.div>
            )}

            {/* Driver grid */}
            {filtered.length > 0 && (
              <>
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, ease: easeSmooth }}
                  className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6"
                >
                  {paginated.map((driver, i) => (
                    <DriverCard key={driver.id} driver={driver} index={i} />
                  ))}
                </motion.div>
                <Pagination
                  current={page}
                  total={totalPages}
                  onChange={setPage}
                />
              </>
            )}
          </div>
        </div>
      </section>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/*  FilterPill                                                         */
/* ------------------------------------------------------------------ */
function FilterPill({ label, onRemove }: { label: string; onRemove: () => void }) {
  return (
    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-[#1E1E26] text-[#8A8A96] border border-[#2A2A35]">
      {label}
      <button onClick={onRemove} className="hover:text-[#F0EDE8] transition-colors">
        <X size={12} />
      </button>
    </span>
  )
}
