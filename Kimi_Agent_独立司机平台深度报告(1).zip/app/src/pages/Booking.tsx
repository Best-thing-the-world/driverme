import { useState, useMemo } from 'react'
import { useParams, useSearchParams, Link, useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  ChevronLeft,
  Plane,
  Clock,
  MapPin,
  Briefcase,
  Crown,
  Heart,
  ShoppingBag,
  Car,
  Calendar as CalendarIcon,
  Users,
  ArrowRight,
  CheckCircle,
  ChevronRight,
  ChevronLeft as ChevronLeftIcon,
} from 'lucide-react'
import { getDriverById } from '@/lib/data'
import type { Driver, Service, BookingFormData } from '@/types'
import {
  format,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  isSameDay,
  addMonths,
  subMonths,
  getDay,
} from 'date-fns'

const easeEnter = [0, 0, 0.2, 1] as [number, number, number, number]
const easeSmooth = [0.4, 0, 0.2, 1] as [number, number, number, number]
const easeBounce = [0.34, 1.56, 0.64, 1] as [number, number, number, number]

const iconMap: Record<string, React.ElementType> = {
  Plane, Clock, MapPin, Briefcase, Crown, Heart, ShoppingBag,
}

const STEP_LABELS = ['Service', 'Date & Time', 'Details', 'Confirm']

const TIME_SLOTS = [
  '6:00 AM', '7:00 AM', '8:00 AM', '9:00 AM', '10:00 AM', '11:00 AM',
  '12:00 PM', '1:00 PM', '2:00 PM', '3:00 PM', '4:00 PM', '5:00 PM',
  '6:00 PM', '7:00 PM', '8:00 PM',
]

/* ================================================================== */
/*  Helper components                                                  */
/* ================================================================== */

function ServiceIcon({ iconName, size = 24 }: { iconName: string; size?: number }) {
  const Icon = iconMap[iconName] || Car
  return <Icon size={size} className="text-[#D4A853]" />
}

function ProgressBar({ step }: { step: number }) {
  const progress = (step / 4) * 100
  return (
    <div className="w-full">
      {/* Step labels */}
      <div className="max-w-[600px] mx-auto px-6 flex items-center justify-between mb-2">
        {STEP_LABELS.map((label, i) => {
          const completed = i + 1 < step
          const active = i + 1 === step
          return (
            <div key={label} className="flex flex-col items-center gap-1">
              <span
                className={`text-xs font-medium transition-colors duration-300 ${
                  completed || active ? 'text-[#D4A853]' : 'text-[#5A5A66]'
                }`}
              >
                {label}
              </span>
              <div className="h-1.5 flex items-center justify-center">
                {completed ? (
                  <CheckCircle size={14} className="text-[#D4A853]" />
                ) : active ? (
                  <span className="w-1.5 h-1.5 rounded-full bg-[#D4A853] animate-pulse" />
                ) : (
                  <span className="w-1.5 h-1.5 rounded-full bg-[#2A2A35]" />
                )}
              </div>
            </div>
          )
        })}
      </div>
      {/* Bar */}
      <div className="h-1 bg-[#1E1E26] w-full">
        <motion.div
          className="h-full bg-gold-shine"
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 0.3, ease: easeSmooth }}
        />
      </div>
    </div>
  )
}

/* ================================================================== */
/*  Step 1: Select Service                                             */
/* ================================================================== */
function Step1SelectService({
  driver,
  selectedServiceId,
  onSelect,
  onContinue,
}: {
  driver: Driver
  selectedServiceId: string
  onSelect: (id: string) => void
  onContinue: () => void
}) {
  return (
    <div className="max-w-[800px] mx-auto px-6 py-12">
      <Link
        to={`/drivers/${driver.id}`}
        className="inline-flex items-center gap-2 text-sm text-[#D4A853] hover:text-[#E8C87A] transition-colors mb-6"
      >
        <ChevronLeft size={16} />
        Back to {driver.name.split(' ')[0]}&apos;s Profile
      </Link>
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: easeEnter }}
        className="text-3xl md:text-4xl font-bold text-[#F0EDE8]"
      >
        Choose Your Service
      </motion.h1>
      <motion.p
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1, ease: easeEnter }}
        className="mt-2 text-[#8A8A96]"
      >
        Select the service that best fits your transportation needs.
      </motion.p>

      <div className="mt-8 space-y-4">
        {driver.services.map((svc, i) => {
          const selected = selectedServiceId === svc.id
          return (
            <motion.button
              key={svc.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: i * 0.08, ease: easeEnter }}
              onClick={() => onSelect(svc.id)}
              className={`w-full flex items-center gap-5 text-left p-6 rounded-2xl border transition-all duration-200 ${
                selected
                  ? 'border-2 border-[#D4A853] bg-[rgba(212,168,83,0.05)] shadow-[0_0_20px_rgba(212,168,83,0.1)] scale-[1.01]'
                  : 'border-[#2A2A35] bg-[#141419] hover:-translate-y-0.5 hover:border-[rgba(212,168,83,0.3)]'
              }`}
            >
              {/* Icon */}
              <div className="w-14 h-14 rounded-2xl bg-[rgba(212,168,83,0.1)] flex items-center justify-center shrink-0">
                <ServiceIcon iconName={svc.icon} size={28} />
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <h3 className="text-lg font-semibold text-[#F0EDE8]">
                  {svc.name}
                </h3>
                <p className="mt-1 text-sm text-[#8A8A96]">{svc.description}</p>
                {svc.duration && (
                  <p className="mt-1 text-xs text-[#5A5A66]">{svc.duration}</p>
                )}
              </div>

              {/* Price */}
              <div className="text-right shrink-0">
                <div className="font-mono text-2xl font-bold text-[#D4A853]">
                  ${svc.basePrice}
                </div>
                <div className="text-xs text-[#5A5A66]">/{svc.priceUnit}</div>
              </div>

              {/* Check */}
              {selected && (
                <div className="w-6 h-6 rounded-full bg-[#D4A853] flex items-center justify-center shrink-0">
                  <CheckCircle size={16} className="text-[#0A0A0F]" />
                </div>
              )}
            </motion.button>
          )
        })}
      </div>

      {/* Sticky action bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-[#141419] border-t border-[#2A2A35] px-6 py-4 z-40">
        <div className="max-w-[800px] mx-auto flex items-center justify-between">
          <div>
            {selectedServiceId && (
              <p className="text-sm text-[#8A8A96]">
                {driver.services.find((s) => s.id === selectedServiceId)?.name}
                {' — '}
                <span className="text-[#D4A853] font-mono font-semibold">
                  ${driver.services.find((s) => s.id === selectedServiceId)?.basePrice}
                </span>
              </p>
            )}
          </div>
          <button
            onClick={onContinue}
            disabled={!selectedServiceId}
            className="px-6 py-3 rounded-full text-sm font-semibold text-[#0A0A0F] bg-gold-shine hover:scale-[1.02] transition-all disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:scale-100"
          >
            Continue &rarr;
          </button>
        </div>
      </div>
    </div>
  )
}

/* ================================================================== */
/*  Step 2: Date & Time                                                */
/* ================================================================== */
function Step2DateTime({
  selectedService,
  selectedDate,
  selectedTime,
  onSelectDate,
  onSelectTime,
  onContinue,
  onBack,
}: {
  selectedService: Service | undefined
  selectedDate: Date | null
  selectedTime: string
  onSelectDate: (d: Date) => void
  onSelectTime: (t: string) => void
  onContinue: () => void
  onBack: () => void
}) {
  const [currentMonth, setCurrentMonth] = useState(new Date())

  const monthStart = startOfMonth(currentMonth)
  const monthEnd = endOfMonth(currentMonth)
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd })
  const startDay = getDay(monthStart)

  const prevMonth = () => setCurrentMonth((m) => subMonths(m, 1))
  const nextMonth = () => setCurrentMonth((m) => addMonths(m, 1))

  // Simulate some unavailable days
  const isUnavailable = (day: Date) => {
    const dayOfWeek = getDay(day)
    return dayOfWeek === 0 // Sundays unavailable
  }

  const dayLabels = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa']

  return (
    <div className="max-w-[900px] mx-auto px-6 py-12">
      <button
        onClick={onBack}
        className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm text-[#F0EDE8] border border-[#2A2A35] hover:bg-[#1E1E26] transition-all mb-6"
      >
        <ChevronLeft size={16} />
        Back
      </button>
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: easeEnter }}
        className="text-3xl md:text-4xl font-bold text-[#F0EDE8]"
      >
        When Do You Need Your Ride?
      </motion.h1>
      <motion.p
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1, ease: easeEnter }}
        className="mt-2 text-[#8A8A96]"
      >
        Select a date and available time slot.
      </motion.p>

      <div className="grid grid-cols-1 md:grid-cols-[55%_45%] gap-8 mt-8">
        {/* Calendar */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.4, ease: easeSmooth }}
          className="bg-[#141419] border border-[#2A2A35] rounded-2xl p-6"
        >
          {/* Month nav */}
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={prevMonth}
              className="w-9 h-9 rounded-lg bg-[#1E1E26] flex items-center justify-center text-[#8A8A96] hover:text-[#F0EDE8] transition-colors"
            >
              <ChevronLeftIcon size={18} />
            </button>
            <h3 className="text-lg font-semibold text-[#F0EDE8]">
              {format(currentMonth, 'MMMM yyyy')}
            </h3>
            <button
              onClick={nextMonth}
              className="w-9 h-9 rounded-lg bg-[#1E1E26] flex items-center justify-center text-[#8A8A96] hover:text-[#F0EDE8] transition-colors"
            >
              <ChevronRight size={18} />
            </button>
          </div>

          {/* Day headers */}
          <div className="grid grid-cols-7 gap-1 mb-1">
            {dayLabels.map((d) => (
              <div
                key={d}
                className="text-center text-xs font-medium text-[#5A5A66] py-2"
              >
                {d}
              </div>
            ))}
          </div>

          {/* Days grid */}
          <div className="grid grid-cols-7 gap-1">
            {Array.from({ length: startDay }).map((_, i) => (
              <div key={`empty-${i}`} />
            ))}
            {days.map((day) => {
              const unavailable = isUnavailable(day)
              const selected = selectedDate ? isSameDay(day, selectedDate) : false
              const today = isSameDay(day, new Date())

              return (
                <button
                  key={day.toISOString()}
                  onClick={() => !unavailable && onSelectDate(day)}
                  disabled={unavailable}
                  className={`w-10 h-10 rounded-lg text-sm font-medium transition-all mx-auto ${
                    selected
                      ? 'bg-[#D4A853] text-[#0A0A0F] font-bold'
                      : unavailable
                      ? 'text-[#5A5A66] cursor-not-allowed opacity-40'
                      : today
                      ? 'text-[#F0EDE8] ring-1 ring-[#D4A853] hover:bg-[#1E1E26]'
                      : 'text-[#F0EDE8] hover:bg-[#1E1E26]'
                  }`}
                >
                  {format(day, 'd')}
                </button>
              )
            })}
          </div>
        </motion.div>

        {/* Time slots */}
        <AnimatePresence mode="wait">
          {selectedDate && (
            <motion.div
              key={selectedDate.toISOString()}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3, ease: easeSmooth }}
            >
              <h4 className="text-lg font-semibold text-[#F0EDE8] mb-4">
                Available Times for{' '}
                <span className="text-[#D4A853]">
                  {format(selectedDate, 'MMM d, yyyy')}
                </span>
              </h4>
              <div className="grid grid-cols-3 gap-2">
                {TIME_SLOTS.map((slot) => {
                  const booked = slot === '1:00 PM' || slot === '5:00 PM'
                  return (
                    <button
                      key={slot}
                      onClick={() => !booked && onSelectTime(slot)}
                      disabled={booked}
                      className={`py-2.5 px-3 rounded-lg text-xs font-medium transition-all border ${
                        selectedTime === slot
                          ? 'bg-[#D4A853] text-[#0A0A0F] border-[#D4A853] font-bold'
                          : booked
                          ? 'bg-transparent text-[#5A5A66] border-[#2A2A35] opacity-40 line-through cursor-not-allowed'
                          : 'bg-[#1E1E26] text-[#F0EDE8] border-[#2A2A35] hover:bg-[#252530]'
                      }`}
                    >
                      {slot}
                    </button>
                  )
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Sticky action bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-[#141419] border-t border-[#2A2A35] px-6 py-4 z-40">
        <div className="max-w-[900px] mx-auto flex items-center justify-between">
          <div className="text-sm text-[#8A8A96]">
            {selectedService && selectedDate && selectedTime && (
              <>
                {selectedService.name} —{' '}
                {format(selectedDate, 'MMM d, yyyy')} — {selectedTime}
              </>
            )}
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="px-5 py-2.5 rounded-full text-sm font-semibold text-[#F0EDE8] border border-[#2A2A35] hover:bg-[#1E1E26] transition-all"
            >
              Back
            </button>
            <button
              onClick={onContinue}
              disabled={!selectedDate || !selectedTime}
              className="px-6 py-3 rounded-full text-sm font-semibold text-[#0A0A0F] bg-gold-shine hover:scale-[1.02] transition-all disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Continue &rarr;
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

/* ================================================================== */
/*  Step 3: Booking Details                                            */
/* ================================================================== */
function Step3Details({
  selectedService,
  selectedDate,
  selectedTime,
  formData,
  onUpdate,
  onContinue,
  onBack,
}: {
  selectedService: Service | undefined
  selectedDate: Date | null
  selectedTime: string
  formData: BookingFormData
  onUpdate: (data: Partial<BookingFormData>) => void
  onContinue: () => void
  onBack: () => void
}) {
  const [errors, setErrors] = useState<Record<string, string>>({})

  const validate = () => {
    const newErrors: Record<string, string> = {}
    if (!formData.pickupLocation.trim()) newErrors.pickupLocation = 'Pickup location is required'
    if (!formData.dropoffLocation.trim()) newErrors.dropoffLocation = 'Drop-off location is required'
    if (formData.passengers < 1) newErrors.passengers = 'Select at least 1 passenger'

    // Service-specific validation
    if (selectedService) {
      selectedService.fields.forEach((field) => {
        if (field.required) {
          const val = (formData as unknown as Record<string, unknown>)[field.name]
          if (!val || (typeof val === 'string' && !val.trim())) {
            newErrors[field.name] = `${field.label} is required`
          }
        }
      })
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleContinue = () => {
    if (validate()) onContinue()
  }

  // Price calculation
  const basePrice = selectedService?.basePrice || 0
  const gratuity = basePrice * 0.2
  const meetGreetFee = formData.pickupType === 'Meet & Greet Inside (+$15)' ? 15 : 0
  const total = basePrice + gratuity + meetGreetFee

  const inputClass = (field: string) =>
    `w-full bg-[#1E1E26] border ${
      errors[field] ? 'border-[#EF4444]' : 'border-[#2A2A35] focus:border-[#D4A853]'
    } rounded-lg px-4 py-3 text-sm text-[#F0EDE8] placeholder-[#5A5A66] outline-none transition-all focus:shadow-[0_0_0_3px_rgba(212,168,83,0.15)]`

  return (
    <div className="max-w-[900px] mx-auto px-6 py-12">
      <button
        onClick={onBack}
        className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm text-[#F0EDE8] border border-[#2A2A35] hover:bg-[#1E1E26] transition-all mb-6"
      >
        <ChevronLeft size={16} />
        Back
      </button>
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: easeEnter }}
        className="text-3xl md:text-4xl font-bold text-[#F0EDE8]"
      >
        Trip Details
      </motion.h1>
      <motion.p
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1, ease: easeEnter }}
        className="mt-2 text-[#8A8A96]"
      >
        A few details to make your ride perfect.
      </motion.p>

      <div className="grid grid-cols-1 lg:grid-cols-[60%_40%] gap-8 mt-8">
        {/* Form */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: easeEnter }}
          className="space-y-5"
        >
          {/* Pickup */}
          <div>
            <label className="block text-xs text-[#8A8A96] mb-1">
              Pickup Location <span className="text-[#EF4444]">*</span>
            </label>
            <div className="relative">
              <MapPin
                size={16}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-[#5A5A66]"
              />
              <input
                type="text"
                placeholder="Enter pickup address"
                value={formData.pickupLocation}
                onChange={(e) => onUpdate({ pickupLocation: e.target.value })}
                className={`${inputClass('pickupLocation')} pl-10`}
              />
            </div>
            {errors.pickupLocation && (
              <p className="mt-1 text-xs text-[#EF4444]">{errors.pickupLocation}</p>
            )}
          </div>

          {/* Dropoff */}
          <div>
            <label className="block text-xs text-[#8A8A96] mb-1">
              Drop-off Location <span className="text-[#EF4444]">*</span>
            </label>
            <div className="relative">
              <MapPin
                size={16}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-[#5A5A66]"
              />
              <input
                type="text"
                placeholder="Enter destination"
                value={formData.dropoffLocation}
                onChange={(e) => onUpdate({ dropoffLocation: e.target.value })}
                className={`${inputClass('dropoffLocation')} pl-10`}
              />
            </div>
            {errors.dropoffLocation && (
              <p className="mt-1 text-xs text-[#EF4444]">{errors.dropoffLocation}</p>
            )}
          </div>

          {/* Passengers */}
          <div>
            <label className="block text-xs text-[#8A8A96] mb-1">
              Number of Passengers <span className="text-[#EF4444]">*</span>
            </label>
            <div className="relative">
              <Users
                size={16}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-[#5A5A66]"
              />
              <select
                value={formData.passengers}
                onChange={(e) =>
                  onUpdate({ passengers: parseInt(e.target.value) })
                }
                className={`${inputClass('passengers')} pl-10 appearance-none`}
              >
                {[1, 2, 3, 4, 5, 6].map((n) => (
                  <option key={n} value={n}>
                    {n} {n === 1 ? 'passenger' : 'passengers'}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Dynamic fields based on service */}
          {selectedService?.fields.map((field, idx) => (
            <motion.div
              key={field.name}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: idx * 0.05, ease: easeEnter }}
            >
              <label className="block text-xs text-[#8A8A96] mb-1">
                {field.label}
                {field.required && <span className="text-[#EF4444]"> *</span>}
              </label>

              {field.type === 'select' && field.options ? (
                <select
                  value={String((formData as unknown as Record<string, unknown>)[field.name] || '')}
                  onChange={(e) =>
                    onUpdate({ [field.name]: e.target.value } as Partial<BookingFormData>)
                  }
                  className={inputClass(field.name)}
                >
                  <option value="">Select {field.label}</option>
                  {field.options.map((opt) => (
                    <option key={opt} value={opt}>
                      {opt}
                    </option>
                  ))}
                </select>
              ) : field.type === 'textarea' ? (
                <textarea
                  placeholder={field.placeholder}
                  rows={3}
                  value={String((formData as unknown as Record<string, unknown>)[field.name] || '')}
                  onChange={(e) =>
                    onUpdate({ [field.name]: e.target.value } as Partial<BookingFormData>)
                  }
                  className={inputClass(field.name)}
                />
              ) : field.type === 'radio' && field.options ? (
                <div className="flex gap-4 mt-1">
                  {field.options.map((opt) => (
                    <label key={opt} className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name={field.name}
                        value={opt}
                        checked={
                          (formData as unknown as Record<string, unknown>)[field.name] === opt
                        }
                        onChange={(e) =>
                          onUpdate({
                            [field.name]: e.target.value,
                          } as Partial<BookingFormData>)
                        }
                        className="w-4 h-4 accent-[#D4A853]"
                      />
                      <span className="text-sm text-[#F0EDE8]">{opt}</span>
                    </label>
                  ))}
                </div>
              ) : (
                <input
                  type={field.type === 'number' ? 'number' : 'text'}
                  placeholder={field.placeholder}
                  value={String((formData as unknown as Record<string, unknown>)[field.name] || '')}
                  onChange={(e) =>
                    onUpdate({ [field.name]: e.target.value } as Partial<BookingFormData>)
                  }
                  className={inputClass(field.name)}
                />
              )}
              {errors[field.name] && (
                <p className="mt-1 text-xs text-[#EF4444]">{errors[field.name]}</p>
              )}
            </motion.div>
          ))}

          {/* Special requests (all services) */}
          <div>
            <label className="block text-xs text-[#8A8A96] mb-1">
              Special Requests
            </label>
            <textarea
              placeholder="Any special requirements..."
              rows={3}
              value={formData.specialRequests}
              onChange={(e) => onUpdate({ specialRequests: e.target.value })}
              className={inputClass('specialRequests')}
            />
          </div>
        </motion.div>

        {/* Booking Summary */}
        <motion.div
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2, ease: easeEnter }}
          className="lg:sticky lg:top-[120px] self-start"
        >
          <div className="bg-[#141419] border border-[#2A2A35] rounded-2xl p-6">
            <h4 className="text-lg font-semibold text-[#F0EDE8] mb-4">
              Booking Summary
            </h4>
            <div className="h-px bg-[#2A2A35] mb-4" />

            {selectedService && (
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <ServiceIcon iconName={selectedService.icon} size={18} />
                  <div className="flex-1">
                    <p className="text-sm text-[#F0EDE8]">{selectedService.name}</p>
                  </div>
                  <span className="font-mono text-sm font-semibold text-[#D4A853]">
                    ${basePrice.toFixed(2)}
                  </span>
                </div>

                {selectedDate && (
                  <div className="flex items-center gap-3">
                    <CalendarIcon size={16} className="text-[#5A5A66]" />
                    <p className="text-sm text-[#8A8A96]">
                      {format(selectedDate, 'EEEE, MMMM d, yyyy')}
                    </p>
                  </div>
                )}
                {selectedTime && (
                  <div className="flex items-center gap-3">
                    <Clock size={16} className="text-[#5A5A66]" />
                    <p className="text-sm text-[#8A8A96]">{selectedTime}</p>
                  </div>
                )}

                <div className="flex items-center gap-2 mt-2">
                  <MapPin size={14} className="text-[#5A5A66]" />
                  <p className="text-xs text-[#8A8A96] truncate">
                    {formData.pickupLocation || 'Pickup location'}
                  </p>
                  <ArrowRight size={12} className="text-[#5A5A66] shrink-0" />
                  <MapPin size={14} className="text-[#5A5A66]" />
                  <p className="text-xs text-[#8A8A96] truncate">
                    {formData.dropoffLocation || 'Destination'}
                  </p>
                </div>

                <div className="h-px bg-[#2A2A35] my-4" />

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-[#8A8A96]">Base rate</span>
                    <span className="text-[#F0EDE8]">${basePrice.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-[#8A8A96]">Gratuity (20%)</span>
                    <span className="text-[#F0EDE8]">${gratuity.toFixed(2)}</span>
                  </div>
                  {meetGreetFee > 0 && (
                    <div className="flex justify-between text-sm">
                      <span className="text-[#8A8A96]">Meet &amp; Greet</span>
                      <span className="text-[#F0EDE8]">${meetGreetFee.toFixed(2)}</span>
                    </div>
                  )}
                </div>

                <div className="h-px bg-[#2A2A35] my-4" />

                <div className="flex justify-between items-center">
                  <span className="text-base font-semibold text-[#F0EDE8]">Total</span>
                  <span className="font-mono text-2xl font-bold text-[#D4A853]">
                    ${total.toFixed(2)}
                  </span>
                </div>

                <p className="text-xs text-[#5A5A66] mt-2">
                  You&apos;ll pay after the ride. No upfront payment required.
                </p>
              </div>
            )}
          </div>
        </motion.div>
      </div>

      {/* Sticky action bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-[#141419] border-t border-[#2A2A35] px-6 py-4 z-40">
        <div className="max-w-[900px] mx-auto flex items-center justify-between">
          <button
            onClick={onBack}
            className="px-5 py-2.5 rounded-full text-sm font-semibold text-[#F0EDE8] border border-[#2A2A35] hover:bg-[#1E1E26] transition-all"
          >
            &larr; Back
          </button>
          <button
            onClick={handleContinue}
            className="px-6 py-3 rounded-full text-sm font-semibold text-[#0A0A0F] bg-gold-shine hover:scale-[1.02] transition-all"
          >
            Review Booking &rarr;
          </button>
        </div>
      </div>
    </div>
  )
}

/* ================================================================== */
/*  Step 4: Confirmation                                               */
/* ================================================================== */
function Step4Confirmation({
  driver,
  selectedService,
  selectedDate,
  selectedTime,
  formData,
}: {
  driver: Driver
  selectedService: Service | undefined
  selectedDate: Date | null
  selectedTime: string
  formData: BookingFormData
  onReset: () => void
}) {
  const bookingId = `DL-2025-${String(Math.floor(Math.random() * 9000) + 1000)}`
  const navigate = useNavigate()

  return (
    <div className="max-w-[640px] mx-auto px-6 py-12 text-center">
      {/* Success icon */}
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.6, ease: easeBounce }}
        className="w-[120px] h-[120px] rounded-full border-[3px] border-[#D4A853] flex items-center justify-center mx-auto mb-6"
      >
        <motion.div
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 0.4, delay: 0.3 }}
        >
          <CheckCircle size={64} className="text-[#D4A853]" />
        </motion.div>
      </motion.div>

      <motion.h1
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.5 }}
        className="text-3xl md:text-4xl font-bold text-[#F0EDE8]"
      >
        Booking Request Sent!
      </motion.h1>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.6 }}
        className="mt-3 text-[#8A8A96]"
      >
        {driver.name.split(' ')[0]} has been notified and will confirm your
        booking shortly. You&apos;ll receive an email confirmation once accepted.
      </motion.p>

      {/* Booking reference card */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.7, ease: easeEnter }}
        className="mt-8 bg-[#141419] border border-[#2A2A35] rounded-2xl p-6 text-left"
      >
        <div className="flex items-center justify-between mb-4">
          <span className="font-mono text-sm font-bold text-[#D4A853] tracking-[0.05em]">
            {bookingId}
          </span>
          <span className="px-2 py-1 rounded-full text-xs font-medium bg-[rgba(59,130,246,0.1)] text-[#3B82F6]">
            New
          </span>
        </div>
        <div className="h-px bg-[#2A2A35] mb-4" />

        <div className="space-y-3">
          {selectedService && (
            <div className="flex items-center gap-3">
              <ServiceIcon iconName={selectedService.icon} size={16} />
              <span className="text-sm text-[#F0EDE8]">{selectedService.name}</span>
            </div>
          )}
          {selectedDate && (
            <div className="flex items-center gap-3">
              <CalendarIcon size={16} className="text-[#5A5A66]" />
              <span className="text-sm text-[#8A8A96]">
                {format(selectedDate, 'EEEE, MMMM d, yyyy')}
              </span>
            </div>
          )}
          {selectedTime && (
            <div className="flex items-center gap-3">
              <Clock size={16} className="text-[#5A5A66]" />
              <span className="text-sm text-[#8A8A96]">{selectedTime}</span>
            </div>
          )}
          <div className="flex items-center gap-3">
            <MapPin size={16} className="text-[#5A5A66]" />
            <span className="text-sm text-[#8A8A96]">{formData.pickupLocation}</span>
          </div>
          <div className="flex items-center gap-3">
            <MapPin size={16} className="text-[#5A5A66]" />
            <span className="text-sm text-[#8A8A96]">{formData.dropoffLocation}</span>
          </div>
          <div className="flex items-center gap-3">
            <Users size={16} className="text-[#5A5A66]" />
            <span className="text-sm text-[#8A8A96]">
              {formData.passengers} {formData.passengers === 1 ? 'passenger' : 'passengers'}
            </span>
          </div>
        </div>

        <div className="h-px bg-[#2A2A35] my-4" />

        {selectedService && (
          <div className="flex justify-between items-center">
            <span className="text-sm text-[#8A8A96]">Total</span>
            <span className="font-mono text-2xl font-bold text-[#D4A853]">
              ${(selectedService.basePrice * 1.2).toFixed(2)}
            </span>
          </div>
        )}
      </motion.div>

      {/* Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 1.0, ease: easeEnter }}
        className="flex flex-wrap items-center justify-center gap-3 mt-8"
      >
        <button
          onClick={() => alert('Calendar export coming soon!')}
          className="px-6 py-3 rounded-full text-sm font-semibold text-[#D4A853] border border-[#D4A853] hover:bg-[rgba(212,168,83,0.1)] transition-all"
        >
          Add to Calendar
        </button>
        <button
          onClick={() => navigate('/dashboard/bookings')}
          className="px-6 py-3 rounded-full text-sm font-semibold text-[#F0EDE8] border border-[#2A2A35] hover:bg-[#1E1E26] transition-all"
        >
          View My Bookings
        </button>
      </motion.div>

      <motion.button
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, delay: 1.1 }}
        onClick={() => navigate(`/drivers/${driver.id}`)}
        className="mt-4 text-sm text-[#D4A853] hover:text-[#E8C87A] transition-colors"
      >
        Back to {driver.name.split(' ')[0]}&apos;s Profile
      </motion.button>

      {/* What's next accordion */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, delay: 1.2 }}
        className="mt-8 text-left"
      >
        <details className="bg-[#141419] border border-[#2A2A35] rounded-xl p-4">
          <summary className="text-sm font-semibold text-[#F0EDE8] cursor-pointer">
            What happens next?
          </summary>
          <div className="mt-3 text-xs text-[#8A8A96] space-y-2">
            <p>1. {driver.name.split(' ')[0]} will review and accept your request (usually within 1 hour).</p>
            <p>2. You&apos;ll receive an email with confirmation details.</p>
            <p>3. {driver.name.split(' ')[0]} will contact you directly with any questions.</p>
            <p>4. Payment is processed after the ride is completed.</p>
          </div>
        </details>
      </motion.div>
    </div>
  )
}

/* ================================================================== */
/*  Main Booking Page                                                  */
/* ================================================================== */
export default function Booking() {
  const { driverId } = useParams<{ driverId: string }>()
  const [searchParams] = useSearchParams()

  const driver = useMemo(() => getDriverById(driverId || ''), [driverId])

  const preselectedService = searchParams.get('service') || ''

  const [step, setStep] = useState(1)
  const [selectedServiceId, setSelectedServiceId] = useState(preselectedService)
  const [selectedDate, setSelectedDate] = useState<Date | null>(null)
  const [selectedTime, setSelectedTime] = useState('')
  const [formData, setFormData] = useState<BookingFormData>({
    serviceId: preselectedService,
    date: '',
    time: '',
    pickupLocation: '',
    dropoffLocation: '',
    passengers: 1,
    specialRequests: '',
    flightNumber: '',
    airport: '',
    pickupType: '',
    luggageCount: undefined,
    hours: undefined,
    itineraryNotes: '',
    companyName: '',
    eventType: '',
  })

  const selectedService = useMemo(
    () => driver?.services.find((s) => s.id === selectedServiceId),
    [driver, selectedServiceId]
  )

  const updateForm = (data: Partial<BookingFormData>) => {
    setFormData((prev) => ({ ...prev, ...data }))
  }

  const handleReset = () => {
    setStep(1)
    setSelectedServiceId('')
    setSelectedDate(null)
    setSelectedTime('')
    setFormData({
      serviceId: '',
      date: '',
      time: '',
      pickupLocation: '',
      dropoffLocation: '',
      passengers: 1,
      specialRequests: '',
      flightNumber: '',
      airport: '',
      pickupType: '',
      luggageCount: undefined,
      hours: undefined,
      itineraryNotes: '',
      companyName: '',
      eventType: '',
    })
  }

  if (!driver) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center text-center px-6">
        <h1 className="font-display text-4xl text-[#F0EDE8] mb-4">
          Driver Not Found
        </h1>
        <p className="text-[#8A8A96] mb-6">
          The driver you&apos;re trying to book doesn&apos;t exist.
        </p>
        <Link
          to="/drivers"
          className="px-6 py-2.5 rounded-full text-sm font-semibold text-[#0A0A0F] bg-gold-shine hover:scale-[1.02] transition-all"
        >
          Browse All Drivers
        </Link>
      </div>
    )
  }

  return (
    <div className="min-h-[100dvh] bg-[#0A0A0F] pb-24">
      {/* Simplified navbar */}
      <div className="h-14 flex items-center border-b border-[#2A2A35] bg-[#0A0A0F]/90 backdrop-blur-[20px]">
        <div className="max-w-[1280px] mx-auto w-full px-6 flex items-center justify-between">
          <Link
            to="/"
            className="flex items-center gap-2"
          >
            <div className="w-8 h-8 rounded-full bg-gold-shine flex items-center justify-center">
              <span className="font-display font-bold text-[#0A0A0F] text-sm">DL</span>
            </div>
          </Link>
          <span className="text-sm text-[#8A8A96]">
            Booking with{' '}
            <span className="text-[#F0EDE8] font-medium">{driver.name}</span>
          </span>
          <Link
            to={`/drivers/${driver.id}`}
            className="text-xs text-[#D4A853] hover:text-[#E8C87A] transition-colors"
          >
            Cancel
          </Link>
        </div>
      </div>

      {/* Progress bar */}
      <ProgressBar step={step} />

      {/* Step content */}
      <AnimatePresence mode="wait">
        {step === 1 && (
          <motion.div
            key="step1"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Step1SelectService
              driver={driver}
              selectedServiceId={selectedServiceId}
              onSelect={setSelectedServiceId}
              onContinue={() => setStep(2)}
            />
          </motion.div>
        )}
        {step === 2 && (
          <motion.div
            key="step2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Step2DateTime
              selectedService={selectedService}
              selectedDate={selectedDate}
              selectedTime={selectedTime}
              onSelectDate={setSelectedDate}
              onSelectTime={setSelectedTime}
              onContinue={() => setStep(3)}
              onBack={() => setStep(1)}
            />
          </motion.div>
        )}
        {step === 3 && (
          <motion.div
            key="step3"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Step3Details
              selectedService={selectedService}
              selectedDate={selectedDate}
              selectedTime={selectedTime}
              formData={formData}
              onUpdate={updateForm}
              onContinue={() => setStep(4)}
              onBack={() => setStep(2)}
            />
          </motion.div>
        )}
        {step === 4 && (
          <motion.div
            key="step4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Step4Confirmation
              driver={driver}
              selectedService={selectedService}
              selectedDate={selectedDate}
              selectedTime={selectedTime}
              formData={formData}
              onReset={handleReset}
            // eslint-disable-next-line @typescript-eslint/no-empty-function
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
