import HeroSection from './sections/HeroSection'
import StatsBarSection from './sections/StatsBarSection'
import HowItWorksSection from './sections/HowItWorksSection'
import FeaturesSection from './sections/FeaturesSection'
import MarketSection from './sections/MarketSection'
import PricingSection from './sections/PricingSection'
import TestimonialsSection from './sections/TestimonialsSection'
import DriverShowcaseSection from './sections/DriverShowcaseSection'
import CTASection from './sections/CTASection'

export default function Landing() {
  return (
    <>
      <HeroSection />
      <StatsBarSection />
      <HowItWorksSection />
      <FeaturesSection />
      <MarketSection />
      <PricingSection />
      <TestimonialsSection />
      <DriverShowcaseSection />
      <CTASection />
    </>
  )
}
