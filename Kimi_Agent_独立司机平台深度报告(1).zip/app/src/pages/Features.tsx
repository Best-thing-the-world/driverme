import { useState, useEffect, useRef } from 'react'
import { motion, useInView, AnimatePresence } from 'framer-motion'
import { Link } from 'react-router-dom'
import {
  Store, CalendarCheck, Users, Wallet, Car, BarChart3, Shield,
  Check, Bell, TrendingUp, Plane, Clock, MapPin, Briefcase, Crown, Heart,
} from 'lucide-react'

/* ─────────────────────── animation helpers ─────────────────────── */

const easeSmooth = [0.4, 0, 0.2, 1] as [number, number, number, number]
const easeEnter = [0, 0, 0.2, 1] as [number, number, number, number]

function FadeIn({
  children,
  delay = 0,
  direction = 'up',
  className = '',
}: {
  children: React.ReactNode
  delay?: number
  direction?: 'up' | 'left' | 'right' | 'none'
  className?: string
}) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-60px' })

  const translate =
    direction === 'up'
      ? { y: 40, x: 0 }
      : direction === 'left'
        ? { y: 0, x: -40 }
        : direction === 'right'
          ? { y: 0, x: 40 }
          : { y: 0, x: 0 }

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, ...translate }}
      animate={isInView ? { opacity: 1, y: 0, x: 0 } : {}}
      transition={{ duration: 0.7, delay, ease: easeEnter }}
      className={className}
    >
      {children}
    </motion.div>
  )
}

function StaggerContainer({
  children,
  className = '',
  stagger = 0.1,
}: {
  children: React.ReactNode
  className?: string
  stagger?: number
}) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-60px' })

  return (
    <motion.div
      ref={ref}
      initial="hidden"
      animate={isInView ? 'visible' : 'hidden'}
      variants={{
        hidden: {},
        visible: { transition: { staggerChildren: stagger } },
      }}
      className={className}
    >
      {children}
    </motion.div>
  )
}

function StaggerItem({
  children,
  className = '',
}: {
  children: React.ReactNode
  className?: string
}) {
  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, y: 30 },
        visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: easeEnter } },
      }}
      className={className}
    >
      {children}
    </motion.div>
  )
}

/* ─────────────────────── tab navigation ─────────────────────── */

const featureTabs = [
  { label: 'Storefront', icon: Store, target: 'section-storefront' },
  { label: 'Booking System', icon: CalendarCheck, target: 'section-booking' },
  { label: 'CRM', icon: Users, target: 'section-crm' },
  { label: 'Earnings', icon: Wallet, target: 'section-earnings' },
  { label: 'Services', icon: Car, target: 'section-services' },
  { label: 'Analytics', icon: BarChart3, target: 'section-analytics' },
  { label: 'Admin Tools', icon: Shield, target: 'section-admin' },
]

function FeatureNavTabs() {
  const [activeTab, setActiveTab] = useState('')

  useEffect(() => {
    const handleScroll = () => {
      const sections = featureTabs.map((t) => ({
        id: t.target,
        top: document.getElementById(t.target)?.getBoundingClientRect().top ?? Infinity,
      }))
      const current = sections.filter((s) => s.top <= 100)
      if (current.length > 0) {
        const nearest = current.reduce((a, b) => (a.top > b.top ? a : b))
        setActiveTab(nearest.id)
      } else {
        setActiveTab('')
      }
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const scrollTo = (id: string) => {
    const el = document.getElementById(id)
    if (el) {
      const top = el.getBoundingClientRect().top + window.scrollY - 120
      window.scrollTo({ top, behavior: 'smooth' })
    }
  }

  return (
    <div className="sticky top-[72px] z-40 bg-[rgba(10,10,15,0.95)] backdrop-blur-[16px] border-b border-[#2A2A35]">
      <div className="max-w-[1280px] mx-auto px-6">
        <div className="flex gap-1 overflow-x-auto scrollbar-hide py-1">
          {featureTabs.map((tab) => {
            const Icon = tab.icon
            const isActive = activeTab === tab.target
            return (
              <button
                key={tab.target}
                onClick={() => scrollTo(tab.target)}
                className={`flex items-center gap-2 px-5 py-3 text-xs font-medium whitespace-nowrap rounded-t-lg transition-all duration-300 border-b-2 ${
                  isActive
                    ? 'text-[#D4A853] border-[#D4A853]'
                    : 'text-[#5A5A66] border-transparent hover:text-[#F0EDE8]'
                }`}
              >
                <Icon size={16} />
                {tab.label}
              </button>
            )
          })}
        </div>
      </div>
    </div>
  )
}

/* ─────────────────────── feature sections data ─────────────────────── */

const featureSections = [
  {
    id: 'section-storefront',
    icon: Store,
    title: 'Your Own Branded Booking Page',
    description:
      'Every driver gets a beautiful, mobile-optimized storefront with their photo, bio, vehicle details, services, reviews, and real-time booking. It looks like you hired a designer \u2014 because you did, in a way.',
    bullets: [
      'Custom photo, bio, and vehicle showcase',
      'Real-time availability calendar',
      'Client reviews and ratings displayed',
      'Shareable unique URL',
      'Mobile-optimized for on-the-go bookings',
    ],
    image: '/feature-storefront.jpg',
    imageAlt: 'Driver storefront mockup',
    reversed: false,
  },
  {
    id: 'section-booking',
    icon: CalendarCheck,
    title: 'A Booking Experience Your Clients Will Love',
    description:
      'Your clients book in under 60 seconds. Service selection, date/time picking, and dynamic fields that adapt to each service type. Professional, smooth, and completely white-labeled.',
    bullets: [
      'Multi-step booking with progress indicator',
      'Service-specific dynamic fields (flight #, luggage, passengers)',
      'Real-time availability \u2014 no double bookings',
      'Automatic email confirmations to you and client',
      'Reschedule and cancellation handling',
    ],
    image: '/feature-booking.jpg',
    imageAlt: 'Booking flow mockup',
    reversed: true,
  },
  {
    id: 'section-crm',
    icon: Users,
    title: 'Know Every Client. Remember Every Detail.',
    description:
      'Your client relationships are your most valuable asset. Our CRM helps you track preferences, add notes, view complete booking histories, and build lasting connections that turn one-time riders into regulars.',
    bullets: [
      'Complete client profiles with contact info',
      'Private notes and tags for each client',
      'Full booking history per client',
      'Client type tagging (corporate, personal, recurring)',
      'Search and filter your client base',
    ],
    image: '/feature-crm.jpg',
    imageAlt: 'CRM interface mockup',
    reversed: false,
  },
  {
    id: 'section-earnings',
    icon: Wallet,
    title: 'See Exactly What You\'ve Earned',
    description:
      'No more spreadsheets or guessing. Your earnings dashboard shows real-time revenue, payout status, and growth trends. Know your numbers like a CEO.',
    bullets: [
      'Real-time revenue tracking',
      'Monthly and year-to-date summaries',
      'Payout status and history',
      'Revenue trend charts and analytics',
      'CSV export for your accountant',
    ],
    image: '/feature-earnings.jpg',
    imageAlt: 'Earnings dashboard mockup',
    reversed: true,
  },
  {
    id: 'section-services',
    icon: Car,
    title: 'Unlimited Services. Fully Customizable.',
    description:
      'Create any service your clients need \u2014 airport transfers, hourly charters, corporate events, senior transport, VIP service, errands. Each with its own pricing, duration, and custom booking fields.',
    bullets: [
      'Pre-built templates: Airport, Hourly, Point-to-Point, VIP',
      'Custom pricing per service (per ride, per hour, per mile)',
      'Dynamic booking fields per service type',
      'Service activation/deactivation toggle',
      'Service description and FAQ for clients',
    ],
    image: null,
    imageAlt: '',
    reversed: false,
    useServiceCards: true,
  },
  {
    id: 'section-analytics',
    icon: BarChart3,
    title: 'Data-Driven Decisions',
    description:
      'Understand your business at a glance. Which services are most popular? What days are busiest? Are you growing month over month? Analytics turn intuition into insight.',
    bullets: [
      'Bookings by service type breakdown',
      'Revenue trends and growth metrics',
      'Peak hours and days analysis',
      'Client retention tracking',
      'Exportable reports',
    ],
    image: null,
    imageAlt: '',
    reversed: true,
    useChartMockup: true,
  },
  {
    id: 'section-admin',
    icon: Shield,
    title: 'Built for Scale',
    description:
      'DriverLink isn\'t just for individual drivers. Platform admins have powerful tools to manage driver onboarding, monitor platform health, and ensure quality across the network.',
    bullets: [
      'Driver application review and approval workflow',
      'Platform-wide analytics and KPIs',
      'Booking volume and revenue monitoring',
      'Driver performance metrics',
      'Quality assurance tools',
    ],
    image: null,
    imageAlt: '',
    reversed: false,
    useAdminMockup: true,
  },
]

const serviceCards = [
  { icon: Plane, name: 'Airport Transfer', price: '$85 base', active: true },
  { icon: Clock, name: 'Hourly Charter', price: '$95/hr', active: true },
  { icon: Heart, name: 'Senior Transport', price: '$55/hr', active: true },
]

/* ─────────────────────── feature section component ─────────────────────── */

function FeatureSection({
  section,
}: {
  section: (typeof featureSections)[number]
}) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-80px' })
  const Icon = section.icon

  const textContent = (
    <div className="flex flex-col gap-6">
      <div className="w-14 h-14 rounded-full bg-[rgba(212,168,83,0.1)] flex items-center justify-center">
        <Icon size={32} className="text-[#D4A853]" />
      </div>
      <h2 className="font-body text-[28px] md:text-[32px] font-semibold text-[#F0EDE8] leading-tight tracking-tight">
        {section.title}
      </h2>
      <p className="text-[#8A8A96] text-base leading-relaxed">
        {section.description}
      </p>
      <ul className="flex flex-col gap-3">
        {section.bullets.map((b) => (
          <li key={b} className="flex items-start gap-3 text-[#F0EDE8] text-sm">
            <Check size={18} className="text-[#D4A853] mt-0.5 shrink-0" />
            <span>{b}</span>
          </li>
        ))}
      </ul>
    </div>
  )

  const visualContent = section.image ? (
    <motion.div
      initial={{ opacity: 0, x: section.reversed ? -40 : 40 }}
      animate={isInView ? { opacity: 1, x: 0 } : {}}
      transition={{ duration: 0.7, delay: 0.2, ease: easeEnter }}
      className="relative"
    >
      <div className="border-2 border-[#2A2A35] rounded-2xl p-2 bg-[#141419]">
        <img
          src={section.image}
          alt={section.imageAlt}
          className="w-full rounded-xl"
        />
      </div>
    </motion.div>
  ) : section.useServiceCards ? (
    <motion.div
      initial={{ opacity: 0, x: section.reversed ? -40 : 40 }}
      animate={isInView ? { opacity: 1, x: 0 } : {}}
      transition={{ duration: 0.7, delay: 0.2, ease: easeEnter }}
      className="flex flex-col gap-3"
    >
      {serviceCards.map((card, i) => {
        const CardIcon = card.icon
        return (
          <motion.div
            key={card.name}
            initial={{ opacity: 0, y: 30, rotateZ: (i - 1) * 1.5 }}
            animate={isInView ? { opacity: 1, y: 0, rotateZ: (i - 1) * 1.5 } : {}}
            transition={{ duration: 0.6, delay: 0.15 * i, ease: easeEnter }}
            className="bg-[#1E1E26] border border-[#2A2A35] rounded-xl p-4 flex items-center gap-4 hover:border-[rgba(212,168,83,0.3)] transition-all duration-300"
          >
            <div className="w-10 h-10 rounded-lg bg-[rgba(212,168,83,0.1)] flex items-center justify-center shrink-0">
              <CardIcon size={20} className="text-[#D4A853]" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[#F0EDE8] font-semibold text-sm">{card.name}</p>
              <p className="text-[#5A5A66] text-xs">{card.price}</p>
            </div>
            <div className="w-10 h-5 rounded-full bg-[#22C55E] relative">
              <div className="absolute right-0.5 top-0.5 w-4 h-4 rounded-full bg-white shadow" />
            </div>
          </motion.div>
        )
      })}
    </motion.div>
  ) : section.useChartMockup ? (
    <motion.div
      initial={{ opacity: 0, x: section.reversed ? -40 : 40 }}
      animate={isInView ? { opacity: 1, x: 0 } : {}}
      transition={{ duration: 0.7, delay: 0.2, ease: easeEnter }}
      className="bg-[#141419] border border-[#2A2A35] rounded-2xl p-6 flex flex-col gap-6"
    >
      {/* Donut chart mock */}
      <div className="flex items-center gap-4">
        <svg width="80" height="80" viewBox="0 0 80 80">
          <circle cx="40" cy="40" r="32" fill="none" stroke="#1E1E26" strokeWidth="12" />
          <motion.circle
            cx="40" cy="40" r="32" fill="none" stroke="#D4A853" strokeWidth="12"
            strokeDasharray={`${0.4 * 201} ${201}`}
            strokeLinecap="round"
            transform="rotate(-90 40 40)"
            initial={{ strokeDasharray: `0 ${201}` }}
            animate={isInView ? { strokeDasharray: `${0.4 * 201} ${201}` } : {}}
            transition={{ duration: 1.2, delay: 0.3, ease: easeSmooth }}
          />
          <motion.circle
            cx="40" cy="40" r="32" fill="none" stroke="#B08D3E" strokeWidth="12"
            strokeDasharray={`${0.3 * 201} ${201}`}
            strokeLinecap="round"
            strokeDashoffset={-0.4 * 201}
            transform="rotate(-90 40 40)"
            initial={{ strokeDasharray: `0 ${201}` }}
            animate={isInView ? { strokeDasharray: `${0.3 * 201} ${201}` } : {}}
            transition={{ duration: 1.2, delay: 0.5, ease: easeSmooth }}
          />
          <motion.circle
            cx="40" cy="40" r="32" fill="none" stroke="#E8C87A" strokeWidth="12"
            strokeDasharray={`${0.2 * 201} ${201}`}
            strokeLinecap="round"
            strokeDashoffset={-(0.4 + 0.3) * 201}
            transform="rotate(-90 40 40)"
            initial={{ strokeDasharray: `0 ${201}` }}
            animate={isInView ? { strokeDasharray: `${0.2 * 201} ${201}` } : {}}
            transition={{ duration: 1.2, delay: 0.7, ease: easeSmooth }}
          />
        </svg>
        <div className="flex flex-col gap-1 text-xs">
          <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-[#D4A853]" />Airport 40%</div>
          <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-[#B08D3E]" />Hourly 30%</div>
          <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-[#E8C87A]" />Point-to-Point 20%</div>
          <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-[#2A2A35]" />Other 10%</div>
        </div>
      </div>
      {/* Bar chart mock */}
      <div>
        <p className="text-xs text-[#5A5A66] mb-3">Bookings by day of week</p>
        <div className="flex items-end gap-2 h-24">
          {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((day, i) => (
            <div key={day + i} className="flex-1 flex flex-col items-center gap-1">
              <motion.div
                className="w-full bg-[#D4A853] rounded-t"
                style={{ height: `${[50, 70, 45, 80, 65, 90, 40][i]}%` }}
                initial={{ height: 0 }}
                animate={isInView ? { height: `${[50, 70, 45, 80, 65, 90, 40][i]}%` } : {}}
                transition={{ duration: 0.8, delay: 0.3 + i * 0.08, ease: easeSmooth }}
              />
              <span className="text-[10px] text-[#5A5A66]">{day}</span>
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  ) : section.useAdminMockup ? (
    <motion.div
      initial={{ opacity: 0, x: section.reversed ? -40 : 40 }}
      animate={isInView ? { opacity: 1, x: 0 } : {}}
      transition={{ duration: 0.7, delay: 0.2, ease: easeEnter }}
      className="bg-[#141419] border border-[#2A2A35] rounded-2xl p-6 flex flex-col gap-4"
    >
      <div className="grid grid-cols-2 gap-3">
        {[
          { label: 'Total Drivers', value: '45' },
          { label: 'Pending', value: '8' },
          { label: 'Monthly Bookings', value: '1,247' },
          { label: 'Revenue', value: '$186K' },
        ].map((kpi, i) => (
          <motion.div
            key={kpi.label}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 0.5, delay: 0.3 + i * 0.1, ease: easeEnter }}
            className="bg-[#1E1E26] rounded-lg p-3"
          >
            <p className="text-[10px] text-[#5A5A66] uppercase tracking-wider">{kpi.label}</p>
            <p className="text-lg font-mono font-bold text-[#D4A853] mt-1">{kpi.value}</p>
          </motion.div>
        ))}
      </div>
      {/* Approval table mock */}
      <div className="border border-[#2A2A35] rounded-lg overflow-hidden">
        <div className="bg-[#1E1E26] px-3 py-2 text-[10px] text-[#5A5A66] uppercase tracking-wider">
          Pending Approvals
        </div>
        {['Marcus J.', 'Sarah M.', 'Elena R.'].map((name, i) => (
          <motion.div
            key={name}
            initial={{ opacity: 0, x: -20 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.4, delay: 0.6 + i * 0.1, ease: easeEnter }}
            className="flex items-center justify-between px-3 py-2 border-t border-[#2A2A35]"
          >
            <span className="text-sm text-[#F0EDE8]">{name}</span>
            <div className="flex gap-2">
              <span className="px-2 py-1 rounded-full text-[10px] bg-[rgba(34,197,94,0.1)] text-[#22C55E]">Approve</span>
              <span className="px-2 py-1 rounded-full text-[10px] bg-[rgba(239,68,68,0.1)] text-[#EF4444]">Reject</span>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  ) : null

  return (
    <section
      id={section.id}
      ref={ref}
      className={`py-24 ${section.id === 'section-analytics' ? 'bg-[#0D0D12]' : ''}`}
    >
      <div className="max-w-[1280px] mx-auto px-6">
        <div
          className={`grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center ${
            section.reversed ? 'lg:[direction:rtl]' : ''
          }`}
        >
          <motion.div
            initial={{ opacity: 0, x: section.reversed ? 40 : -40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, ease: easeEnter }}
            className={section.reversed ? 'lg:[direction:ltr]' : ''}
          >
            {textContent}
          </motion.div>
          <div className={section.reversed ? 'lg:[direction:ltr]' : ''}>
            {visualContent}
          </div>
        </div>
      </div>
    </section>
  )
}

/* ─────────────────────── main page ─────────────────────── */

export default function Features() {
  return (
    <div className="bg-[#0A0A0F] min-h-screen">
      {/* ── Section 1: Hero ── */}
      <section className="pt-32 pb-24">
        <div className="max-w-[1280px] mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* Left — text */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: easeEnter }}
            >
              <span className="text-[#D4A853] text-xs font-medium tracking-[0.15em] uppercase">
                FEATURES
              </span>
              <h1 className="font-display text-[36px] md:text-[48px] lg:text-[56px] font-bold text-[#F0EDE8] leading-[1.05] tracking-tight mt-4">
                Everything You Need to Run Your Chauffeur Business
              </h1>
              <p className="text-[#8A8A96] text-lg leading-relaxed mt-6 max-w-lg">
                From your first client to your hundredth, DriverLink grows with you. One platform. Zero complexity.
              </p>
              <Link
                to="/register"
                className="inline-block mt-8 px-6 py-3 rounded-full text-sm font-semibold text-[#0A0A0F] bg-[linear-gradient(135deg,#D4A853_0%,#E8C87A_50%,#D4A853_100%)] hover:scale-[1.02] hover:shadow-[0_4px_24px_rgba(212,168,83,0.3)] transition-all duration-200"
              >
                Get Started
              </Link>
            </motion.div>

            {/* Right — image with floating cards */}
            <motion.div
              initial={{ opacity: 0, x: 40 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2, ease: easeEnter }}
              className="relative"
            >
              <div className="border border-[rgba(212,168,83,0.2)] rounded-2xl overflow-hidden">
                <img
                  src="/feature-storefront.jpg"
                  alt="Feature preview"
                  className="w-full"
                />
              </div>

              {/* Floating card 1 */}
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.5, ease: easeEnter }}
                className="absolute -top-4 -right-4 bg-[#141419] border border-[#2A2A35] rounded-xl px-4 py-3 shadow-elevated animate-float"
              >
                <div className="flex items-center gap-2">
                  <Bell size={16} className="text-[#D4A853]" />
                  <span className="text-sm font-semibold text-[#F0EDE8]">New Booking!</span>
                </div>
              </motion.div>

              {/* Floating card 2 */}
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.7, ease: easeEnter }}
                className="absolute -bottom-4 -left-4 bg-[#141419] border border-[#2A2A35] rounded-xl px-4 py-3 shadow-elevated animate-float"
                style={{ animationDelay: '1s' }}
              >
                <div className="flex items-center gap-2">
                  <TrendingUp size={16} className="text-[#22C55E]" />
                  <span className="text-sm font-semibold text-[#F0EDE8]">$1,240 this month</span>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── Section 2: Feature Nav Tabs ── */}
      <FeatureNavTabs />

      {/* ── Sections 3–9: Feature Deep Dives ── */}
      {featureSections.map((section) => (
        <FeatureSection key={section.id} section={section} />
      ))}

      {/* ── Section 10: Final CTA ── */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-[600px] h-[600px] rounded-full bg-[#D4A853] opacity-[0.06] blur-[120px]" />
        </div>
        <div className="max-w-[800px] mx-auto px-6 text-center relative z-10">
          <FadeIn>
            <h2 className="font-display text-[32px] md:text-[48px] lg:text-[56px] font-bold text-[#F0EDE8] leading-[1.05] tracking-tight">
              Ready to Transform Your Business?
            </h2>
          </FadeIn>
          <FadeIn delay={0.15}>
            <p className="text-[#8A8A96] text-lg leading-relaxed mt-6 max-w-lg mx-auto">
              Join independent drivers who are building their own business, not someone else&apos;s.
            </p>
          </FadeIn>
          <FadeIn delay={0.3}>
            <div className="mt-10">
              <Link
                to="/register"
                className="inline-block px-8 py-4 rounded-full text-sm font-semibold text-[#0A0A0F] bg-[linear-gradient(135deg,#D4A853_0%,#E8C87A_50%,#D4A853_100%)] hover:scale-[1.02] hover:shadow-[0_4px_24px_rgba(212,168,83,0.3)] transition-all duration-200"
              >
                Get Started for Free
              </Link>
              <p className="text-[#5A5A66] text-xs mt-4">
                No credit card required. 14-day free trial.
              </p>
            </div>
          </FadeIn>
        </div>
      </section>
    </div>
  )
}
