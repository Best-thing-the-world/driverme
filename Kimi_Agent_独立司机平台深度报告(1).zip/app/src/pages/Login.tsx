import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Link } from 'react-router-dom'
import {
  Mail, Lock, Eye, EyeOff, Key, ChevronLeft,
} from 'lucide-react'

/* ─────────────────────── animation helpers ─────────────────────── */

const easeSmooth = [0.4, 0, 0.2, 1] as [number, number, number, number]
const _easeEnter = [0, 0, 0.2, 1] as [number, number, number, number]

function FormTransition({ children, keyProp }: { children: React.ReactNode; keyProp: string }) {
  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={keyProp}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -10 }}
        transition={{ duration: 0.3, ease: easeSmooth }}
      >
        {children}
      </motion.div>
    </AnimatePresence>
  )
}

/* ─────────────────────── components ─────────────────────── */

function PasswordInput({
  value,
  onChange,
  placeholder,
  icon,
}: {
  value: string
  onChange: (v: string) => void
  placeholder: string
  icon: React.ReactNode
}) {
  const [show, setShow] = useState(false)

  return (
    <div className="relative">
      <div className="absolute left-3 top-1/2 -translate-y-1/2 text-[#5A5A66]">
        {icon}
      </div>
      <input
        type={show ? 'text' : 'password'}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full bg-[#1E1E26] border border-[#2A2A35] rounded-lg py-3 pl-10 pr-10 text-sm text-[#F0EDE8] placeholder:text-[#5A5A66] focus:outline-none focus:border-[#D4A853] focus:ring-[3px] focus:ring-[rgba(212,168,83,0.15)] transition-all duration-200"
      />
      <button
        type="button"
        onClick={() => setShow(!show)}
        className="absolute right-3 top-1/2 -translate-y-1/2 text-[#5A5A66] hover:text-[#8A8A96] transition-colors"
      >
        {show ? <EyeOff size={18} /> : <Eye size={18} />}
      </button>
    </div>
  )
}

/* ─────────────────────── login form ─────────────────────── */

type LoginView = 'login' | 'forgot' | 'reset-sent'

export default function Login() {
  const [view, setView] = useState<LoginView>('login')
  const [loginType, setLoginType] = useState<'driver' | 'admin'>('driver')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [adminKey, setAdminKey] = useState('')
  const [rememberMe, setRememberMe] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  const [shake, setShake] = useState(false)

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')

    if (!email || !password) {
      setError('Please fill in all fields.')
      setShake(true)
      setTimeout(() => setShake(false), 400)
      return
    }
    if (loginType === 'admin' && !adminKey) {
      setError('Admin access key is required.')
      setShake(true)
      setTimeout(() => setShake(false), 400)
      return
    }

    setIsLoading(true)
    // Simulate API call
    await new Promise((r) => setTimeout(r, 1500))
    setIsLoading(false)
    // Mock success — in real app, redirect to dashboard
  }

  const handleForgot = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email) {
      setError('Please enter your email address.')
      return
    }
    setIsLoading(true)
    await new Promise((r) => setTimeout(r, 1000))
    setIsLoading(false)
    setView('reset-sent')
  }

  return (
    <div className="min-h-[100dvh] bg-[#0A0A0F] flex">
      {/* ── Left decorative panel (desktop) ── */}
      <div className="hidden lg:flex lg:w-1/2 relative flex-col items-center justify-center">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: 'url(/hero-bg.jpg)' }}
        />
        <div className="absolute inset-0 bg-gradient-to-br from-[rgba(10,10,15,0.7)] to-[rgba(10,10,15,0.95)]" />
        <div className="relative z-10 flex flex-col items-center text-center px-12">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[linear-gradient(135deg,#D4A853_0%,#E8C87A_50%,#D4A853_100%)] flex items-center justify-center">
              <span className="font-display font-bold text-[#0A0A0F] text-lg leading-none">DL</span>
            </div>
            <span className="font-display text-2xl font-semibold text-[#F0EDE8]">
              DriverLink
            </span>
          </div>
          <p className="text-[#8A8A96] text-lg mt-4 max-w-sm">
            The platform for independent chauffeurs.
          </p>
          <blockquote className="mt-12 max-w-[360px]">
            <p className="text-[#8A8A96] text-sm italic leading-relaxed">
              &ldquo;DriverLink transformed my business. I went from chasing clients to having them book me directly.&rdquo;
            </p>
            <cite className="text-[#D4A853] text-xs not-italic mt-3 block">
              — Marcus J., Atlanta
            </cite>
          </blockquote>
        </div>
      </div>

      {/* ── Right side: login form ── */}
      <div className="flex-1 flex items-center justify-center px-6 py-12">
        <motion.div
          animate={shake ? { x: [-5, 5, -5, 5, 0] } : {}}
          transition={{ duration: 0.4 }}
          className="w-full max-w-[420px] bg-[#141419] border border-[#2A2A35] rounded-2xl p-10 md:p-12 shadow-[0_20px_60px_rgba(0,0,0,0.3)]"
        >
          <AnimatePresence mode="wait">
            {view === 'login' && (
              <motion.div
                key="login"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3, ease: easeSmooth }}
              >
                {/* Header */}
                <div className="text-center">
                  <div className="w-12 h-12 rounded-full bg-[linear-gradient(135deg,#D4A853_0%,#E8C87A_50%,#D4A853_100%)] flex items-center justify-center mx-auto">
                    <span className="font-display font-bold text-[#0A0A0F] text-lg leading-none">DL</span>
                  </div>
                  <h1 className="text-2xl font-bold text-[#F0EDE8] mt-4">Welcome Back</h1>
                  <p className="text-sm text-[#8A8A96] mt-2">
                    Sign in to your DriverLink account
                  </p>
                </div>

                {/* Tab toggle */}
                <div className="mt-6 bg-[#1E1E26] border border-[#2A2A35] rounded-full p-1 flex">
                  <button
                    onClick={() => { setLoginType('driver'); setError('') }}
                    className={`flex-1 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                      loginType === 'driver'
                        ? 'bg-[#141419] text-[#D4A853] font-semibold shadow'
                        : 'text-[#5A5A66] hover:text-[#8A8A96]'
                    }`}
                  >
                    Driver
                  </button>
                  <button
                    onClick={() => { setLoginType('admin'); setError('') }}
                    className={`flex-1 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                      loginType === 'admin'
                        ? 'bg-[#141419] text-[#D4A853] font-semibold shadow'
                        : 'text-[#5A5A66] hover:text-[#8A8A96]'
                    }`}
                  >
                    Admin
                  </button>
                </div>

                {/* Error */}
                {error && (
                  <motion.p
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-sm text-[#EF4444] mt-4 text-center"
                  >
                    {error}
                  </motion.p>
                )}

                {/* Form */}
                <form onSubmit={handleLogin} className="mt-6 flex flex-col gap-4">
                  {/* Email */}
                  <div className="relative">
                    <div className="absolute left-3 top-1/2 -translate-y-1/2 text-[#5A5A66]">
                      <Mail size={18} />
                    </div>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="you@example.com"
                      className="w-full bg-[#1E1E26] border border-[#2A2A35] rounded-lg py-3 pl-10 pr-4 text-sm text-[#F0EDE8] placeholder:text-[#5A5A66] focus:outline-none focus:border-[#D4A853] focus:ring-[3px] focus:ring-[rgba(212,168,83,0.15)] transition-all duration-200"
                    />
                  </div>

                  {/* Password */}
                  <PasswordInput
                    value={password}
                    onChange={setPassword}
                    placeholder="••••••••"
                    icon={<Lock size={18} />}
                  />

                  {/* Admin key (conditional) */}
                  <AnimatePresence>
                    {loginType === 'admin' && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.3, ease: easeSmooth }}
                        className="overflow-hidden"
                      >
                        <div className="pt-2 flex flex-col gap-1">
                          <div className="relative">
                            <div className="absolute left-3 top-1/2 -translate-y-1/2 text-[#5A5A66]">
                              <Key size={18} />
                            </div>
                            <input
                              type="password"
                              value={adminKey}
                              onChange={(e) => setAdminKey(e.target.value)}
                              placeholder="Enter your admin key"
                              className="w-full bg-[#1E1E26] border border-[#2A2A35] rounded-lg py-3 pl-10 pr-4 text-sm text-[#F0EDE8] placeholder:text-[#5A5A66] focus:outline-none focus:border-[#D4A853] focus:ring-[3px] focus:ring-[rgba(212,168,83,0.15)] transition-all duration-200"
                            />
                          </div>
                          <p className="text-xs text-[#5A5A66]">
                            Contact your platform administrator for the admin key.
                          </p>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Remember me + forgot */}
                  <div className="flex items-center justify-between">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={rememberMe}
                        onChange={(e) => setRememberMe(e.target.checked)}
                        className="w-4 h-4 rounded border-[#2A2A35] bg-[#1E1E26] accent-[#D4A853] cursor-pointer"
                      />
                      <span className="text-sm text-[#8A8A96]">Remember me for 30 days</span>
                    </label>
                    <button
                      type="button"
                      onClick={() => { setView('forgot'); setError('') }}
                      className="text-sm text-[#D4A853] hover:underline"
                    >
                      Forgot password?
                    </button>
                  </div>

                  {/* Submit */}
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-3 rounded-full text-sm font-semibold text-[#0A0A0F] bg-[linear-gradient(135deg,#D4A853_0%,#E8C87A_50%,#D4A853_100%)] hover:scale-[1.02] hover:shadow-[0_4px_24px_rgba(212,168,83,0.3)] transition-all duration-200 disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2 h-12"
                  >
                    {isLoading ? (
                      <>
                        <LoadingSpinner />
                        Signing in...
                      </>
                    ) : (
                      'Sign In'
                    )}
                  </button>
                </form>

                {/* Divider */}
                <div className="flex items-center gap-4 my-8">
                  <div className="flex-1 h-px bg-[#2A2A35]" />
                  <span className="text-xs text-[#5A5A66]">or</span>
                  <div className="flex-1 h-px bg-[#2A2A35]" />
                </div>

                {/* Social login */}
                <div className="flex flex-col gap-3">
                  <button className="w-full py-2.5 rounded-full text-sm font-medium text-[#F0EDE8] border border-[#2A2A35] hover:bg-[#1E1E26] transition-all duration-200 flex items-center justify-center gap-2 h-11">
                    <GoogleIcon />
                    Sign in with Google
                  </button>
                  <button className="w-full py-2.5 rounded-full text-sm font-medium text-[#F0EDE8] border border-[#2A2A35] hover:bg-[#1E1E26] transition-all duration-200 flex items-center justify-center gap-2 h-11">
                    <AppleIcon />
                    Sign in with Apple
                  </button>
                </div>

                {/* Footer */}
                <p className="text-center text-sm text-[#8A8A96] mt-8">
                  Don&apos;t have an account?{' '}
                  <Link to="/register" className="text-[#D4A853] hover:underline font-medium">
                    Get Started
                  </Link>
                </p>
              </motion.div>
            )}

            {view === 'forgot' && (
              <motion.div
                key="forgot"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3, ease: easeSmooth }}
              >
                <button
                  onClick={() => { setView('login'); setError('') }}
                  className="flex items-center gap-1 text-sm text-[#D4A853] hover:underline mb-4"
                >
                  <ChevronLeft size={16} />
                  Back to login
                </button>

                <h2 className="text-2xl font-bold text-[#F0EDE8]">Reset Password</h2>
                <p className="text-sm text-[#8A8A96] mt-2">
                  Enter your email and we&apos;ll send you a reset link.
                </p>

                {error && (
                  <motion.p
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="text-sm text-[#EF4444] mt-4"
                  >
                    {error}
                  </motion.p>
                )}

                <form onSubmit={handleForgot} className="mt-6 flex flex-col gap-4">
                  <div className="relative">
                    <div className="absolute left-3 top-1/2 -translate-y-1/2 text-[#5A5A66]">
                      <Mail size={18} />
                    </div>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="you@example.com"
                      className="w-full bg-[#1E1E26] border border-[#2A2A35] rounded-lg py-3 pl-10 pr-4 text-sm text-[#F0EDE8] placeholder:text-[#5A5A66] focus:outline-none focus:border-[#D4A853] focus:ring-[3px] focus:ring-[rgba(212,168,83,0.15)] transition-all duration-200"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-3 rounded-full text-sm font-semibold text-[#0A0A0F] bg-[linear-gradient(135deg,#D4A853_0%,#E8C87A_50%,#D4A853_100%)] hover:scale-[1.02] transition-all duration-200 disabled:opacity-60 flex items-center justify-center gap-2 h-12"
                  >
                    {isLoading ? (
                      <>
                        <LoadingSpinner />
                        Sending...
                      </>
                    ) : (
                      'Send Reset Link'
                    )}
                  </button>
                </form>

                <p className="text-xs text-[#5A5A66] mt-4 text-center">
                  Check your spam folder if you don&apos;t see the email.
                </p>
              </motion.div>
            )}

            {view === 'reset-sent' && (
              <motion.div
                key="reset-sent"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3, ease: easeSmooth }}
                className="text-center py-8"
              >
                <div className="w-14 h-14 rounded-full bg-[rgba(212,168,83,0.1)] flex items-center justify-center mx-auto">
                  <Mail size={28} className="text-[#D4A853]" />
                </div>
                <h3 className="text-xl font-bold text-[#F0EDE8] mt-4">
                  Check Your Email
                </h3>
                <p className="text-sm text-[#8A8A96] mt-2">
                  We&apos;ve sent a password reset link to your email address.
                </p>
                <button
                  onClick={() => setView('login')}
                  className="mt-6 px-6 py-2.5 rounded-full text-sm font-semibold text-[#D4A853] border border-[#D4A853] hover:bg-[rgba(212,168,83,0.1)] transition-all duration-200"
                >
                  Back to Login
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </div>
  )
}

/* ─────────────────────── icons ─────────────────────── */

function LoadingSpinner() {
  return (
    <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
    </svg>
  )
}

function GoogleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18">
      <path d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844c-.209 1.125-.843 2.078-1.796 2.717v2.258h2.908c1.702-1.567 2.684-3.874 2.684-6.615z" fill="#4285F4" />
      <path d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.836.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332C2.438 15.983 5.482 18 9 18z" fill="#34A853" />
      <path d="M3.964 10.71c-.18-.54-.282-1.117-.282-1.71s.102-1.17.282-1.71V4.958H.957C.347 6.173 0 7.548 0 9s.348 2.827.957 4.042l3.007-2.332z" fill="#FBBC05" />
      <path d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0 5.482 0 2.438 2.017.957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58z" fill="#EA4335" />
    </svg>
  )
}

function AppleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="#F0EDE8">
      <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z" />
    </svg>
  )
}
