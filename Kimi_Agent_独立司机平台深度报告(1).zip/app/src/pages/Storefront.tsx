import { useMemo } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import {
  MapPin,
  Star,
  Clock,
  Calendar,
  Car,
  ShieldCheck,
  CheckCircle,
  Users,
  Luggage,
  Shield,
  Plane,
  Crown,
  Briefcase,
  ChevronLeft,
  Quote,
  Heart,
  ShoppingBag,
} from 'lucide-react'
import { getDriverById, drivers, vehicleFeatures } from '@/lib/data'
import type { Driver, Service, Review } from '@/types'

const easeEnter = [0, 0, 0.2, 1] as [number, number, number, number]

const iconMap: Record<string, React.ElementType> = {
  Plane, Clock, MapPin, Briefcase, Crown, Heart, ShoppingBag,
}

/* ------------------------------------------------------------------ */
/*  ServiceIcon                                                        */
/* ------------------------------------------------------------------ */
function ServiceIcon({ iconName, size = 36 }: { iconName: string; size?: number }) {
  const Icon = iconMap[iconName] || Car
  return (
    <div className="w-12 h-12 rounded-xl bg-[rgba(212,168,83,0.1)] flex items-center justify-center">
      <Icon size={size * 0.6} className="text-[#D4A853]" />
    </div>
  )
}

/* ------------------------------------------------------------------ */
/*  ServiceCard                                                        */
/* ------------------------------------------------------------------ */
function ServiceCard({
  service,
  driverId,
  index,
}: {
  service: Service
  driverId: string
  index: number
}) {
  const navigate = useNavigate()

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.6, delay: index * 0.1, ease: easeEnter }}
      className="bg-[#141419] border border-[#2A2A35] rounded-2xl p-7 transition-all duration-300 hover:-translate-y-1 hover:border-[rgba(212,168,83,0.3)] hover:shadow-gold-sm"
    >
      <ServiceIcon iconName={service.icon} />
      <h3 className="mt-4 text-xl font-semibold text-[#F0EDE8]">
        {service.name}
      </h3>
      <p className="mt-2 text-sm text-[#8A8A96] leading-relaxed">
        {service.description}
      </p>
      <div className="mt-3 flex items-baseline gap-1">
        <span className="font-mono text-2xl font-bold text-[#D4A853]">
          ${service.basePrice}
        </span>
        <span className="text-xs text-[#5A5A66]">/{service.priceUnit}</span>
      </div>
      {service.duration && (
        <p className="mt-1 text-xs text-[#5A5A66]">{service.duration}</p>
      )}
      <button
        onClick={() => navigate(`/book/${driverId}?service=${service.id}`)}
        className="mt-5 w-full py-3 rounded-full text-sm font-semibold text-[#D4A853] border border-[#D4A853] hover:bg-[rgba(212,168,83,0.1)] transition-all hover:scale-[1.02]"
      >
        Book This Service
      </button>
    </motion.div>
  )
}

/* ------------------------------------------------------------------ */
/*  ReviewCard                                                         */
/* ------------------------------------------------------------------ */
function ReviewCard({ review, index }: { review: Review; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: 40 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.5, delay: index * 0.2, ease: easeEnter }}
      className="relative bg-[#141419] border border-[#2A2A35] rounded-2xl p-7 min-w-[320px] md:min-w-[480px]"
    >
      <Quote
        size={32}
        className="absolute top-6 left-6 text-[#D4A853] opacity-30"
      />
      <div className="flex gap-1 mb-4 pt-8">
        {Array.from({ length: 5 }, (_, i) => (
          <Star
            key={i}
            size={16}
            className={
              i < review.rating
                ? 'text-[#D4A853] fill-[#D4A853]'
                : 'text-[#2A2A35]'
            }
          />
        ))}
      </div>
      <p className="text-[#F0EDE8] leading-relaxed italic">&ldquo;{review.text}&rdquo;</p>
      <div className="flex items-center justify-between mt-6">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-[#1E1E26] flex items-center justify-center text-sm font-semibold text-[#D4A853]">
            {review.author.charAt(0)}
          </div>
          <div>
            <p className="text-sm font-semibold text-[#F0EDE8]">
              {review.author}
            </p>
            <p className="text-xs text-[#5A5A66]">{review.date}</p>
          </div>
        </div>
        <span className="px-3 py-1 rounded-full text-xs font-medium border border-[#D4A853]/30 text-[#D4A853]">
          {review.service}
        </span>
      </div>
    </motion.div>
  )
}

/* ------------------------------------------------------------------ */
/*  MiniDriverCard (for "You Might Also Like")                         */
/* ------------------------------------------------------------------ */
function MiniDriverCard({ driver, index }: { driver: Driver; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1, ease: easeEnter }}
    >
      <Link
        to={`/drivers/${driver.id}`}
        className="group block bg-[#141419] border border-[#2A2A35] rounded-2xl overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:border-[rgba(212,168,83,0.3)] hover:shadow-[0_12px_40px_rgba(0,0,0,0.4)]"
      >
        <div className="relative aspect-video overflow-hidden">
          <img
            src={driver.vehicle.image}
            alt={`${driver.vehicle.make} ${driver.vehicle.model}`}
            className="w-full h-full object-cover transition-transform duration-400 group-hover:scale-105"
          />
        </div>
        <div className="p-4">
          <div className="flex items-center gap-2">
            <img
              src={driver.avatar}
              alt={driver.name}
              className="w-8 h-8 rounded-full object-cover border border-[#D4A853]"
            />
            <h4 className="text-sm font-semibold text-[#F0EDE8]">
              {driver.name}
            </h4>
          </div>
          <div className="flex items-center gap-1 mt-1 text-xs text-[#5A5A66]">
            <MapPin size={12} />
            <span>{driver.location}</span>
          </div>
          <div className="flex items-center justify-between mt-2">
            <div className="flex items-center gap-1">
              <Star size={12} className="text-[#D4A853] fill-[#D4A853]" />
              <span className="text-xs font-medium text-[#F0EDE8]">
                {driver.ratings.average}
              </span>
              <span className="text-xs text-[#5A5A66]">
                ({driver.ratings.count})
              </span>
            </div>
            <span className="font-mono text-sm font-bold text-[#D4A853]">
              ${driver.hourlyRate}/hr
            </span>
          </div>
        </div>
      </Link>
    </motion.div>
  )
}

/* ------------------------------------------------------------------ */
/*  Main Storefront Page                                               */
/* ------------------------------------------------------------------ */
export default function Storefront() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const driver = useMemo(() => getDriverById(id || ''), [id])
  const features = useMemo(
    () => (driver ? vehicleFeatures[driver.id] || [] : []),
    [driver]
  )
  const otherDrivers = useMemo(
    () => drivers.filter((d) => d.id !== id).slice(0, 3),
    [id]
  )

  if (!driver) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center text-center px-6">
        <h1 className="font-display text-4xl text-[#F0EDE8] mb-4">
          Driver Not Found
        </h1>
        <p className="text-[#8A8A96] mb-6">
          The driver you&apos;re looking for doesn&apos;t exist.
        </p>
        <Link
          to="/drivers"
          className="px-6 py-2.5 rounded-full text-sm font-semibold text-[#0A0A0F] bg-gold-shine hover:scale-[1.02] transition-all"
        >
          Browse All Drivers
        </Link>
      </div>
    )
  }

  const vehicleInfo = `${driver.vehicle.make} ${driver.vehicle.model}`

  return (
    <div className="min-h-[100dvh] bg-[#0A0A0F]">
      {/* ========== Section 1: Hero Header ========== */}
      <section className="relative min-h-[400px] flex items-end">
        <img
          src={driver.vehicle.image}
          alt={vehicleInfo}
          className="absolute inset-0 w-full h-full object-cover object-center"
        />
        <div
          className="absolute inset-0"
          style={{
            background:
              'linear-gradient(180deg, rgba(10,10,15,0.5) 0%, rgba(10,10,15,0.95) 100%)',
          }}
        />
        <div className="relative z-10 w-full max-w-[1280px] mx-auto px-6 pb-12">
          <Link
            to="/drivers"
            className="inline-flex items-center gap-2 text-sm text-[#D4A853] hover:text-[#E8C87A] transition-colors mb-6"
          >
            <ChevronLeft size={16} />
            Browse All Drivers
          </Link>

          <div className="flex items-center gap-5">
            <motion.img
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.2, ease: easeEnter }}
              src={driver.avatar}
              alt={driver.name}
              className="w-20 h-20 rounded-full object-cover border-[3px] border-[#D4A853] shadow-[0_4px_20px_rgba(212,168,83,0.2)]"
            />
            <div>
              <div className="flex items-center gap-3">
                <motion.h1
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, ease: easeEnter }}
                  className="text-3xl md:text-4xl font-bold text-[#F0EDE8]"
                >
                  {driver.name}
                </motion.h1>
                <motion.span
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.4, delay: 0.35 }}
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-[rgba(212,168,83,0.15)] text-[#D4A853] border border-[#D4A853]/20"
                >
                  <ShieldCheck size={14} />
                  Verified
                </motion.span>
              </div>
              <motion.p
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.15, ease: easeEnter }}
                className="mt-1 text-lg text-[#8A8A96]"
              >
                {driver.tagline}
              </motion.p>
            </div>
          </div>

          {/* Meta row */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3, ease: easeEnter }}
            className="flex flex-wrap gap-x-6 gap-y-2 mt-4"
          >
            <span className="flex items-center gap-1.5 text-xs text-[#5A5A66]">
              <MapPin size={14} />
              {driver.location}
            </span>
            <span className="flex items-center gap-1.5 text-xs text-[#F0EDE8]">
              <Star size={14} className="text-[#D4A853] fill-[#D4A853]" />
              {driver.ratings.average} ({driver.ratings.count} reviews)
            </span>
            <span className="flex items-center gap-1.5 text-xs text-[#5A5A66]">
              <Clock size={14} />
              {driver.responseTime} response
            </span>
            <span className="flex items-center gap-1.5 text-xs text-[#5A5A66]">
              <Calendar size={14} />
              Member since {driver.memberSince}
            </span>
            <span className="flex items-center gap-1.5 text-xs text-[#5A5A66]">
              <Car size={14} />
              {driver.totalRides} completed rides
            </span>
          </motion.div>

          {/* Quick stats */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4, ease: easeEnter }}
            className="flex flex-wrap gap-3 mt-5"
          >
            <span className="px-4 py-2 rounded-full text-sm font-medium bg-[#1E1E26] border border-[#2A2A35] text-[#F0EDE8]">
              {driver.totalRides} Rides
            </span>
            <span className="px-4 py-2 rounded-full text-sm font-medium border border-[#D4A853] text-[#D4A853]">
              ${driver.hourlyRate}/hr
            </span>
            <span className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-medium bg-[rgba(34,197,94,0.1)] text-[#22C55E]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#22C55E]" />
              Available Today
            </span>
          </motion.div>
        </div>
      </section>

      {/* ========== Section 2: About + Vehicle ========== */}
      <section className="py-16 max-w-[1280px] mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-[55%_45%] gap-12">
          {/* Left — About */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: easeEnter }}
          >
            <div className="flex items-center gap-3 mb-6">
              <h2 className="text-2xl font-semibold text-[#F0EDE8]">
                About {driver.name.split(' ')[0]}
              </h2>
              <div className="w-10 h-0.5 bg-[#D4A853]" />
            </div>
            <div className="text-[#8A8A96] leading-[1.7] space-y-4">
              {driver.bio.split('\n\n').map((p, i) => (
                <p key={i}>{p}</p>
              ))}
            </div>

            {/* USPs */}
            <div className="mt-8 space-y-3">
              {driver.usps.map((usp, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -15 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: i * 0.1, ease: easeEnter }}
                  className="flex items-start gap-3"
                >
                  <CheckCircle size={20} className="text-[#D4A853] shrink-0 mt-0.5" />
                  <span className="text-[#F0EDE8] text-sm">{usp}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Right — Vehicle Card */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2, ease: easeEnter }}
            className="bg-[#141419] border border-[#2A2A35] rounded-2xl overflow-hidden shadow-elevated"
          >
            <img
              src={driver.vehicle.image}
              alt={vehicleInfo}
              className="w-full aspect-[16/10] object-cover"
            />
            <div className="p-6">
              <h3 className="text-xl font-semibold text-[#F0EDE8]">
                {vehicleInfo}
              </h3>

              {/* Specs grid */}
              <div className="grid grid-cols-2 gap-3 mt-4">
                <div className="flex items-center gap-2 text-xs text-[#8A8A96]">
                  <Users size={16} className="text-[#5A5A66]" />
                  {driver.vehicle.capacity} Passengers
                </div>
                <div className="flex items-center gap-2 text-xs text-[#8A8A96]">
                  <Luggage size={16} className="text-[#5A5A66]" />
                  {driver.vehicle.luggage} Large Bags
                </div>
                <div className="flex items-center gap-2 text-xs text-[#8A8A96]">
                  <Calendar size={16} className="text-[#5A5A66]" />
                  {driver.vehicle.year} Model
                </div>
                <div className="flex items-center gap-2 text-xs text-[#8A8A96]">
                  <Shield size={16} className="text-[#5A5A66]" />
                  Fully Insured
                </div>
              </div>

              {/* Features */}
              <div className="flex flex-wrap gap-2 mt-4">
                {features.map((f) => (
                  <span
                    key={f}
                    className="px-3 py-1 rounded-full text-xs bg-[#1E1E26] border border-[#2A2A35] text-[#8A8A96]"
                  >
                    {f}
                  </span>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ========== Section 3: Services ========== */}
      <section className="py-16 bg-[#0D0D12]">
        <div className="max-w-[1280px] mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: easeEnter }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl font-semibold text-[#F0EDE8]">
              Services &amp; Pricing
            </h2>
            <p className="mt-2 text-[#8A8A96] max-w-[600px] mx-auto">
              Choose the service that fits your needs. All bookings include
              professional service and an immaculate vehicle.
            </p>
          </motion.div>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {driver.services.map((svc, i) => (
              <ServiceCard
                key={svc.id}
                service={svc}
                driverId={driver.id}
                index={i}
              />
            ))}
          </div>
        </div>
      </section>

      {/* ========== Section 4: Reviews ========== */}
      <section className="py-16 max-w-[1280px] mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: easeEnter }}
          className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8"
        >
          <h2 className="text-3xl font-semibold text-[#F0EDE8]">
            What Clients Say
          </h2>
          <div className="flex items-center gap-3 mt-3 sm:mt-0">
            <div className="flex gap-0.5">
              {[1, 2, 3, 4, 5].map((s) => (
                <Star
                  key={s}
                  size={18}
                  className="text-[#D4A853] fill-[#D4A853]"
                />
              ))}
            </div>
            <span className="text-sm text-[#F0EDE8] font-medium">
              {driver.ratings.average} out of 5
            </span>
            <span className="text-sm text-[#5A5A66]">
              {driver.ratings.count} reviews
            </span>
          </div>
        </motion.div>

        <div className="flex gap-6 overflow-x-auto pb-4 snap-x snap-mandatory scrollbar-hide">
          {driver.reviews.map((review, i) => (
            <div key={review.id} className="snap-start">
              <ReviewCard review={review} index={i} />
            </div>
          ))}
        </div>
      </section>

      {/* ========== Section 5: Booking CTA ========== */}
      <section className="relative py-24 bg-[#0D0D12] border-t border-b border-[#2A2A35] overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-[#D4A853] opacity-[0.06] blur-[120px]" />
        <div className="relative z-10 max-w-[640px] mx-auto px-6 text-center">
          <motion.img
            initial={{ scale: 0.8, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: easeEnter }}
            src={driver.avatar}
            alt={driver.name}
            className="w-24 h-24 rounded-full object-cover border-[3px] border-[#D4A853] mx-auto mb-6 shadow-[0_4px_20px_rgba(212,168,83,0.2)]"
          />
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: easeEnter }}
            className="text-3xl font-semibold text-[#F0EDE8]"
          >
            Book with {driver.name.split(' ')[0]}
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1, ease: easeEnter }}
            className="mt-3 text-lg text-[#8A8A96]"
          >
            Ready to ride? Choose your service and book in under 60 seconds.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2, ease: easeEnter }}
          >
            <button
              onClick={() => navigate(`/book/${driver.id}`)}
              className="mt-8 inline-flex items-center px-8 py-4 rounded-full text-base font-semibold text-[#0A0A0F] bg-gold-shine hover:scale-[1.02] hover:shadow-[0_4px_24px_rgba(212,168,83,0.3)] transition-all"
            >
              Book a Ride
            </button>
          </motion.div>
          {driver.phone && (
            <motion.p
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="mt-4 text-xs text-[#5A5A66]"
            >
              Or call directly: {driver.phone}
            </motion.p>
          )}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.35, ease: easeEnter }}
            className="flex items-center justify-center gap-6 mt-6"
          >
            <span className="flex items-center gap-1.5 text-xs text-[#5A5A66]">
              <ShieldCheck size={14} className="text-[#D4A853]" />
              Verified
            </span>
            <span className="flex items-center gap-1.5 text-xs text-[#5A5A66]">
              <Clock size={14} className="text-[#D4A853]" />
              {driver.responseTime} Response
            </span>
            <span className="flex items-center gap-1.5 text-xs text-[#5A5A66]">
              <Star size={14} className="text-[#D4A853] fill-[#D4A853]" />
              {driver.ratings.average} Rating
            </span>
          </motion.div>
        </div>
      </section>

      {/* ========== Section 6: Other Drivers ========== */}
      <section className="py-16 max-w-[1280px] mx-auto px-6">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-semibold text-[#F0EDE8]">
            You Might Also Like
          </h2>
          <Link
            to="/drivers"
            className="text-sm text-[#D4A853] hover:text-[#E8C87A] transition-colors"
          >
            Browse All
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {otherDrivers.map((d, i) => (
            <MiniDriverCard key={d.id} driver={d} index={i} />
          ))}
        </div>
      </section>
    </div>
  )
}
