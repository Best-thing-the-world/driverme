import { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import {
  Wallet,
  Calendar,
  CalendarCheck,
  Car,
  ArrowUp,
  ArrowDown,
  ChevronRight,
  CheckCircle,
  UserPlus,
  CreditCard,
  Star,
  Plus,
  CalendarPlus,
  FileText,
  Settings,
  HelpCircle,
  TrendingUp,
} from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { cn } from '@/lib/utils';
import DashboardLayout from '@/components/DashboardLayout';
import {
  kpiData,
  revenueChartData30D,
  revenueChartData7D,
  revenueChartData3M,
  revenueChartData1Y,
  upcomingBookings,
  activityFeed,
  topClients,
  quickActions,
  statusConfig,
  type ChartDataPoint,
} from '@/lib/dashboard-data';

const iconMap: Record<string, React.ElementType> = {
  Wallet,
  Calendar,
  CalendarCheck,
  Car,
  CheckCircle,
  UserPlus,
  CreditCard,
  Star,
  Plus,
  CalendarPlus,
  FileText,
  Settings,
  HelpCircle,
};

/* ─── Animated number counter ─── */
function useCountUp(end: number, duration: number = 1500, startOnMount: boolean = true) {
  const [count, setCount] = useState(0);
  const [started, setStarted] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!startOnMount) {
      const observer = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting && !started) {
            setStarted(true);
          }
        },
        { threshold: 0.1 }
      );
      if (ref.current) observer.observe(ref.current);
      return () => observer.disconnect();
    } else {
      const timer = setTimeout(() => setStarted(true), 300);
      return () => clearTimeout(timer);
    }
  }, [startOnMount, started]);

  useEffect(() => {
    if (!started) return;
    let startTime: number;
    let raf: number;
    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setCount(Math.floor(eased * end));
      if (progress < 1) raf = requestAnimationFrame(animate);
    };
    raf = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(raf);
  }, [started, end, duration]);

  return { count, ref };
}

function AnimatedValue({ value, numericValue }: { value: string; numericValue: number }) {
  const { count, ref } = useCountUp(numericValue, 1500);
  const prefix = value.startsWith('$') ? '$' : '';
  const suffix = value.includes('%') ? '%' : '';
  const displayValue = prefix + count.toLocaleString() + suffix;

  return (
    <div ref={ref} className="font-mono text-[28px] font-bold text-[#F0EDE8] mt-2">
      {displayValue}
    </div>
  );
}

/* ─── KPI Card ─── */
function KPICard({
  kpi,
  index,
}: {
  kpi: (typeof kpiData)[0];
  index: number;
}) {
  const Icon = iconMap[kpi.icon] || Wallet;
  const numericValue = parseInt(kpi.value.replace(/[$,%]/g, ''));

  return (
    <div
      className={cn(
        'bg-[#141419] border border-[#2A2A35] rounded-xl p-5 transition-all duration-300',
        'hover:border-[rgba(212,168,83,0.15)] hover:-translate-y-0.5'
      )}
      style={{
        animation: `fadeUp 0.5s cubic-bezier(0,0,0.2,1) ${index * 0.1}s both`,
      }}
    >
      <div className="flex items-center justify-between">
        <div
          className="w-8 h-8 rounded-lg flex items-center justify-center"
          style={{ backgroundColor: kpi.iconBg }}
        >
          <Icon size={18} style={{ color: kpi.iconBg.replace('0.1', '1').replace('rgba(', '').replace(')', '') === '212,168,83,1' ? '#D4A853' : undefined }} className="text-[#D4A853]" />
        </div>
        <span className="text-xs text-[#5A5A66] font-medium">{kpi.label}</span>
      </div>
      <AnimatedValue value={kpi.value} numericValue={numericValue} />
      {kpi.change && (
        <div className="flex items-center gap-1 mt-2">
          {kpi.changeType === 'positive' ? (
            <ArrowUp size={12} className="text-[#22C55E]" />
          ) : kpi.changeType === 'negative' ? (
            <ArrowDown size={12} className="text-[#EF4444]" />
          ) : null}
          <span
            className={cn(
              'text-xs font-medium',
              kpi.changeType === 'positive' && 'text-[#22C55E]',
              kpi.changeType === 'negative' && 'text-[#EF4444]',
              kpi.changeType === 'neutral' && 'text-[#5A5A66]'
            )}
          >
            {kpi.change}
          </span>
          <span className="text-xs text-[#5A5A66]">vs last month</span>
        </div>
      )}
    </div>
  );
}

/* ─── Custom Chart Tooltip ─── */
function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ value: number }>; label?: string }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-[#1E1E26] border border-[#D4A853] rounded-lg px-4 py-3 shadow-lg">
      <p className="text-xs text-[#5A5A66] mb-1">{label}</p>
      <p className="text-sm font-semibold text-[#F0EDE8] font-mono">
        ${payload[0].value.toLocaleString()}
      </p>
    </div>
  );
}

/* ─── Revenue Chart ─── */
function RevenueChart() {
  const [period, setPeriod] = useState<'7D' | '30D' | '3M' | '1Y'>('30D');

  const chartData: Record<string, ChartDataPoint[]> = {
    '7D': revenueChartData7D,
    '30D': revenueChartData30D,
    '3M': revenueChartData3M,
    '1Y': revenueChartData1Y,
  };

  const periods: Array<'7D' | '30D' | '3M' | '1Y'> = ['7D', '30D', '3M', '1Y'];

  return (
    <div className="bg-[#141419] border border-[#2A2A35] rounded-xl p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h4 className="text-xl font-semibold text-[#F0EDE8]">Revenue Overview</h4>
        <div className="flex items-center gap-1 bg-[#0A0A0F] rounded-lg p-1">
          {periods.map((p) => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={cn(
                'px-3 py-1.5 rounded-md text-xs font-medium transition-all duration-150',
                period === p
                  ? 'bg-[#1E1E26] text-[#D4A853]'
                  : 'text-[#8A8A96] hover:text-[#F0EDE8]'
              )}
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {/* Chart */}
      <ResponsiveContainer width="100%" height={280}>
        <AreaChart data={chartData[period]} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
          <defs>
            <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#D4A853" stopOpacity={0.15} />
              <stop offset="100%" stopColor="#D4A853" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(42,42,53,0.3)" vertical={false} />
          <XAxis
            dataKey="date"
            tick={{ fill: '#5A5A66', fontSize: 11 }}
            axisLine={false}
            tickLine={false}
          />
          <YAxis
            tick={{ fill: '#5A5A66', fontSize: 11 }}
            axisLine={false}
            tickLine={false}
            tickFormatter={(v: number) => `$${v}`}
          />
          <Tooltip content={<CustomTooltip />} />
          <Area
            type="monotone"
            dataKey="revenue"
            stroke="#D4A853"
            strokeWidth={2}
            fill="url(#revenueGradient)"
            dot={false}
            activeDot={{ r: 4, fill: '#D4A853', stroke: '#0A0A0F', strokeWidth: 2 }}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

/* ─── Upcoming Bookings ─── */
function UpcomingBookings() {
  return (
    <div className="bg-[#141419] border border-[#2A2A35] rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <h4 className="text-xl font-semibold text-[#F0EDE8]">Upcoming Bookings</h4>
        <Link
          to="/dashboard/bookings"
          className="text-sm text-[#D4A853] hover:text-[#E8C87A] transition-colors flex items-center gap-1"
        >
          View All
          <ChevronRight size={14} />
        </Link>
      </div>
      <div className="space-y-0">
        {upcomingBookings.map((booking, i) => {
          const status = statusConfig[booking.status];
          return (
            <div
              key={booking.id}
              className={cn(
                'flex items-center gap-3 py-3 transition-colors duration-200 -mx-2 px-2 rounded-lg cursor-pointer group',
                i < upcomingBookings.length - 1 && 'border-b border-[#2A2A35]',
                'hover:bg-[#1A1A22]'
              )}
              style={{
                animation: `slideRight 0.4s cubic-bezier(0,0,0.2,1) ${0.3 + i * 0.08}s both`,
              }}
            >
              {/* Status dot */}
              <div
                className="w-2 h-2 rounded-full flex-shrink-0"
                style={{ backgroundColor: status?.color || '#8A8A96' }}
              />
              {/* Time */}
              <div className="w-28 flex-shrink-0">
                <p className="text-xs text-[#D4A853] font-medium">{booking.time}</p>
              </div>
              {/* Info */}
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-[#F0EDE8] truncate">{booking.client}</p>
                <p className="text-xs text-[#8A8A96] truncate">{booking.service}</p>
                <p className="text-xs text-[#5A5A66] truncate">{booking.pickup}</p>
              </div>
              {/* Price */}
              <div className="flex items-center gap-1 flex-shrink-0">
                <span className="text-xs font-mono font-semibold text-[#D4A853]">{booking.price}</span>
                <ChevronRight size={14} className="text-[#5A5A66] group-hover:text-[#8A8A96] transition-colors" />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ─── Activity Feed ─── */
function ActivityFeed() {
  return (
    <div className="bg-[#141419] border border-[#2A2A35] rounded-xl p-6">
      <h4 className="text-xl font-semibold text-[#F0EDE8] mb-4">Recent Activity</h4>
      <div className="space-y-0">
        {activityFeed.map((item, i) => {
          const Icon = iconMap[item.icon] || CheckCircle;
          return (
            <div
              key={item.id}
              className={cn(
                'flex items-start gap-3 py-3',
                i < activityFeed.length - 1 && 'border-b border-[#2A2A35]'
              )}
              style={{
                animation: `fadeIn 0.3s ease ${0.5 + i * 0.08}s both`,
              }}
            >
              <div
                className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5"
                style={{ backgroundColor: item.iconBg }}
              >
                <Icon size={14} style={{ color: item.iconColor }} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-[#F0EDE8]">{item.description}</p>
                <p className="text-xs text-[#5A5A66] mt-0.5">{item.timestamp}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ─── Top Clients ─── */
function TopClients() {
  return (
    <div className="bg-[#141419] border border-[#2A2A35] rounded-xl p-6">
      <h4 className="text-xl font-semibold text-[#F0EDE8] mb-4">Top Clients</h4>
      <div className="space-y-3">
        {topClients.map((client, i) => (
          <div
            key={client.id}
            className="flex items-center gap-3"
            style={{
              animation: `fadeIn 0.3s ease ${0.6 + i * 0.08}s both`,
            }}
          >
            <div
              className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
              style={{ backgroundColor: client.avatarColor }}
            >
              <span className="text-xs font-semibold text-[#0A0A0F]">{client.initials}</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-[#F0EDE8] truncate">{client.name}</p>
            </div>
            <div className="text-right flex-shrink-0">
              <p className="text-xs font-mono font-semibold text-[#D4A853]">{client.totalSpent}</p>
              <p className="text-xs text-[#5A5A66]">{client.rides} rides</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ─── Quick Actions ─── */
function QuickActions() {
  return (
    <div className="bg-[#141419] border border-[#2A2A35] rounded-xl p-6">
      <h4 className="text-xl font-semibold text-[#F0EDE8] mb-4">Quick Actions</h4>
      <div className="grid grid-cols-3 gap-2">
        {quickActions.map((action, i) => {
          const Icon = iconMap[action.icon] || Plus;
          return (
            <button
              key={action.label}
              className={cn(
                'flex flex-col items-center justify-center gap-2 bg-[#1E1E26] border border-[#2A2A35] rounded-lg p-4 transition-all duration-200',
                'hover:bg-[#252530] hover:border-[rgba(212,168,83,0.3)] hover:shadow-[0_4px_24px_rgba(212,168,83,0.08)]'
              )}
              style={{
                animation: `fadeIn 0.3s ease ${0.65 + i * 0.05}s both`,
              }}
            >
              <Icon size={20} className="text-[#D4A853]" />
              <span className="text-[11px] text-[#8A8A96] font-medium text-center leading-tight">
                {action.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* ─── Performance Banner ─── */
function PerformanceBanner() {
  return (
    <div
      className={cn(
        'mt-6 rounded-xl border border-[rgba(212,168,83,0.15)] px-6 py-4 flex items-center gap-4',
        'bg-gradient-to-r from-[rgba(212,168,83,0.08)] to-transparent'
      )}
      style={{
        animation: 'slideLeft 0.6s cubic-bezier(0,0,0.2,1) 0.8s both',
      }}
    >
      <TrendingUp size={24} className="text-[#D4A853] flex-shrink-0" />
      <p className="flex-1 text-sm text-[#F0EDE8]">
        Your revenue is up 12% this month. You're on track for your best month yet!
      </p>
      <button className="text-sm text-[#D4A853] hover:text-[#E8C87A] transition-colors flex items-center gap-1 flex-shrink-0">
        View Details
        <ChevronRight size={14} />
      </button>
    </div>
  );
}

/* ─── Main Overview Page ─── */
export default function DashboardOverview() {
  const dateStr = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

  return (
    <DashboardLayout>
      {/* CSS Animations */}
      <style>{`
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes slideRight {
          from { opacity: 0; transform: translateX(-20px); }
          to { opacity: 1; transform: translateX(0); }
        }
        @keyframes slideLeft {
          from { opacity: 0; transform: translateX(-30px); }
          to { opacity: 1; transform: translateX(0); }
        }
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
      `}</style>

      {/* Welcome Header */}
      <div
        className="mb-8 flex flex-col sm:flex-row sm:items-end sm:justify-between gap-2"
        style={{ animation: 'fadeUp 0.4s cubic-bezier(0,0,0.2,1) 0s both' }}
      >
        <div>
          <h2 className="text-3xl font-bold text-[#F0EDE8]">
            {greeting}, Marcus
          </h2>
          <p className="text-base text-[#8A8A96] mt-1">
            Here's what's happening with your business today.
          </p>
        </div>
        <p className="text-xs text-[#5A5A66] font-medium">{dateStr}</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5 mb-8">
        {kpiData.map((kpi, i) => (
          <KPICard key={kpi.label} kpi={kpi} index={i} />
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 xl:grid-cols-5 gap-6">
        {/* Left: Revenue Chart */}
        <div className="xl:col-span-3">
          <RevenueChart />
        </div>
        {/* Right: Upcoming Bookings */}
        <div className="xl:col-span-2">
          <UpcomingBookings />
        </div>
      </div>

      {/* Secondary Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5 mt-6">
        <ActivityFeed />
        <TopClients />
        <QuickActions />
      </div>

      {/* Performance Banner */}
      <PerformanceBanner />
    </DashboardLayout>
  );
}
