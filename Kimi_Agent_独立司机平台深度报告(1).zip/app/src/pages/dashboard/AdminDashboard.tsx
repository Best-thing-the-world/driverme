import { useState } from 'react'
import { Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Users,
  UserCheck,
  CalendarCheck,
  Wallet,
  UserPlus,
  CheckCircle,
  CreditCard,
  Star,
  AlertTriangle,
  ArrowUpRight,
  TrendingUp,
  ChevronRight,
  Search,
  ShieldCheck,
} from 'lucide-react'
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts'
import { cn } from '@/lib/utils'

/* ------------------------------------------------------------------ */
/*  Mock Data                                                          */
/* ------------------------------------------------------------------ */

const kpiData = [
  {
    label: 'Total Drivers',
    value: 45,
    change: '+5 this month',
    changeType: 'up' as const,
    icon: Users,
    color: 'gold',
  },
  {
    label: 'Pending Approvals',
    value: 8,
    change: 'Awaiting review',
    changeType: 'neutral' as const,
    icon: UserCheck,
    color: 'amber',
  },
  {
    label: 'Monthly Bookings',
    value: 1247,
    change: '+12%',
    changeType: 'up' as const,
    icon: CalendarCheck,
    color: 'green',
  },
  {
    label: 'Platform Revenue',
    value: 186420,
    prefix: '$',
    change: '+18%',
    changeType: 'up' as const,
    icon: Wallet,
    color: 'gold',
  },
]

const pendingDrivers = [
  { id: '1', name: 'Carlos Mendez', location: 'Phoenix, AZ', vehicle: 'Mercedes E-Class 2023', applied: '2 days ago', initials: 'CM' },
  { id: '2', name: 'Priya Patel', location: 'Dallas, TX', vehicle: 'BMW X7', applied: '3 days ago', initials: 'PP' },
  { id: '3', name: 'William Brooks', location: 'Boston, MA', vehicle: 'Cadillac CT5', applied: '3 days ago', initials: 'WB' },
  { id: '4', name: 'Sophia Nguyen', location: 'San Diego, CA', vehicle: 'Tesla Model S', applied: '4 days ago', initials: 'SN' },
  { id: '5', name: 'Jamal Washington', location: 'Washington, DC', vehicle: 'Lincoln Continental', applied: '5 days ago', initials: 'JW' },
  { id: '6', name: 'Rachel Kim', location: 'Seattle, WA', vehicle: 'Genesis G80', applied: '5 days ago', initials: 'RK' },
  { id: '7', name: 'David Torres', location: 'Austin, TX', vehicle: 'Audi A6', applied: '6 days ago', initials: 'DT' },
  { id: '8', name: 'Lisa Anderson', location: 'Nashville, TN', vehicle: 'Volvo S90', applied: '6 days ago', initials: 'LA' },
]

const activityFeed = [
  { id: 1, icon: UserPlus, color: '#3B82F6', text: 'Carlos M. submitted driver application', time: '2 hours ago' },
  { id: 2, icon: CheckCircle, color: '#22C55E', text: 'Elena R. completed onboarding', time: '5 hours ago' },
  { id: 3, icon: CreditCard, color: '#D4A853', text: 'Monthly payout batch processed: $24,680', time: '1 day ago' },
  { id: 4, icon: Star, color: '#D4A853', text: 'Platform reached 1,000+ bookings milestone', time: '2 days ago' },
  { id: 5, icon: AlertTriangle, color: '#F59E0B', text: '3 bookings flagged for review', time: '2 days ago' },
  { id: 6, icon: CheckCircle, color: '#22C55E', text: 'Marcus J. approved (auto)', time: '3 days ago' },
]

const growthData = [
  { month: 'Jan', drivers: 12 },
  { month: 'Feb', drivers: 18 },
  { month: 'Mar', drivers: 22 },
  { month: 'Apr', drivers: 27 },
  { month: 'May', drivers: 32 },
  { month: 'Jun', drivers: 38 },
  { month: 'Jul', drivers: 42 },
  { month: 'Aug', drivers: 45 },
]

const serviceTypeData = [
  { name: 'Airport', value: 40, color: '#D4A853' },
  { name: 'Hourly', value: 25, color: '#E8C87A' },
  { name: 'Point-to-Point', value: 18, color: '#8B5CF6' },
  { name: 'Corporate', value: 12, color: '#3B82F6' },
  { name: 'Other', value: 5, color: '#6B6B78' },
]

const bookingsData = [
  { id: 'DL-0350', driver: 'Marcus J.', client: 'Amanda L.', service: 'Airport', date: 'Mar 15', amount: 85, status: 'new' },
  { id: 'DL-0349', driver: 'Elena R.', client: 'David C.', service: 'Hourly', date: 'Mar 14', amount: 225, status: 'confirmed' },
  { id: 'DL-0348', driver: 'Sarah M.', client: 'Lisa W.', service: 'Senior', date: 'Mar 13', amount: 110, status: 'completed' },
  { id: 'DL-0347', driver: 'James C.', client: 'Robert T.', service: 'Airport', date: 'Mar 12', amount: 95, status: 'completed' },
  { id: 'DL-0346', driver: 'Aida W.', client: 'Karen M.', service: 'VIP', date: 'Mar 11', amount: 600, status: 'completed' },
]

const topDrivers = [
  { rank: 1, name: 'Marcus J.', revenue: 14280, rides: 156, rating: 4.9, initials: 'MJ' },
  { rank: 2, name: 'James C.', revenue: 12840, rides: 142, rating: 4.8, initials: 'JC' },
  { rank: 3, name: 'Elena R.', revenue: 11520, rides: 128, rating: 4.9, initials: 'ER' },
  { rank: 4, name: 'Aida W.', revenue: 10680, rides: 118, rating: 4.8, initials: 'AW' },
  { rank: 5, name: 'Robert T.', revenue: 9450, rides: 105, rating: 4.7, initials: 'RT' },
]

const statusColors: Record<string, { bg: string; text: string }> = {
  new: { bg: 'rgba(59,130,246,0.1)', text: '#3B82F6' },
  accepted: { bg: 'rgba(245,158,11,0.1)', text: '#F59E0B' },
  confirmed: { bg: 'rgba(34,197,94,0.1)', text: '#22C55E' },
  in_progress: { bg: 'rgba(139,92,246,0.1)', text: '#8B5CF6' },
  completed: { bg: 'rgba(16,185,129,0.1)', text: '#10B981' },
  canceled: { bg: 'rgba(239,68,68,0.1)', text: '#EF4444' },
}

/* ------------------------------------------------------------------ */
/*  Animation helpers                                                  */
/* ------------------------------------------------------------------ */

const containerVariants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.1 } },
}

const itemVariants = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: [0.0, 0, 0.2, 1] as [number, number, number, number] } },
}

/* ------------------------------------------------------------------ */
/*  Custom Tooltip for Charts                                          */
/* ------------------------------------------------------------------ */

function ChartTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ value: number }>; label?: string }) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-[#1E1E26] border border-[#2A2A35] rounded-lg px-3 py-2 shadow-xl">
      <p className="text-xs text-[#5A5A66] mb-1">{label}</p>
      <p className="text-sm font-semibold text-[#F0EDE8]">{payload[0].value.toLocaleString()}</p>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/*  Main Component                                                     */
/* ------------------------------------------------------------------ */

export default function AdminDashboard() {
  const [drivers, setDrivers] = useState(pendingDrivers)
  const [approvalFilter, setApprovalFilter] = useState('')

  const handleApprove = (id: string) => {
    setDrivers((prev) => prev.filter((d) => d.id !== id))
  }

  const handleDecline = (id: string) => {
    setDrivers((prev) => prev.filter((d) => d.id !== id))
  }

  const filteredDrivers = drivers.filter(
    (d) =>
      d.name.toLowerCase().includes(approvalFilter.toLowerCase()) ||
      d.location.toLowerCase().includes(approvalFilter.toLowerCase())
  )

  const formatKpiValue = (kpi: (typeof kpiData)[0]) => {
    if (kpi.prefix) {
      return `${kpi.prefix}${kpi.value.toLocaleString()}`
    }
    return kpi.value.toLocaleString()
  }

  return (
    <>
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="show"
        className="space-y-6"
      >
        {/* ===== Section 1: KPI Cards ===== */}
        <motion.div variants={itemVariants} className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5">
          {kpiData.map((kpi) => {
            const Icon = kpi.icon
            const isAmber = kpi.color === 'amber'
            const isGreen = kpi.color === 'green'
            return (
              <motion.div
                key={kpi.label}
                whileHover={{ y: -4 }}
                transition={{ duration: 0.3 }}
                className={cn(
                  'bg-[#141419] border rounded-xl p-6 transition-all duration-300',
                  isAmber
                    ? 'border-[#F59E0B]/40 shadow-[0_0_20px_rgba(245,158,11,0.08)]'
                    : 'border-[#2A2A35] hover:border-[rgba(212,168,83,0.3)] hover:shadow-gold-sm'
                )}
              >
                <div className="flex items-start justify-between mb-4">
                  <div
                    className={cn(
                      'w-10 h-10 rounded-lg flex items-center justify-center',
                      isAmber && 'bg-[rgba(245,158,11,0.1)]',
                      isGreen && 'bg-[rgba(34,197,94,0.1)]',
                      !isAmber && !isGreen && 'bg-[rgba(212,168,83,0.1)]'
                    )}
                  >
                    <Icon
                      size={20}
                      className={cn(
                        isAmber && 'text-[#F59E0B]',
                        isGreen && 'text-[#22C55E]',
                        !isAmber && !isGreen && 'text-[#D4A853]'
                      )}
                    />
                  </div>
                  {kpi.changeType === 'up' && (
                    <div className="flex items-center gap-1 text-xs font-medium text-[#22C55E]">
                      <TrendingUp size={14} />
                      {kpi.change}
                    </div>
                  )}
                </div>
                <p className="text-sm text-[#8A8A96] mb-1">{kpi.label}</p>
                <p className="text-2xl font-bold text-[#F0EDE8] font-mono tracking-tight">
                  {formatKpiValue(kpi)}
                </p>
              </motion.div>
            )
          })}
        </motion.div>

        {/* ===== Section 2: Two-Column (Approvals + Activity) ===== */}
        <motion.div variants={itemVariants} className="grid grid-cols-1 xl:grid-cols-[1.4fr_1fr] gap-6">
          {/* Driver Approvals Queue */}
          <div className="bg-[#141419] border border-[#2A2A35] rounded-xl flex flex-col">
            <div className="p-6 border-b border-[#2A2A35]">
              <div className="flex items-center justify-between mb-1">
                <h3 className="text-lg font-semibold text-[#F0EDE8]">Pending Driver Approvals</h3>
                <Link
                  to="#"
                  className="flex items-center gap-1 text-sm text-[#D4A853] hover:text-[#E8C87A] transition-colors"
                >
                  View All <ChevronRight size={16} />
                </Link>
              </div>
              <p className="text-xs text-[#F59E0B]">{drivers.length} applications awaiting review</p>

              {/* Search */}
              <div className="mt-4 flex items-center bg-[#1E1E26] border border-[#2A2A35] rounded-lg px-3 py-2">
                <Search size={16} className="text-[#5A5A66] mr-2" />
                <input
                  type="text"
                  placeholder="Filter by name or location..."
                  value={approvalFilter}
                  onChange={(e) => setApprovalFilter(e.target.value)}
                  className="bg-transparent text-sm text-[#F0EDE8] placeholder:text-[#5A5A66] outline-none w-full"
                />
              </div>
            </div>

            <div className="flex-1 p-4 space-y-2 max-h-[440px] overflow-y-auto">
              <AnimatePresence mode="popLayout">
                {filteredDrivers.length === 0 ? (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex flex-col items-center justify-center py-12 text-center"
                  >
                    <ShieldCheck size={40} className="text-[#2A2A35] mb-3" />
                    <p className="text-sm text-[#5A5A66]">All caught up!</p>
                    <p className="text-xs text-[#5A5A66] mt-1">No pending driver approvals</p>
                  </motion.div>
                ) : (
                  filteredDrivers.map((driver, i) => (
                    <motion.div
                      key={driver.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: '100%' }}
                      transition={{ duration: 0.3, delay: i * 0.08 }}
                      layout
                      className="flex items-center gap-4 bg-[#0A0A0F] border border-[#2A2A35] rounded-xl p-4 hover:border-[rgba(212,168,83,0.2)] transition-colors"
                    >
                      {/* Avatar with status dot */}
                      <div className="relative shrink-0 self-start">
                        <div className="w-11 h-11 rounded-full bg-[#1E1E26] border border-[#2A2A35] flex items-center justify-center">
                          <span className="text-sm font-semibold text-[#D4A853]">{driver.initials}</span>
                        </div>
                        <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-[#F59E0B] border-2 border-[#0A0A0F]" />
                      </div>

                      {/* Info */}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-[#F0EDE8]">{driver.name}</p>
                        <p className="text-xs text-[#5A5A66] mt-0.5">{driver.location}</p>
                        <p className="text-xs text-[#5A5A66]">{driver.vehicle}</p>
                        <p className="text-xs text-[#5A5A66] mt-0.5">Applied {driver.applied}</p>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={() => handleApprove(driver.id)}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold bg-[#22C55E] text-[#0A0A0F] hover:brightness-110 transition-all"
                        >
                          <CheckCircle size={12} />
                          Approve
                        </button>
                        <button
                          onClick={() => handleDecline(driver.id)}
                          className="px-3 py-1.5 rounded-full text-xs font-semibold text-[#8A8A96] border border-[#2A2A35] hover:text-[#EF4444] hover:border-[#EF4444]/40 transition-all"
                        >
                          Decline
                        </button>
                      </div>
                    </motion.div>
                  ))
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* Activity Feed */}
          <div className="bg-[#141419] border border-[#2A2A35] rounded-xl">
            <div className="p-6 border-b border-[#2A2A35]">
              <h3 className="text-lg font-semibold text-[#F0EDE8]">Recent Platform Activity</h3>
            </div>
            <div className="p-4 space-y-1">
              {activityFeed.map((item, i) => {
                const Icon = item.icon
                return (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: i * 0.08 }}
                    className="flex items-start gap-3 p-3 rounded-lg hover:bg-[#1A1A22] transition-colors"
                  >
                    <div
                      className="w-8 h-8 rounded-full flex items-center justify-center shrink-0 mt-0.5"
                      style={{ backgroundColor: `${item.color}15` }}
                    >
                      <Icon size={15} style={{ color: item.color }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-[#F0EDE8] leading-snug">{item.text}</p>
                      <p className="text-xs text-[#5A5A66] mt-1">{item.time}</p>
                    </div>
                  </motion.div>
                )
              })}
            </div>
          </div>
        </motion.div>

        {/* ===== Section 3: Charts Row ===== */}
        <motion.div variants={itemVariants} className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Driver Growth Chart */}
          <div className="bg-[#141419] border border-[#2A2A35] rounded-xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h4 className="text-base font-semibold text-[#F0EDE8]">Driver Growth</h4>
              <div className="flex items-center gap-1 bg-[#1E1E26] rounded-lg p-0.5">
                {['6M', '1Y', 'All'].map((period) => (
                  <button
                    key={period}
                    className={cn(
                      'px-3 py-1 rounded-md text-xs font-medium transition-all',
                      period === 'All'
                        ? 'bg-[#2A2A35] text-[#F0EDE8]'
                        : 'text-[#5A5A66] hover:text-[#8A8A96]'
                    )}
                  >
                    {period}
                  </button>
                ))}
              </div>
            </div>
            <ResponsiveContainer width="100%" height={240}>
              <AreaChart data={growthData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="goldArea" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#D4A853" stopOpacity={0.15} />
                    <stop offset="100%" stopColor="#D4A853" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(42,42,53,0.5)" />
                <XAxis
                  dataKey="month"
                  tick={{ fill: '#5A5A66', fontSize: 12 }}
                  axisLine={{ stroke: '#2A2A35' }}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fill: '#5A5A66', fontSize: 12 }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip content={<ChartTooltip />} />
                <Area
                  type="monotone"
                  dataKey="drivers"
                  stroke="#D4A853"
                  strokeWidth={2.5}
                  fill="url(#goldArea)"
                  dot={{ fill: '#D4A853', r: 4, stroke: '#141419', strokeWidth: 2 }}
                  activeDot={{ r: 6, stroke: '#D4A853', strokeWidth: 2, fill: '#141419' }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Bookings by Service Type - Donut */}
          <div className="bg-[#141419] border border-[#2A2A35] rounded-xl p-6">
            <h4 className="text-base font-semibold text-[#F0EDE8] mb-6">Bookings by Service</h4>
            <div className="flex items-center gap-6">
              <div className="w-1/2">
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie
                      data={serviceTypeData}
                      cx="50%"
                      cy="50%"
                      innerRadius={55}
                      outerRadius={85}
                      paddingAngle={3}
                      dataKey="value"
                      stroke="none"
                    >
                      {serviceTypeData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      content={({ active, payload }) => {
                        if (!active || !payload?.length) return null
                        const data = payload[0].payload as { name: string; value: number }
                        return (
                          <div className="bg-[#1E1E26] border border-[#2A2A35] rounded-lg px-3 py-2 shadow-xl">
                            <p className="text-sm font-medium text-[#F0EDE8]">{data.name}</p>
                            <p className="text-xs text-[#5A5A66]">{data.value}%</p>
                          </div>
                        )
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
                {/* Center text */}
                <div className="relative -mt-[130px] mb-[60px] text-center pointer-events-none">
                  <p className="text-xl font-bold text-[#F0EDE8] font-mono">1,247</p>
                  <p className="text-xs text-[#5A5A66]">bookings</p>
                </div>
              </div>
              {/* Legend */}
              <div className="w-1/2 space-y-3">
                {serviceTypeData.map((item) => (
                  <div key={item.name} className="flex items-center gap-3">
                    <span
                      className="w-3 h-3 rounded-full shrink-0"
                      style={{ backgroundColor: item.color }}
                    />
                    <span className="text-sm text-[#8A8A96] flex-1">{item.name}</span>
                    <span className="text-sm font-semibold text-[#F0EDE8] font-mono">{item.value}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>

        {/* ===== Section 4: Recent Bookings Table ===== */}
        <motion.div variants={itemVariants} className="bg-[#141419] border border-[#2A2A35] rounded-xl">
          <div className="p-6 border-b border-[#2A2A35] flex items-center justify-between flex-wrap gap-4">
            <h3 className="text-lg font-semibold text-[#F0EDE8]">Recent Bookings</h3>
            <Link
              to="#"
              className="flex items-center gap-1 text-sm text-[#D4A853] hover:text-[#E8C87A] transition-colors"
            >
              View All <ArrowUpRight size={16} />
            </Link>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#2A2A35]">
                  {['Booking ID', 'Driver', 'Client', 'Service', 'Date', 'Amount', 'Status'].map((h) => (
                    <th
                      key={h}
                      className="text-left px-5 py-4 text-xs font-semibold text-[#8A8A96] uppercase tracking-wider"
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {bookingsData.map((booking, i) => (
                  <motion.tr
                    key={booking.id}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: i * 0.04 }}
                    className="border-b border-[#2A2A35] hover:bg-[#1A1A22] transition-colors"
                  >
                    <td className="px-5 py-4">
                      <span className="text-sm font-mono font-medium text-[#F0EDE8]">{booking.id}</span>
                    </td>
                    <td className="px-5 py-4">
                      <span className="text-sm text-[#F0EDE8]">{booking.driver}</span>
                    </td>
                    <td className="px-5 py-4">
                      <span className="text-sm text-[#8A8A96]">{booking.client}</span>
                    </td>
                    <td className="px-5 py-4">
                      <span className="text-sm text-[#8A8A96]">{booking.service}</span>
                    </td>
                    <td className="px-5 py-4">
                      <span className="text-sm text-[#8A8A96]">{booking.date}</span>
                    </td>
                    <td className="px-5 py-4">
                      <span className="text-sm font-mono font-medium text-[#D4A853]">${booking.amount}</span>
                    </td>
                    <td className="px-5 py-4">
                      <span
                        className="inline-flex px-2.5 py-1 rounded-full text-xs font-semibold capitalize"
                        style={{
                          backgroundColor: statusColors[booking.status]?.bg || 'rgba(128,128,128,0.1)',
                          color: statusColors[booking.status]?.text || '#8A8A96',
                        }}
                      >
                        {booking.status === 'in_progress' ? 'In Progress' : booking.status}
                      </span>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>

        {/* ===== Section 5: Top Performing Drivers ===== */}
        <motion.div variants={itemVariants}>
          <h3 className="text-lg font-semibold text-[#F0EDE8] mb-4">Top Performing Drivers</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
            {topDrivers.map((driver, i) => (
              <motion.div
                key={driver.rank}
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4, delay: i * 0.1 }}
                whileHover={{ y: -4 }}
                className="bg-[#141419] border border-[#2A2A35] rounded-xl p-5 hover:border-[rgba(212,168,83,0.3)] hover:shadow-gold-sm transition-all duration-300"
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-7 h-7 rounded-full bg-[#D4A853] flex items-center justify-center">
                    <span className="text-xs font-bold text-[#0A0A0F]">#{driver.rank}</span>
                  </div>
                  <div className="w-10 h-10 rounded-full bg-[#1E1E26] border border-[#2A2A35] flex items-center justify-center">
                    <span className="text-sm font-semibold text-[#D4A853]">{driver.initials}</span>
                  </div>
                </div>
                <p className="text-sm font-semibold text-[#F0EDE8] mb-3">{driver.name}</p>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-[#5A5A66]">Revenue</span>
                    <span className="text-sm font-mono font-semibold text-[#D4A853]">
                      ${driver.revenue.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-[#5A5A66]">Rides</span>
                    <span className="text-sm text-[#8A8A96]">{driver.rides}</span>
                  </div>
                  <div className="flex items-center gap-1.5 pt-1 border-t border-[#2A2A35]">
                    <Star size={12} className="text-[#D4A853] fill-[#D4A853]" />
                    <span className="text-xs font-medium text-[#D4A853]">{driver.rating}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </motion.div>
    </>
  )
}
