import { useState, useMemo } from 'react';
import {
  UserPlus,
  Users,
  Briefcase,
  RotateCcw,
  Search,
  LayoutList,
  LayoutGrid,
  MoreHorizontal,
  Mail,
  Phone,
  Calendar,
  Clock,
  X,
  Edit,
  MessageSquare,
  Heart,
  ChevronRight,
  Plus,
  Trash2,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import DashboardLayout from '@/components/DashboardLayout';
import {
  customers,
  crmStats,
  bookings,
  customerTypeConfig,
  type Customer,
  type Note,
} from '@/lib/dashboard-data';

const statusConfig: Record<string, { color: string; bg: string; label: string }> = {
  new: { color: '#3B82F6', bg: 'rgba(59,130,246,0.1)', label: 'New' },
  accepted: { color: '#F59E0B', bg: 'rgba(245,158,11,0.1)', label: 'Accepted' },
  confirmed: { color: '#22C55E', bg: 'rgba(34,197,94,0.1)', label: 'Confirmed' },
  in_progress: { color: '#8B5CF6', bg: 'rgba(139,92,246,0.1)', label: 'In Progress' },
  completed: { color: '#10B981', bg: 'rgba(16,185,129,0.1)', label: 'Completed' },
  canceled: { color: '#EF4444', bg: 'rgba(239,68,68,0.1)', label: 'Canceled' },
};

const statIcons: Record<string, React.ElementType> = {
  Users,
  Briefcase,
  RotateCcw,
  UserPlus,
};

const filterOptions = ['All Clients', 'Corporate', 'Personal', 'Recurring'];

/* ─── Customer Type Badge ─── */
function TypeBadge({ type }: { type: string }) {
  const config = customerTypeConfig[type];
  if (!config) return null;
  return (
    <div className="flex items-center gap-1.5">
      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: config.color }} />
      <span className="text-xs font-medium" style={{ color: config.color }}>
        {config.label}
      </span>
    </div>
  );
}

/* ─── Tag Pill ─── */
function TagPill({ tag }: { tag: string }) {
  return (
    <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium text-[#D4A853] border border-[rgba(212,168,83,0.3)] bg-[rgba(212,168,83,0.05)]">
      {tag}
    </span>
  );
}

/* ─── Add Client Modal ─── */
function AddClientModal({ onClose, onAdd }: { onClose: () => void; onAdd: (c: Customer) => void }) {
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    type: 'personal' as 'personal' | 'corporate' | 'recurring',
    tags: '',
    notes: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = 'Name is required';
    if (form.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Invalid email';
    if (form.phone && !/^\([0-9]{3}\)\s[0-9]{3}-[0-9]{4}$/.test(form.phone)) {
      // soft validation
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;
    const initials = form.name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase();
    const colors = ['#D4A853', '#3B82F6', '#22C55E', '#8B5CF6', '#EF4444', '#F59E0B', '#14B8A6', '#EC4899', '#6366F1', '#A855F7'];
    const newClient: Customer = {
      id: `c${Date.now()}`,
      name: form.name,
      email: form.email,
      phone: form.phone,
      type: form.type,
      totalSpent: 0,
      rides: 0,
      lastRide: 'Never',
      memberSince: new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
      tags: form.tags
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean),
      initials,
      avatarColor: colors[Math.floor(Math.random() * colors.length)],
      notes: form.notes
        ? [
            {
              id: `n${Date.now()}`,
              content: form.notes,
              createdAt: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
              createdBy: 'You',
            },
          ]
        : [],
      bookings: [],
    };
    onAdd(newClient);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-[4px]" />
      <div
        className="relative bg-[#141419] border border-[#2A2A35] rounded-2xl w-full max-w-[520px] shadow-2xl"
        style={{ animation: 'slideUp 0.4s cubic-bezier(0.34, 1.56, 0.64, 1)' }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-6 border-b border-[#2A2A35]">
          <h3 className="text-xl font-semibold text-[#F0EDE8]">Add New Client</h3>
          <button onClick={onClose} className="p-2 rounded-lg text-[#5A5A66] hover:text-[#F0EDE8] hover:bg-[#1E1E26] transition-colors">
            <X size={18} />
          </button>
        </div>
        <div className="p-6 space-y-4">
          <div>
            <label className="block text-xs text-[#8A8A96] mb-1.5">Name *</label>
            <input
              type="text"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className={cn(
                'w-full h-10 px-4 rounded-lg bg-[#1E1E26] border text-sm text-[#F0EDE8] placeholder-[#5A5A66] focus:outline-none focus:border-[#D4A853] focus:ring-[3px] focus:ring-[rgba(212,168,83,0.15)] transition-all',
                errors.name ? 'border-[#EF4444]' : 'border-[#2A2A35]'
              )}
              placeholder="Client name"
            />
            {errors.name && <p className="text-xs text-[#EF4444] mt-1">{errors.name}</p>}
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-[#8A8A96] mb-1.5">Email</label>
              <input
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className={cn(
                  'w-full h-10 px-4 rounded-lg bg-[#1E1E26] border text-sm text-[#F0EDE8] placeholder-[#5A5A66] focus:outline-none focus:border-[#D4A853] focus:ring-[3px] focus:ring-[rgba(212,168,83,0.15)] transition-all',
                  errors.email ? 'border-[#EF4444]' : 'border-[#2A2A35]'
                )}
                placeholder="email@example.com"
              />
              {errors.email && <p className="text-xs text-[#EF4444] mt-1">{errors.email}</p>}
            </div>
            <div>
              <label className="block text-xs text-[#8A8A96] mb-1.5">Phone</label>
              <input
                type="tel"
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                className="w-full h-10 px-4 rounded-lg bg-[#1E1E26] border border-[#2A2A35] text-sm text-[#F0EDE8] placeholder-[#5A5A66] focus:outline-none focus:border-[#D4A853] focus:ring-[3px] focus:ring-[rgba(212,168,83,0.15)] transition-all"
                placeholder="(404) 555-0123"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-[#8A8A96] mb-1.5">Type</label>
              <select
                value={form.type}
                onChange={(e) => setForm({ ...form, type: e.target.value as 'personal' | 'corporate' | 'recurring' })}
                className="w-full h-10 px-4 rounded-lg bg-[#1E1E26] border border-[#2A2A35] text-sm text-[#F0EDE8] focus:outline-none focus:border-[#D4A853] focus:ring-[3px] focus:ring-[rgba(212,168,83,0.15)] transition-all appearance-none"
              >
                <option value="personal">Personal</option>
                <option value="corporate">Corporate</option>
                <option value="recurring">Recurring</option>
              </select>
            </div>
            <div>
              <label className="block text-xs text-[#8A8A96] mb-1.5">Tags (comma-separated)</label>
              <input
                type="text"
                value={form.tags}
                onChange={(e) => setForm({ ...form, tags: e.target.value })}
                className="w-full h-10 px-4 rounded-lg bg-[#1E1E26] border border-[#2A2A35] text-sm text-[#F0EDE8] placeholder-[#5A5A66] focus:outline-none focus:border-[#D4A853] focus:ring-[3px] focus:ring-[rgba(212,168,83,0.15)] transition-all"
                placeholder="VIP, Corporate, ..."
              />
            </div>
          </div>
          <div>
            <label className="block text-xs text-[#8A8A96] mb-1.5">Notes</label>
            <textarea
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              rows={3}
              className="w-full px-4 py-3 rounded-lg bg-[#1E1E26] border border-[#2A2A35] text-sm text-[#F0EDE8] placeholder-[#5A5A66] focus:outline-none focus:border-[#D4A853] focus:ring-[3px] focus:ring-[rgba(212,168,83,0.15)] transition-all resize-none"
              placeholder="Initial notes about this client..."
            />
          </div>
        </div>
        <div className="flex items-center justify-end gap-3 p-6 border-t border-[#2A2A35]">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-full text-sm font-semibold text-[#F0EDE8] border border-[#2A2A35] hover:bg-[#1E1E26] transition-all"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            className="px-5 py-2.5 rounded-full text-sm font-semibold text-[#0A0A0F] bg-[#D4A853] hover:scale-[1.02] hover:shadow-[0_4px_24px_rgba(212,168,83,0.3)] transition-all"
          >
            Save Client
          </button>
        </div>
      </div>
      <style>{`
        @keyframes slideUp {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}

/* ─── Client Detail Drawer ─── */
function ClientDetailDrawer({
  customer,
  onClose,
  onUpdateNotes,
}: {
  customer: Customer;
  onClose: () => void;
  onUpdateNotes: (id: string, notes: Note[]) => void;
}) {
  const [activeTab, setActiveTab] = useState<'overview' | 'bookings' | 'notes'>('overview');
  const [newNote, setNewNote] = useState('');

  const clientBookings = bookings.filter((b) =>
    customer.bookings.includes(b.id)
  );

  const handleAddNote = () => {
    if (!newNote.trim()) return;
    const note: Note = {
      id: `n${Date.now()}`,
      content: newNote.trim(),
      createdAt: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      createdBy: 'You',
    };
    onUpdateNotes(customer.id, [note, ...customer.notes]);
    setNewNote('');
  };

  const handleDeleteNote = (noteId: string) => {
    onUpdateNotes(
      customer.id,
      customer.notes.filter((n) => n.id !== noteId)
    );
  };

  const tabs = [
    { key: 'overview' as const, label: 'Overview' },
    { key: 'bookings' as const, label: 'Bookings' },
    { key: 'notes' as const, label: 'Notes' },
  ];

  return (
    <div className="fixed inset-0 z-50" onClick={onClose}>
      <div className="absolute inset-0 bg-black/50 backdrop-blur-[4px]" />
      <div
        className="absolute right-0 top-0 h-full w-full max-w-[480px] bg-[#141419] border-l border-[#2A2A35] shadow-2xl overflow-y-auto"
        style={{ animation: 'slideInRight 0.4s cubic-bezier(0.4,0,0.2,1)' }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 bg-[#141419] z-10 border-b border-[#2A2A35] p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-4">
              <div
                className="w-16 h-16 rounded-full flex items-center justify-center flex-shrink-0 relative"
                style={{ backgroundColor: customer.avatarColor }}
              >
                <span className="text-xl font-bold text-[#0A0A0F]">{customer.initials}</span>
                <div
                  className="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full border-2 border-[#141419]"
                  style={{ backgroundColor: customerTypeConfig[customer.type]?.color }}
                />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-[#F0EDE8]">{customer.name}</h2>
                <TypeBadge type={customer.type} />
              </div>
            </div>
            <div className="flex items-center gap-1">
              <button className="p-2 rounded-lg text-[#5A5A66] hover:text-[#F0EDE8] hover:bg-[#1E1E26] transition-colors">
                <Edit size={16} />
              </button>
              <button className="p-2 rounded-lg text-[#5A5A66] hover:text-[#F0EDE8] hover:bg-[#1E1E26] transition-colors">
                <MessageSquare size={16} />
              </button>
              <button
                onClick={onClose}
                className="p-2 rounded-lg text-[#5A5A66] hover:text-[#F0EDE8] hover:bg-[#1E1E26] transition-colors"
              >
                <X size={18} />
              </button>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex items-center gap-1 bg-[#0A0A0F] rounded-lg p-1">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={cn(
                  'flex-1 py-2 rounded-md text-sm font-medium transition-all duration-150',
                  activeTab === tab.key
                    ? 'bg-[#1E1E26] text-[#D4A853]'
                    : 'text-[#8A8A96] hover:text-[#F0EDE8]'
                )}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          {/* Overview Tab */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Contact Info */}
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <Mail size={15} className="text-[#8A8A96] flex-shrink-0" />
                  <span className="text-sm text-[#F0EDE8]">{customer.email}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Phone size={15} className="text-[#8A8A96] flex-shrink-0" />
                  <span className="text-sm text-[#F0EDE8]">{customer.phone}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Calendar size={15} className="text-[#8A8A96] flex-shrink-0" />
                  <span className="text-sm text-[#8A8A96]">
                    Member since <span className="text-[#F0EDE8]">{customer.memberSince}</span>
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <Clock size={15} className="text-[#8A8A96] flex-shrink-0" />
                  <span className="text-sm text-[#8A8A96]">
                    Last ride <span className="text-[#F0EDE8]">{customer.lastRide}</span>
                  </span>
                </div>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-[#1E1E26] rounded-lg p-4">
                  <p className="text-xs text-[#5A5A66] mb-1">Total Spent</p>
                  <p className="font-mono text-xl font-bold text-[#D4A853]">
                    ${customer.totalSpent.toLocaleString()}
                  </p>
                </div>
                <div className="bg-[#1E1E26] rounded-lg p-4">
                  <p className="text-xs text-[#5A5A66] mb-1">Total Rides</p>
                  <p className="font-mono text-xl font-bold text-[#F0EDE8]">{customer.rides}</p>
                </div>
                <div className="bg-[#1E1E26] rounded-lg p-4">
                  <p className="text-xs text-[#5A5A66] mb-1">Average Ride</p>
                  <p className="font-mono text-xl font-bold text-[#F0EDE8]">
                    ${customer.rides > 0 ? Math.round(customer.totalSpent / customer.rides) : 0}
                  </p>
                </div>
                <div className="bg-[#1E1E26] rounded-lg p-4">
                  <p className="text-xs text-[#5A5A66] mb-1">Relationship</p>
                  <p className="font-mono text-xl font-bold text-[#F0EDE8]">
                    {customer.memberSince.includes('2023')
                      ? '2 years'
                      : customer.memberSince.includes('2024')
                      ? '1 year'
                      : '< 1 year'}
                  </p>
                </div>
              </div>

              {/* Preferences */}
              {customer.preferences && customer.preferences.length > 0 && (
                <div>
                  <h5 className="text-sm font-semibold text-[#F0EDE8] mb-3">Preferences</h5>
                  <div className="flex flex-wrap gap-2">
                    {customer.preferences.map((pref, i) => (
                      <div
                        key={i}
                        className="flex items-center gap-2 bg-[#1E1E26] rounded-full px-3 py-1.5"
                      >
                        <Heart size={12} className="text-[#D4A853]" />
                        <span className="text-xs text-[#F0EDE8]">{pref}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Tags */}
              <div>
                <h5 className="text-sm font-semibold text-[#F0EDE8] mb-3">Tags</h5>
                <div className="flex flex-wrap gap-2">
                  {customer.tags.map((tag) => (
                    <TagPill key={tag} tag={tag} />
                  ))}
                </div>
              </div>

              {/* Recent Bookings */}
              {clientBookings.length > 0 && (
                <div>
                  <h5 className="text-sm font-semibold text-[#F0EDE8] mb-3">Recent Bookings</h5>
                  <div className="space-y-2">
                    {clientBookings.slice(0, 3).map((b) => (
                      <div
                        key={b.id}
                        className="flex items-center gap-3 bg-[#1E1E26] rounded-lg p-3"
                      >
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-[#F0EDE8] truncate">
                            {b.service.name}
                          </p>
                          <p className="text-xs text-[#5A5A66]">
                            {b.pickup.date} · {b.pickup.time}
                          </p>
                        </div>
                        <span className="font-mono text-sm font-semibold text-[#D4A853] flex-shrink-0">
                          ${b.price.toFixed(2)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Bookings Tab */}
          {activeTab === 'bookings' && (
            <div>
              {clientBookings.length > 0 ? (
                <div className="space-y-2">
                  {clientBookings.map((b) => (
                    <div
                      key={b.id}
                      className="flex items-center gap-3 bg-[#1E1E26] rounded-lg p-4"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-mono text-xs font-semibold text-[#D4A853]">
                            {b.id}
                          </span>
                          <span
                            className="px-2 py-0.5 rounded-full text-[10px] font-medium"
                            style={{
                              backgroundColor: statusConfig[b.status]?.bg,
                              color: statusConfig[b.status]?.color,
                            }}
                          >
                            {statusConfig[b.status]?.label}
                          </span>
                        </div>
                        <p className="text-sm text-[#F0EDE8]">{b.service.name}</p>
                        <p className="text-xs text-[#5A5A66]">
                          {b.pickup.date} · {b.pickup.time}
                        </p>
                      </div>
                      <span className="font-mono text-sm font-semibold text-[#D4A853] flex-shrink-0">
                        ${b.price.toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-[#5A5A66] text-center py-8">No bookings found for this client.</p>
              )}
            </div>
          )}

          {/* Notes Tab */}
          {activeTab === 'notes' && (
            <div className="space-y-4">
              {/* Add Note */}
              <div>
                <textarea
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                  rows={3}
                  placeholder="Write a note..."
                  className="w-full px-4 py-3 rounded-lg bg-[#1E1E26] border border-[#2A2A35] text-sm text-[#F0EDE8] placeholder-[#5A5A66] focus:outline-none focus:border-[#D4A853] focus:ring-[3px] focus:ring-[rgba(212,168,83,0.15)] transition-all resize-none"
                />
                <div className="flex justify-end mt-2">
                  <button
                    onClick={handleAddNote}
                    disabled={!newNote.trim()}
                    className={cn(
                      'px-4 py-2 rounded-full text-xs font-semibold transition-all',
                      newNote.trim()
                        ? 'text-[#0A0A0F] bg-[#D4A853] hover:scale-[1.02]'
                        : 'text-[#5A5A66] bg-[#1E1E26] cursor-not-allowed'
                    )}
                  >
                    Add Note
                  </button>
                </div>
              </div>

              {/* Notes List */}
              <div className="space-y-3">
                {customer.notes.length > 0 ? (
                  customer.notes.map((note) => (
                    <div
                      key={note.id}
                      className="border-l-[3px] border-[#D4A853] pl-3 py-1 group"
                    >
                      <p className="text-sm text-[#F0EDE8]">{note.content}</p>
                      <div className="flex items-center gap-2 mt-1.5">
                        <span className="text-[11px] text-[#D4A853]">{note.createdBy}</span>
                        <span className="text-[11px] text-[#5A5A66]">{note.createdAt}</span>
                        <button
                          onClick={() => handleDeleteNote(note.id)}
                          className="ml-auto opacity-0 group-hover:opacity-100 p-1 rounded text-[#5A5A66] hover:text-[#EF4444] transition-all"
                        >
                          <Trash2 size={12} />
                        </button>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-[#5A5A66] text-center py-8">No notes yet.</p>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
      <style>{`
        @keyframes slideInRight {
          from { transform: translateX(100%); }
          to { transform: translateX(0); }
        }
      `}</style>
    </div>
  );
}

/* ─── Client Table Row ─── */
function ClientTableRow({
  customer,
  index,
  onSelect,
}: {
  customer: Customer;
  index: number;
  onSelect: () => void;
}) {
  return (
    <tr
      className="border-b border-[#2A2A35] hover:bg-[#1A1A22] transition-colors cursor-pointer"
      onClick={onSelect}
      style={{ animation: `fadeRow 0.4s ease ${index * 0.05}s both` }}
    >
      <td className="px-5 py-3.5">
        <div className="flex items-center gap-3">
          <div
            className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
            style={{ backgroundColor: customer.avatarColor }}
          >
            <span className="text-[10px] font-semibold text-[#0A0A0F]">{customer.initials}</span>
          </div>
          <span className="text-sm font-medium text-[#F0EDE8]">{customer.name}</span>
        </div>
      </td>
      <td className="px-5 py-3.5">
        <TypeBadge type={customer.type} />
      </td>
      <td className="px-5 py-3.5">
        <p className="text-xs text-[#8A8A96]">{customer.email}</p>
        <p className="text-xs text-[#5A5A66]">{customer.phone}</p>
      </td>
      <td className="px-5 py-3.5">
        <span className="font-mono text-sm font-semibold text-[#D4A853]">
          ${customer.totalSpent.toLocaleString()}
        </span>
      </td>
      <td className="px-5 py-3.5">
        <span className="text-sm text-[#F0EDE8]">{customer.rides}</span>
      </td>
      <td className="px-5 py-3.5">
        <span className="text-xs text-[#8A8A96]">{customer.lastRide}</span>
      </td>
      <td className="px-5 py-3.5">
        <div className="flex flex-wrap gap-1">
          {customer.tags.slice(0, 3).map((tag) => (
            <TagPill key={tag} tag={tag} />
          ))}
          {customer.tags.length > 3 && (
            <span className="text-[10px] text-[#5A5A66]">+{customer.tags.length - 3}</span>
          )}
        </div>
      </td>
      <td className="px-5 py-3.5" onClick={(e) => e.stopPropagation()}>
        <button className="p-2 rounded-lg text-[#5A5A66] hover:text-[#F0EDE8] hover:bg-[#1E1E26] transition-colors">
          <MoreHorizontal size={16} />
        </button>
      </td>
    </tr>
  );
}

/* ─── Client Grid Card ─── */
function ClientGridCard({
  customer,
  index,
  onSelect,
}: {
  customer: Customer;
  index: number;
  onSelect: () => void;
}) {
  return (
    <div
      className={cn(
        'bg-[#141419] border border-[#2A2A35] rounded-2xl p-6 transition-all duration-300 cursor-pointer',
        'hover:border-[rgba(212,168,83,0.3)] hover:-translate-y-1 hover:shadow-gold-sm'
      )}
      onClick={onSelect}
      style={{ animation: `fadeUp 0.5s ease ${index * 0.08}s both` }}
    >
      {/* Avatar + Type */}
      <div className="flex items-start justify-between mb-4">
        <div className="relative">
          <div
            className="w-14 h-14 rounded-full flex items-center justify-center"
            style={{ backgroundColor: customer.avatarColor }}
          >
            <span className="text-lg font-bold text-[#0A0A0F]">{customer.initials}</span>
          </div>
          <div
            className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-[#141419]"
            style={{ backgroundColor: customerTypeConfig[customer.type]?.color }}
          />
        </div>
        <TypeBadge type={customer.type} />
      </div>

      {/* Name */}
      <h3 className="text-lg font-semibold text-[#F0EDE8] mb-1">{customer.name}</h3>
      <p className="text-xs text-[#8A8A96] mb-0.5">{customer.email}</p>
      <p className="text-xs text-[#5A5A66] mb-4">{customer.phone}</p>

      {/* Divider */}
      <div className="border-t border-[#2A2A35] my-4" />

      {/* Stats */}
      <div className="flex items-center gap-4 mb-4">
        <span className="text-xs text-[#8A8A96]">
          <span className="text-[#D4A853] font-mono font-semibold">{customer.rides}</span> rides
        </span>
        <span className="text-xs text-[#8A8A96]">
          <span className="text-[#D4A853] font-mono font-semibold">
            ${customer.totalSpent.toLocaleString()}
          </span>{' '}
          spent
        </span>
      </div>

      {/* Tags */}
      <div className="flex flex-wrap gap-1 mb-4">
        {customer.tags.map((tag) => (
          <TagPill key={tag} tag={tag} />
        ))}
      </div>

      {/* View Profile */}
      <button className="flex items-center gap-1 text-sm text-[#D4A853] hover:text-[#E8C87A] transition-colors mt-auto">
        View Profile
        <ChevronRight size={14} />
      </button>
    </div>
  );
}

/* ─── Main CRM Page ─── */
export default function DashboardCRM() {
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState('All Clients');
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list');
  const [selectedClient, setSelectedClient] = useState<Customer | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [clientList, setClientList] = useState<Customer[]>(customers);

  const filtered = useMemo(() => {
    let data = [...clientList];

    if (typeFilter !== 'All Clients') {
      data = data.filter((c) => c.type === typeFilter.toLowerCase());
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      data = data.filter(
        (c) =>
          c.name.toLowerCase().includes(q) ||
          c.email.toLowerCase().includes(q) ||
          c.phone.includes(q)
      );
    }

    return data;
  }, [clientList, typeFilter, searchQuery]);

  const handleAddClient = (client: Customer) => {
    setClientList((prev) => [client, ...prev]);
  };

  const handleUpdateNotes = (id: string, notes: Note[]) => {
    setClientList((prev) =>
      prev.map((c) => (c.id === id ? { ...c, notes } : c))
    );
    // Also update selected client if open
    if (selectedClient?.id === id) {
      setSelectedClient({ ...selectedClient, notes });
    }
  };

  return (
    <DashboardLayout>
      <style>{`
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeRow {
          from { opacity: 0; transform: translateX(-15px); }
          to { opacity: 1; transform: translateX(0); }
        }
      `}</style>

      {/* Header */}
      <div
        className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-6"
        style={{ animation: 'fadeUp 0.4s cubic-bezier(0,0,0.2,1) 0s both' }}
      >
        <div>
          <h1 className="text-4xl font-bold text-[#F0EDE8]">Customer CRM</h1>
          <p className="text-base text-[#8A8A96] mt-1">
            Manage your client relationships and track every interaction.
          </p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-full text-sm font-semibold text-[#0A0A0F] bg-[#D4A853] hover:scale-[1.02] hover:shadow-[0_4px_24px_rgba(212,168,83,0.3)] transition-all"
        >
          <UserPlus size={14} />
          Add Client
        </button>
      </div>

      {/* Stats Bar */}
      <div
        className="grid grid-cols-2 lg:grid-cols-4 gap-5 mb-6"
        style={{ animation: 'fadeUp 0.4s cubic-bezier(0,0,0.2,1) 0.1s both' }}
      >
        {crmStats.map((stat, i) => {
          const Icon = statIcons[stat.icon] || Users;
          return (
            <div
              key={stat.label}
              className="bg-[#141419] border border-[#2A2A35] rounded-xl p-4"
              style={{ animation: `fadeUp 0.5s ease ${i * 0.1}s both` }}
            >
              <div className="flex items-center gap-2 mb-2">
                <div
                  className="w-7 h-7 rounded-lg flex items-center justify-center"
                  style={{ backgroundColor: `${stat.color}1A` }}
                >
                  <Icon size={15} style={{ color: stat.color }} />
                </div>
                <span className="text-xs text-[#5A5A66]">{stat.label}</span>
              </div>
              <p className="font-mono text-xl font-bold text-[#F0EDE8]">{stat.value}</p>
            </div>
          );
        })}
      </div>

      {/* Toolbar */}
      <div
        className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-4"
        style={{ animation: 'fadeUp 0.3s ease 0.2s both' }}
      >
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#5A5A66]" />
            <input
              type="text"
              placeholder="Search clients by name, email, or phone..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full sm:w-[300px] h-10 pl-10 pr-4 rounded-lg bg-[#1E1E26] border border-[#2A2A35] text-sm text-[#F0EDE8] placeholder-[#5A5A66] focus:outline-none focus:border-[#D4A853] focus:ring-[3px] focus:ring-[rgba(212,168,83,0.15)] transition-all"
            />
          </div>
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="h-10 px-4 rounded-lg bg-[#1E1E26] border border-[#2A2A35] text-sm text-[#F0EDE8] focus:outline-none focus:border-[#D4A853] transition-all appearance-none cursor-pointer"
          >
            {filterOptions.map((o) => (
              <option key={o} value={o}>
                {o}
              </option>
            ))}
          </select>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setViewMode('list')}
            className={cn(
              'p-2.5 rounded-lg transition-colors',
              viewMode === 'list'
                ? 'text-[#D4A853] bg-[#1E1E26]'
                : 'text-[#5A5A66] hover:text-[#F0EDE8] hover:bg-[#1E1E26]'
            )}
          >
            <LayoutList size={18} />
          </button>
          <button
            onClick={() => setViewMode('grid')}
            className={cn(
              'p-2.5 rounded-lg transition-colors',
              viewMode === 'grid'
                ? 'text-[#D4A853] bg-[#1E1E26]'
                : 'text-[#5A5A66] hover:text-[#F0EDE8] hover:bg-[#1E1E26]'
            )}
          >
            <LayoutGrid size={18} />
          </button>
        </div>
      </div>

      {/* List View */}
      {viewMode === 'list' && (
        <div className="bg-[#141419] border border-[#2A2A35] rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-[#141419]">
                  <th className="px-5 py-3.5 text-left text-[11px] font-semibold text-[#8A8A96] uppercase tracking-[0.05em]">
                    Name
                  </th>
                  <th className="px-5 py-3.5 text-left text-[11px] font-semibold text-[#8A8A96] uppercase tracking-[0.05em]">
                    Type
                  </th>
                  <th className="px-5 py-3.5 text-left text-[11px] font-semibold text-[#8A8A96] uppercase tracking-[0.05em]">
                    Contact
                  </th>
                  <th className="px-5 py-3.5 text-left text-[11px] font-semibold text-[#8A8A96] uppercase tracking-[0.05em]">
                    Total Spent
                  </th>
                  <th className="px-5 py-3.5 text-left text-[11px] font-semibold text-[#8A8A96] uppercase tracking-[0.05em]">
                    Rides
                  </th>
                  <th className="px-5 py-3.5 text-left text-[11px] font-semibold text-[#8A8A96] uppercase tracking-[0.05em]">
                    Last Ride
                  </th>
                  <th className="px-5 py-3.5 text-left text-[11px] font-semibold text-[#8A8A96] uppercase tracking-[0.05em]">
                    Tags
                  </th>
                  <th className="px-5 py-3.5 w-10" />
                </tr>
              </thead>
              <tbody>
                {filtered.map((customer, i) => (
                  <ClientTableRow
                    key={customer.id}
                    customer={customer}
                    index={i}
                    onSelect={() => setSelectedClient(customer)}
                  />
                ))}
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={8} className="px-5 py-12 text-center text-sm text-[#5A5A66]">
                      No clients found matching your criteria.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Grid View */}
      {viewMode === 'grid' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
          {filtered.map((customer, i) => (
            <ClientGridCard
              key={customer.id}
              customer={customer}
              index={i}
              onSelect={() => setSelectedClient(customer)}
            />
          ))}
          {filtered.length === 0 && (
            <div className="col-span-full py-12 text-center text-sm text-[#5A5A66]">
              No clients found matching your criteria.
            </div>
          )}
        </div>
      )}

      {/* Detail Drawer */}
      {selectedClient && (
        <ClientDetailDrawer
          customer={selectedClient}
          onClose={() => setSelectedClient(null)}
          onUpdateNotes={handleUpdateNotes}
        />
      )}

      {/* Add Client Modal */}
      {showAddModal && (
        <AddClientModal onClose={() => setShowAddModal(false)} onAdd={handleAddClient} />
      )}
    </DashboardLayout>
  );
}
