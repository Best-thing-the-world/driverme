import { useState } from 'react'
import {
  Wallet,
  Calendar,
  Clock,
  CreditCard,
  Car,
  Receipt,
  Heart,
  CheckCircle,
  ChevronDown,
  Download,
  ArrowUpRight,
  LineChartIcon,
  BarChart3,
} from 'lucide-react'
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts'

/* ------------------------------------------------------------------ */
/*  Types                                                               */
/* ------------------------------------------------------------------ */

interface Transaction {
  id: string
  date: string
  description: string
  type: 'booking' | 'payout' | 'fee' | 'tip'
  amount: number
  status: 'completed' | 'pending' | 'processed'
}

interface MonthlyData {
  month: string
  revenue: number
  rides: number
  avgPerRide: number
  payout: number | null
  status: 'Paid' | 'Pending'
}

/* ------------------------------------------------------------------ */
/*  Mock Data                                                           */
/* ------------------------------------------------------------------ */

const chartData = [
  { month: 'Jan', revenue: 580 },
  { month: 'Feb', revenue: 720 },
  { month: 'Mar', revenue: 1240 },
  { month: 'Apr', revenue: 1180 },
  { month: 'May', revenue: 1450 },
  { month: 'Jun', revenue: 1680 },
  { month: 'Jul', revenue: 1520 },
  { month: 'Aug', revenue: 1890 },
  { month: 'Sep', revenue: 1340 },
  { month: 'Oct', revenue: 1560 },
  { month: 'Nov', revenue: 1780 },
  { month: 'Dec', revenue: 2100 },
]

const monthlyBreakdown: MonthlyData[] = [
  { month: 'March 2025', revenue: 3280, rides: 24, avgPerRide: 137, payout: null, status: 'Pending' },
  { month: 'February 2025', revenue: 2840, rides: 21, avgPerRide: 135, payout: 2840, status: 'Paid' },
  { month: 'January 2025', revenue: 2450, rides: 19, avgPerRide: 129, payout: 2450, status: 'Paid' },
  { month: 'December 2024', revenue: 2100, rides: 18, avgPerRide: 117, payout: 2100, status: 'Paid' },
  { month: 'November 2024', revenue: 1780, rides: 16, avgPerRide: 111, payout: 1780, status: 'Paid' },
]

const transactions: Transaction[] = [
  { id: '1', date: 'Mar 12', description: 'Corporate Event — Thomas R.', type: 'booking', amount: 360, status: 'completed' },
  { id: '2', date: 'Mar 12', description: 'Platform Fee (2.9%)', type: 'fee', amount: -10.44, status: 'completed' },
  { id: '3', date: 'Mar 11', description: 'Hourly Charter — Nancy P.', type: 'booking', amount: 475, status: 'completed' },
  { id: '4', date: 'Mar 11', description: 'Platform Fee', type: 'fee', amount: -13.78, status: 'completed' },
  { id: '5', date: 'Mar 10', description: 'Airport Transfer — James L.', type: 'booking', amount: 85, status: 'completed' },
  { id: '6', date: 'Mar 10', description: 'Tip from James L.', type: 'tip', amount: 20, status: 'completed' },
  { id: '7', date: 'Mar 9', description: 'Payout — Feb 2025', type: 'payout', amount: -2840, status: 'processed' },
]

const payoutHistory = [
  { amount: 2840, date: 'Feb 28' },
  { amount: 2450, date: 'Jan 31' },
  { amount: 2100, date: 'Dec 31' },
]

/* ------------------------------------------------------------------ */
/*  Custom Chart Tooltip                                                */
/* ------------------------------------------------------------------ */

function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ value: number }>; label?: string }) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-[#1E1E26] border border-[#2A2A35] rounded-lg px-4 py-3 shadow-elevated">
      <p className="text-xs text-[#5A5A66] mb-1">{label}</p>
      <p className="text-sm font-semibold text-[#F0EDE8]">${payload[0].value.toLocaleString()}</p>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/*  KPI Card                                                            */
/* ------------------------------------------------------------------ */

function KpiCard({
  label,
  value,
  change,
  icon: Icon,
  highlight = false,
}: {
  label: string
  value: string
  change?: string
  icon: React.ComponentType<{ size?: number; className?: string }>
  highlight?: boolean
}) {
  return (
    <div
      className={[
        'rounded-xl border p-6 transition-all duration-300 hover:-translate-y-1',
        highlight
          ? 'bg-[#141419] border-[#D4A853] shadow-gold-sm'
          : 'bg-[#141419] border-[#2A2A35] hover:border-[rgba(212,168,83,0.3)]',
      ].join(' ')}
    >
      <div className="flex items-start justify-between">
        <div className="space-y-3">
          <p className="text-sm text-[#8A8A96]">{label}</p>
          <p className="font-mono text-[32px] font-bold text-[#F0EDE8] leading-none tracking-tight">{value}</p>
          {change && (
            <div className="flex items-center gap-1">
              <ArrowUpRight size={14} className="text-[#22C55E]" />
              <span className="text-xs font-medium text-[#22C55E]">{change}</span>
            </div>
          )}
        </div>
        <div className="w-11 h-11 rounded-xl bg-[#D4A853]/10 flex items-center justify-center">
          <Icon size={22} className="text-[#D4A853]" />
        </div>
      </div>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/*  Transaction Type Icon                                               */
/* ------------------------------------------------------------------ */

function TransactionTypeIcon({ type }: { type: Transaction['type'] }) {
  const config = {
    booking: { icon: Car, bg: 'bg-[#22C55E]/10', color: 'text-[#22C55E]' },
    fee: { icon: Receipt, bg: 'bg-[#EF4444]/10', color: 'text-[#EF4444]' },
    tip: { icon: Heart, bg: 'bg-[#D4A853]/10', color: 'text-[#D4A853]' },
    payout: { icon: CreditCard, bg: 'bg-[#3B82F6]/10', color: 'text-[#3B82F6]' },
  }
  const { icon: Icon, bg, color } = config[type]
  return (
    <div className={['w-9 h-9 rounded-full flex items-center justify-center', bg].join(' ')}>
      <Icon size={16} className={color} />
    </div>
  )
}

/* ------------------------------------------------------------------ */
/*  Main Page Component                                                 */
/* ------------------------------------------------------------------ */

export default function DashboardEarnings() {
  const [chartType, setChartType] = useState<'area' | 'bar'>('area')
  const [period, setPeriod] = useState('1Y')

  const periods = ['7D', '30D', '3M', '1Y', 'All']

  const filteredChartData =
    period === '7D'
      ? chartData.slice(-1)
      : period === '30D'
      ? chartData.slice(-2)
      : period === '3M'
      ? chartData.slice(-3)
      : chartData

  return (
    <div className="min-h-full">
      {/* Page header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-[42px] font-bold text-[#F0EDE8] leading-tight tracking-tight">Earnings</h1>
          <p className="text-base text-[#8A8A96] mt-1">Track your revenue, payouts, and financial growth.</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold text-[#F0EDE8] border border-[#2A2A35] hover:bg-[#1E1E26] transition-all">
            <Download size={16} /> Export CSV
          </button>
          <button className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold text-[#0A0A0F] bg-gold-shine hover:scale-[1.02] hover:shadow-[0_4px_24px_rgba(212,168,83,0.3)] transition-all duration-200">
            Request Payout
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5 mb-8">
        <KpiCard label="Total Revenue (YTD)" value="$12,450" change="↑ 23%" icon={Wallet} />
        <KpiCard label="This Month" value="$3,280" change="↑ 8%" icon={Calendar} />
        <KpiCard label="Pending Payout" value="$1,240" icon={Clock} highlight />
        <KpiCard label="Total Payouts" value="$11,210" change="↑ 18%" icon={CreditCard} />
      </div>

      {/* Revenue Chart */}
      <div className="bg-[#141419] border border-[#2A2A35] rounded-xl p-6 mb-8">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-semibold text-[#F0EDE8]">Revenue Trend</h3>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1 bg-[#0D0D12] rounded-lg p-1">
              {periods.map((p) => (
                <button
                  key={p}
                  onClick={() => setPeriod(p)}
                  className={[
                    'px-3 py-1.5 rounded-md text-xs font-medium transition-all',
                    period === p
                      ? 'bg-[#D4A853] text-[#0A0A0F]'
                      : 'text-[#8A8A96] hover:text-[#F0EDE8]',
                  ].join(' ')}
                >
                  {p}
                </button>
              ))}
            </div>
            <div className="flex items-center bg-[#0D0D12] rounded-lg p-1">
              <button
                onClick={() => setChartType('area')}
                className={[
                  'p-1.5 rounded-md transition-all',
                  chartType === 'area' ? 'bg-[#2A2A35] text-[#D4A853]' : 'text-[#5A5A66] hover:text-[#8A8A96]',
                ].join(' ')}
              >
                <LineChartIcon size={16} />
              </button>
              <button
                onClick={() => setChartType('bar')}
                className={[
                  'p-1.5 rounded-md transition-all',
                  chartType === 'bar' ? 'bg-[#2A2A35] text-[#D4A853]' : 'text-[#5A5A66] hover:text-[#8A8A96]',
                ].join(' ')}
              >
                <BarChart3 size={16} />
              </button>
            </div>
          </div>
        </div>

        <ResponsiveContainer width="100%" height={320}>
          {chartType === 'area' ? (
            <AreaChart data={filteredChartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="goldArea" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#D4A853" stopOpacity={0.2} />
                  <stop offset="100%" stopColor="#D4A853" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(42,42,53,0.5)" vertical={false} />
              <XAxis dataKey="month" tick={{ fill: '#5A5A66', fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis
                tick={{ fill: '#5A5A66', fontSize: 12 }}
                axisLine={false}
                tickLine={false}
                tickFormatter={(v: number) => `$${v}`}
              />
              <Tooltip content={<CustomTooltip />} />
              <Area
                type="monotone"
                dataKey="revenue"
                stroke="#D4A853"
                strokeWidth={2}
                fill="url(#goldArea)"
              />
            </AreaChart>
          ) : (
            <BarChart data={filteredChartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(42,42,53,0.5)" vertical={false} />
              <XAxis dataKey="month" tick={{ fill: '#5A5A66', fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis
                tick={{ fill: '#5A5A66', fontSize: 12 }}
                axisLine={false}
                tickLine={false}
                tickFormatter={(v: number) => `$${v}`}
              />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="revenue" fill="#D4A853" radius={[4, 4, 0, 0]} />
            </BarChart>
          )}
        </ResponsiveContainer>
      </div>

      {/* Two-column layout: Monthly breakdown + Payout info */}
      <div className="grid grid-cols-1 xl:grid-cols-[55%_45%] gap-6">
        {/* Monthly Breakdown Table */}
        <div className="bg-[#141419] border border-[#2A2A35] rounded-xl overflow-hidden">
          <div className="px-6 py-5 border-b border-[#2A2A35]">
            <h4 className="text-lg font-semibold text-[#F0EDE8]">Monthly Breakdown</h4>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-[#141419]">
                  <th className="text-left px-5 py-3 text-[11px] font-semibold text-[#8A8A96] uppercase tracking-[0.05em]">Month</th>
                  <th className="text-right px-5 py-3 text-[11px] font-semibold text-[#8A8A96] uppercase tracking-[0.05em]">Revenue</th>
                  <th className="text-right px-5 py-3 text-[11px] font-semibold text-[#8A8A96] uppercase tracking-[0.05em]">Rides</th>
                  <th className="text-right px-5 py-3 text-[11px] font-semibold text-[#8A8A96] uppercase tracking-[0.05em]">Avg/Ride</th>
                  <th className="text-right px-5 py-3 text-[11px] font-semibold text-[#8A8A96] uppercase tracking-[0.05em]">Payout</th>
                  <th className="text-right px-5 py-3 text-[11px] font-semibold text-[#8A8A96] uppercase tracking-[0.05em]">Status</th>
                </tr>
              </thead>
              <tbody>
                {monthlyBreakdown.map((row, i) => (
                  <tr
                    key={row.month}
                    className={[
                      'border-t border-[#2A2A35] transition-colors hover:bg-[#1A1A22]',
                      i === 0 ? 'bg-[#1A1A22]/50' : '',
                    ].join(' ')}
                  >
                    <td className="px-5 py-4 text-sm text-[#F0EDE8] font-medium">{row.month}</td>
                    <td className="px-5 py-4 text-sm text-[#F0EDE8] font-mono text-right">${row.revenue.toLocaleString()}</td>
                    <td className="px-5 py-4 text-sm text-[#8A8A96] text-right">{row.rides}</td>
                    <td className="px-5 py-4 text-sm text-[#8A8A96] font-mono text-right">${row.avgPerRide}</td>
                    <td className="px-5 py-4 text-sm text-[#8A8A96] font-mono text-right">
                      {row.payout ? `$${row.payout.toLocaleString()}` : '—'}
                    </td>
                    <td className="px-5 py-4 text-right">
                      {row.status === 'Paid' ? (
                        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-[#22C55E]">
                          <CheckCircle size={13} /> Paid
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-[#F59E0B]">
                          <Clock size={13} /> Pending
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Payout Info Card */}
        <div className="bg-[#141419] border border-[#2A2A35] rounded-xl p-6">
          <h4 className="text-lg font-semibold text-[#F0EDE8] mb-5">Payout Information</h4>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <CreditCard size={18} className="text-[#8A8A96]" />
                <div>
                  <p className="text-sm text-[#F0EDE8]">Bank Account •••• 4521</p>
                  <p className="text-xs text-[#5A5A66]">Payout Method</p>
                </div>
              </div>
              <button className="text-xs text-[#D4A853] hover:underline">Edit</button>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Calendar size={18} className="text-[#8A8A96]" />
                <div>
                  <p className="text-sm text-[#F0EDE8]">Every 2 weeks (auto)</p>
                  <p className="text-xs text-[#5A5A66]">Payout Schedule</p>
                </div>
              </div>
              <button className="text-xs text-[#D4A853] hover:underline">Edit</button>
            </div>

            <div className="border-t border-[#2A2A35] pt-4 space-y-3">
              <div className="flex items-center gap-3">
                <CheckCircle size={18} className="text-[#22C55E]" />
                <div>
                  <p className="text-sm text-[#22C55E]">$2,840.00 on Feb 28, 2025</p>
                  <p className="text-xs text-[#5A5A66]">Last Payout</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Clock size={18} className="text-[#D4A853]" />
                <div>
                  <p className="text-sm text-[#D4A853]">$1,240.00 estimated Mar 15, 2025</p>
                  <p className="text-xs text-[#5A5A66]">Next Payout</p>
                </div>
              </div>
            </div>

            {/* Payout history */}
            <div className="border-t border-[#2A2A35] pt-4">
              <p className="text-xs font-semibold text-[#8A8A96] uppercase tracking-[0.05em] mb-3">Recent Payouts</p>
              <div className="space-y-2.5">
                {payoutHistory.map((p) => (
                  <div key={p.date} className="flex items-center justify-between">
                    <span className="inline-flex items-center gap-2 text-sm text-[#F0EDE8]">
                      <CheckCircle size={14} className="text-[#22C55E]" />
                      ${p.amount.toLocaleString()}
                    </span>
                    <span className="text-xs text-[#5A5A66]">{p.date}</span>
                  </div>
                ))}
              </div>
              <button className="mt-4 text-sm text-[#D4A853] hover:underline inline-flex items-center gap-1">
                View Full History →
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Transactions */}
      <div className="bg-[#141419] border border-[#2A2A35] rounded-xl mt-6 overflow-hidden">
        <div className="flex items-center justify-between px-6 py-5 border-b border-[#2A2A35]">
          <h4 className="text-lg font-semibold text-[#F0EDE8]">Recent Transactions</h4>
          <div className="flex items-center gap-3">
            <button className="text-sm text-[#D4A853] hover:underline">View All →</button>
            <button className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#1E1E26] border border-[#2A2A35] text-xs font-medium text-[#8A8A96] hover:bg-[#252530] transition-colors">
              All <ChevronDown size={13} />
            </button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-[#141419]">
                <th className="text-left px-5 py-3 text-[11px] font-semibold text-[#8A8A96] uppercase tracking-[0.05em]">Date</th>
                <th className="text-left px-5 py-3 text-[11px] font-semibold text-[#8A8A96] uppercase tracking-[0.05em]">Description</th>
                <th className="text-left px-5 py-3 text-[11px] font-semibold text-[#8A8A96] uppercase tracking-[0.05em]">Type</th>
                <th className="text-right px-5 py-3 text-[11px] font-semibold text-[#8A8A96] uppercase tracking-[0.05em]">Amount</th>
                <th className="text-right px-5 py-3 text-[11px] font-semibold text-[#8A8A96] uppercase tracking-[0.05em]">Status</th>
              </tr>
            </thead>
            <tbody>
              {transactions.map((tx) => (
                <tr
                  key={tx.id}
                  className="border-t border-[#2A2A35] transition-colors hover:bg-[#1A1A22]"
                >
                  <td className="px-5 py-4 text-sm text-[#8A8A96]">{tx.date}</td>
                  <td className="px-5 py-4 text-sm text-[#F0EDE8]">{tx.description}</td>
                  <td className="px-5 py-4">
                    <div className="flex items-center gap-2">
                      <TransactionTypeIcon type={tx.type} />
                      <span className="text-sm text-[#8A8A96] capitalize">{tx.type.replace('_', ' ')}</span>
                    </div>
                  </td>
                  <td className={[
                    'px-5 py-4 text-sm font-mono font-semibold text-right',
                    tx.amount > 0 ? 'text-[#22C55E]' : 'text-[#EF4444]',
                  ].join(' ')}>
                    {tx.amount > 0 ? '+' : ''}${Math.abs(tx.amount).toFixed(2)}
                  </td>
                  <td className="px-5 py-4 text-right">
                    <span className={[
                      'inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium',
                      tx.status === 'completed' ? 'bg-[#22C55E]/10 text-[#22C55E]' :
                      tx.status === 'processed' ? 'bg-[#3B82F6]/10 text-[#3B82F6]' :
                      'bg-[#F59E0B]/10 text-[#F59E0B]',
                    ].join(' ')}>
                      {tx.status.charAt(0).toUpperCase() + tx.status.slice(1)}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Tax Summary */}
      <div className="mt-6 max-w-[480px]">
        <div className="bg-[#141419] border border-[#2A2A35] rounded-xl p-6">
          <h4 className="text-lg font-semibold text-[#F0EDE8] mb-5">Tax Summary (2025)</h4>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-[#8A8A96]">Total Revenue</span>
              <span className="font-mono text-lg font-semibold text-[#D4A853]">$12,450.00</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-[#8A8A96]">Platform Fees</span>
              <span className="font-mono text-lg font-semibold text-[#EF4444]">-$361.05</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-[#8A8A96]">Tips Received</span>
              <span className="font-mono text-lg font-semibold text-[#22C55E]">+$340.00</span>
            </div>
            <div className="border-t border-[#2A2A35] pt-4 flex items-center justify-between">
              <span className="text-sm font-semibold text-[#F0EDE8]">Net Earnings</span>
              <span className="font-mono text-2xl font-bold text-[#D4A853] underline underline-offset-4 decoration-[#D4A853]/40">
                $12,428.95
              </span>
            </div>
          </div>

          <p className="text-xs text-[#5A5A66] mt-4">
            Export detailed report for your accountant.
          </p>
          <button className="mt-3 inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium text-[#D4A853] border border-[#D4A853] hover:bg-[rgba(212,168,83,0.1)] transition-all">
            <Download size={14} /> Download Tax Report
          </button>
        </div>
      </div>
    </div>
  )
}
