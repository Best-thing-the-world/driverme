import { useState, useCallback } from 'react'
import {
  Camera,
  Monitor,
  Smartphone,
  GripVertical,
  X,
  Plus,
  Check,
  ExternalLink,
  Copy,
  Star,
  MapPin,
  Phone,
  Mail,
  Clock,
  Shield,
} from 'lucide-react'
import { Switch } from '@/components/ui/switch'

/* ------------------------------------------------------------------ */
/*  Types                                                               */
/* ------------------------------------------------------------------ */

interface StorefrontData {
  displayName: string
  tagline: string
  bio: string
  city: string
  phone: string
  email: string
  avatar: string
  usps: string[]
  vehicle: {
    make: string
    model: string
    year: string
    color: string
    capacity: string
    luggage: string
    features: string[]
    showInsurance: boolean
    insuranceProvider: string
    coverage: string
  }
  theme: {
    accentColor: string
    layout: 'standard' | 'hero'
    showRatings: boolean
    showRideCount: boolean
    showMemberSince: boolean
    showResponseTime: boolean
    allowPhoneBooking: boolean
  }
  settings: {
    url: string
    visible: boolean
    acceptBookings: boolean
    autoAccept: boolean
    minNotice: string
    cancellationPolicy: string
  }
  services: Array<{
    id: string
    name: string
    price: number
    unit: string
    active: boolean
  }>
}

/* ------------------------------------------------------------------ */
/*  Color presets                                                       */
/* ------------------------------------------------------------------ */

const accentColors = [
  '#D4A853', '#C0C0C0', '#B76E79', '#3B82F6', '#10B981',
  '#8B5CF6', '#EF4444', '#F97316', '#14B8A6', '#6366F1',
  '#EC4899', '#custom',
]

/* ------------------------------------------------------------------ */
/*  Initial Data                                                        */
/* ------------------------------------------------------------------ */

const initialData: StorefrontData = {
  displayName: 'Marcus Johnson',
  tagline: "Executive Chauffeur | Atlanta's Premium Black Car Service",
  bio: "With over 15 years of professional driving experience, I provide executive-level transportation services in the Atlanta area. My commitment to punctuality, discretion, and premium service has earned me a loyal clientele of business executives and discerning travelers. Every ride is tailored to your needs — from airport transfers with flight tracking to full-day corporate charters.",
  city: 'Atlanta, GA',
  phone: '(404) 555-0147',
  email: 'marcus@driverlink.co',
  avatar: '',
  usps: [
    '15+ years professional experience',
    'Flight tracking for all airport pickups',
    'Immaculately maintained luxury vehicle',
    'Discreet, professional service',
    'Corporate accounts welcome',
    '24/7 availability on request',
  ],
  vehicle: {
    make: 'Cadillac',
    model: 'Escalade',
    year: '2022',
    color: 'Black',
    capacity: '6',
    luggage: '4',
    features: ['Leather Interior', 'Climate Control', 'WiFi Hotspot', 'Phone Chargers', 'Bottled Water', 'Premium Sound System', 'Tinted Windows'],
    showInsurance: true,
    insuranceProvider: 'Commercial Auto Insurance',
    coverage: '$1.5M liability',
  },
  theme: {
    accentColor: '#D4A853',
    layout: 'standard',
    showRatings: true,
    showRideCount: true,
    showMemberSince: true,
    showResponseTime: true,
    allowPhoneBooking: false,
  },
  settings: {
    url: 'driverlink.co/drivers/marcus-johnson',
    visible: true,
    acceptBookings: true,
    autoAccept: false,
    minNotice: '6 hours',
    cancellationPolicy: 'Free cancellation up to 24 hours before the scheduled ride. Cancellations within 24 hours may incur a 50% fee.',
  },
  services: [
    { id: '1', name: 'Airport Transfer', price: 85, unit: 'ride', active: true },
    { id: '2', name: 'Hourly Charter', price: 95, unit: 'hour', active: true },
    { id: '3', name: 'Point-to-Point', price: 65, unit: 'ride', active: true },
    { id: '4', name: 'VIP Black Service', price: 150, unit: 'hour', active: true },
    { id: '5', name: 'Corporate Event', price: 120, unit: 'hour', active: true },
  ],
}

/* ------------------------------------------------------------------ */
/*  Live Preview Component                                              */
/* ------------------------------------------------------------------ */

function LivePreview({ data, device }: { data: StorefrontData; device: 'desktop' | 'mobile' }) {
  const accent = data.theme.accentColor
  const isHero = data.theme.layout === 'hero'

  const previewWidth = device === 'mobile' ? '375px' : '100%'

  return (
    <div className="flex justify-center">
      <div
        className="w-full bg-[#0A0A0F] border border-[#2A2A35] rounded-2xl overflow-hidden shadow-[0_20px_60px_rgba(0,0,0,0.5)] transition-all duration-300"
        style={{ maxWidth: previewWidth }}
      >
        {/* Preview header */}
        <div className="h-1.5 bg-[#2A2A35] mx-auto rounded-b-sm" style={{ width: device === 'mobile' ? '40%' : '20%' }} />

        <div className="overflow-y-auto" style={{ maxHeight: 'calc(100vh - 200px)' }}>
          {/* Hero section */}
          {isHero ? (
            <div className="relative h-48 bg-[#141419] flex items-end p-6 overflow-hidden">
              <div className="absolute inset-0 bg-[#1E1E26]" />
              <div className="relative flex items-center gap-4">
                <div
                  className="w-20 h-20 rounded-full border-[3px] flex items-center justify-center bg-[#1E1E26] text-2xl font-bold"
                  style={{ borderColor: accent }}
                >
                  {data.displayName.split(' ').map((n) => n[0]).join('')}
                </div>
                <div>
                  <h2 className="text-xl font-bold text-[#F0EDE8]">{data.displayName}</h2>
                  <p className="text-sm text-[#8A8A96] mt-0.5">{data.tagline}</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center pt-8 pb-6 px-6">
              <div
                className="w-24 h-24 rounded-full border-[3px] flex items-center justify-center bg-[#1E1E26] text-3xl font-bold mb-4"
                style={{ borderColor: accent }}
              >
                {data.displayName.split(' ').map((n) => n[0]).join('')}
              </div>
              <h2 className="text-xl font-bold text-[#F0EDE8] text-center">{data.displayName}</h2>
              <p className="text-sm text-[#8A8A96] mt-1 text-center">{data.tagline}</p>
              {data.theme.showRatings && (
                <div className="flex items-center gap-1.5 mt-2">
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <Star key={s} size={14} className={s <= 5 ? 'text-[#D4A853] fill-[#D4A853]' : 'text-[#2A2A35]'} />
                    ))}
                  </div>
                  <span className="text-xs text-[#8A8A96]">5.0 (48 reviews)</span>
                </div>
              )}
            </div>
          )}

          {/* Location & meta */}
          <div className="flex items-center justify-center gap-4 px-6 pb-4 text-xs text-[#8A8A96]">
            <span className="inline-flex items-center gap-1">
              <MapPin size={12} style={{ color: accent }} /> {data.city}
            </span>
            {data.theme.showMemberSince && (
              <span>Member since 2021</span>
            )}
            {data.theme.showResponseTime && (
              <span className="inline-flex items-center gap-1">
                <Clock size={12} /> &lt; 1 hour
              </span>
            )}
          </div>

          {/* USPs */}
          <div className="px-6 py-4">
            <div className="flex flex-wrap gap-2">
              {data.usps.map((usp, i) => (
                <span
                  key={i}
                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-medium border"
                  style={{ borderColor: `${accent}40`, color: accent, backgroundColor: `${accent}10` }}
                >
                  <Check size={10} /> {usp}
                </span>
              ))}
            </div>
          </div>

          {/* Bio */}
          <div className="px-6 py-4 border-t border-[#2A2A35]">
            <p className="text-sm text-[#8A8A96] leading-relaxed">{data.bio}</p>
          </div>

          {/* Vehicle */}
          <div className="px-6 py-5 border-t border-[#2A2A35]">
            <h3 className="text-base font-semibold text-[#F0EDE8] mb-3">Vehicle</h3>
            <div className="rounded-xl bg-[#141419] border border-[#2A2A35] p-4">
              <div className="h-32 bg-[#1E1E26] rounded-lg mb-3 flex items-center justify-center">
                <Car size={48} style={{ color: `${accent}40` }} />
              </div>
              <p className="text-sm font-semibold text-[#F0EDE8]">
                {data.vehicle.year} {data.vehicle.make} {data.vehicle.model}
              </p>
              <p className="text-xs text-[#8A8A96] mt-1">{data.vehicle.color} • {data.vehicle.capacity} passengers • {data.vehicle.luggage} bags</p>
              <div className="flex flex-wrap gap-1.5 mt-3">
                {data.vehicle.features.map((f, i) => (
                  <span key={i} className="px-2 py-1 rounded-md bg-[#1E1E26] text-[11px] text-[#8A8A96] border border-[#2A2A35]">{f}</span>
                ))}
              </div>
              {data.vehicle.showInsurance && (
                <div className="flex items-center gap-2 mt-3 pt-3 border-t border-[#2A2A35]">
                  <Shield size={14} style={{ color: accent }} />
                  <span className="text-xs text-[#8A8A96]">{data.vehicle.insuranceProvider} • {data.vehicle.coverage}</span>
                </div>
              )}
            </div>
          </div>

          {/* Services */}
          <div className="px-6 py-5 border-t border-[#2A2A35]">
            <h3 className="text-base font-semibold text-[#F0EDE8] mb-3">Services</h3>
            <div className="space-y-2.5">
              {data.services.filter((s) => s.active).map((service) => (
                <div key={service.id} className="flex items-center justify-between p-3.5 rounded-xl bg-[#141419] border border-[#2A2A35]">
                  <span className="text-sm font-medium text-[#F0EDE8]">{service.name}</span>
                  <span className="font-mono text-sm font-semibold" style={{ color: accent }}>
                    ${service.price}/{service.unit}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Contact */}
          <div className="px-6 py-5 border-t border-[#2A2A35]">
            <h3 className="text-base font-semibold text-[#F0EDE8] mb-3">Contact</h3>
            <div className="space-y-2.5">
              <div className="flex items-center gap-3 text-sm text-[#8A8A96]">
                <MapPin size={16} style={{ color: accent }} /> {data.city}
              </div>
              <div className="flex items-center gap-3 text-sm text-[#8A8A96]">
                <Mail size={16} style={{ color: accent }} /> {data.email}
              </div>
              {data.theme.allowPhoneBooking && (
                <div className="flex items-center gap-3 text-sm text-[#8A8A96]">
                  <Phone size={16} style={{ color: accent }} /> {data.phone}
                </div>
              )}
            </div>
          </div>

          {/* Book CTA */}
          <div className="p-6 border-t border-[#2A2A35]">
            <button
              className="w-full py-3.5 rounded-full text-sm font-semibold text-[#0A0A0F] transition-all hover:scale-[1.02]"
              style={{ backgroundColor: accent }}
            >
              Book a Ride
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

/* Simple car icon wrapper for preview */
function Car({ size, className, style }: { size?: number; className?: string; style?: React.CSSProperties }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className} style={style}>
      <path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2" />
      <circle cx="7" cy="17" r="2" />
      <circle cx="17" cy="17" r="2" />
    </svg>
  )
}

/* ------------------------------------------------------------------ */
/*  Main Page Component                                                 */
/* ------------------------------------------------------------------ */

export default function DashboardStorefront() {
  const [data, setData] = useState<StorefrontData>(initialData)
  const [activeTab, setActiveTab] = useState<'profile' | 'vehicle' | 'services' | 'theme' | 'settings'>('profile')
  const [previewDevice, setPreviewDevice] = useState<'desktop' | 'mobile'>('desktop')

  const updateField = useCallback(<K extends keyof StorefrontData>(field: K, value: StorefrontData[K]) => {
    setData((prev) => ({ ...prev, [field]: value }))
  }, [])

  const updateVehicle = useCallback((field: keyof StorefrontData['vehicle'], value: string | boolean | string[]) => {
    setData((prev) => ({ ...prev, vehicle: { ...prev.vehicle, [field]: value } }))
  }, [])

  const updateTheme = useCallback((field: keyof StorefrontData['theme'], value: string | boolean) => {
    setData((prev) => ({ ...prev, theme: { ...prev.theme, [field]: value } }))
  }, [])

  const updateSettings = useCallback((field: keyof StorefrontData['settings'], value: string | boolean) => {
    setData((prev) => ({ ...prev, settings: { ...prev.settings, [field]: value } }))
  }, [])

  const addUsp = () => {
    if (data.usps.length >= 8) return
    setData((prev) => ({ ...prev, usps: [...prev.usps, ''] }))
  }

  const removeUsp = (index: number) => {
    setData((prev) => ({ ...prev, usps: prev.usps.filter((_, i) => i !== index) }))
  }

  const updateUsp = (index: number, value: string) => {
    setData((prev) => ({
      ...prev,
      usps: prev.usps.map((u, i) => (i === index ? value : u)),
    }))
  }

  const addFeature = (feature: string) => {
    if (!data.vehicle.features.includes(feature)) {
      setData((prev) => ({ ...prev, vehicle: { ...prev.vehicle, features: [...prev.vehicle.features, feature] } }))
    }
  }

  const removeFeature = (index: number) => {
    setData((prev) => ({
      ...prev,
      vehicle: { ...prev.vehicle, features: prev.vehicle.features.filter((_, i) => i !== index) },
    }))
  }

  const toggleService = (id: string) => {
    setData((prev) => ({
      ...prev,
      services: prev.services.map((s) => s.id === id ? { ...s, active: !s.active } : s),
    }))
  }

  /* ---------- Shared input styles ---------- */
  const inputClass = 'w-full px-4 py-3 rounded-lg bg-[#1E1E26] border border-[#2A2A35] text-[#F0EDE8] placeholder:text-[#5A5A66] focus:border-[#D4A853] focus:outline-none focus:ring-[3px] focus:ring-[rgba(212,168,83,0.15)] transition-all text-sm'
  const labelClass = 'block text-sm font-medium text-[#8A8A96] mb-1.5'
  const sectionClass = 'space-y-4'
  const sectionTitle = 'text-base font-semibold text-[#F0EDE8] mb-3'

  /* ---------- Tabs ---------- */
  const tabs: { key: typeof activeTab; label: string }[] = [
    { key: 'profile', label: 'Profile' },
    { key: 'vehicle', label: 'Vehicle' },
    { key: 'services', label: 'Services' },
    { key: 'theme', label: 'Theme' },
    { key: 'settings', label: 'Settings' },
  ]

  return (
    <div className="min-h-full">
      {/* Page header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-[42px] font-bold text-[#F0EDE8] leading-tight tracking-tight">Storefront Editor</h1>
          <p className="text-base text-[#8A8A96] mt-1">Customize how clients see your booking page. Changes publish instantly.</p>
        </div>
        <button className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold text-[#D4A853] border border-[#D4A853] hover:bg-[rgba(212,168,83,0.1)] transition-all">
          <ExternalLink size={16} /> View Live Page
        </button>
      </div>

      {/* Split-screen layout */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Left: Editor */}
        <div className="min-h-0">
          {/* Tabs */}
          <div className="sticky top-0 z-10 bg-[#0A0A0F] border-b border-[#2A2A35] mb-6">
            <div className="flex gap-1 overflow-x-auto">
              {tabs.map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key)}
                  className={[
                    'px-5 py-3 text-sm font-medium border-b-2 transition-all whitespace-nowrap',
                    activeTab === tab.key
                      ? 'text-[#D4A853] border-[#D4A853]'
                      : 'text-[#8A8A96] border-transparent hover:text-[#F0EDE8]',
                  ].join(' ')}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Tab content */}
          <div className="px-1 pb-10">
            {/* Profile Tab */}
            {activeTab === 'profile' && (
              <div className="space-y-8">
                {/* Photo */}
                <div>
                  <h4 className={sectionTitle}>Profile Photo</h4>
                  <div className="flex items-center gap-4">
                    <div
                      className="w-[120px] h-[120px] rounded-full border-[3px] border-[#D4A853] flex items-center justify-center bg-[#1E1E26] text-3xl font-bold text-[#D4A853] flex-shrink-0"
                    >
                      {data.displayName.split(' ').map((n) => n[0]).join('')}
                    </div>
                    <div className="flex-1 border-2 border-dashed border-[#2A2A35] hover:border-[#D4A853] rounded-xl p-8 text-center transition-colors cursor-pointer hover:bg-[rgba(212,168,83,0.05)]">
                      <Camera size={32} className="mx-auto text-[#5A5A66] mb-2" />
                      <p className="text-sm text-[#8A8A96]">Drop photo here or click to upload</p>
                      <p className="text-xs text-[#5A5A66] mt-1">JPG, PNG. Max 5MB.</p>
                    </div>
                  </div>
                </div>

                {/* Basic Info */}
                <div>
                  <h4 className={sectionTitle}>Basic Information</h4>
                  <div className={sectionClass}>
                    <div>
                      <label className={labelClass}>Display Name</label>
                      <input
                        type="text"
                        value={data.displayName}
                        onChange={(e) => updateField('displayName', e.target.value)}
                        className={inputClass}
                      />
                    </div>
                    <div>
                      <label className={labelClass}>Tagline</label>
                      <input
                        type="text"
                        value={data.tagline}
                        onChange={(e) => updateField('tagline', e.target.value)}
                        maxLength={80}
                        className={inputClass}
                      />
                      <p className="text-right text-xs text-[#5A5A66] mt-1">{data.tagline.length}/80</p>
                    </div>
                    <div>
                      <label className={labelClass}>Bio</label>
                      <textarea
                        value={data.bio}
                        onChange={(e) => updateField('bio', e.target.value)}
                        rows={6}
                        maxLength={500}
                        placeholder="Tell clients about your experience, approach, and what makes your service special..."
                        className={inputClass + ' resize-none'}
                      />
                      <p className="text-right text-xs text-[#5A5A66] mt-1">{data.bio.length}/500</p>
                    </div>
                  </div>
                </div>

                {/* Contact */}
                <div>
                  <h4 className={sectionTitle}>Contact & Location</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className={labelClass}>City</label>
                      <input type="text" value={data.city} onChange={(e) => updateField('city', e.target.value)} className={inputClass} />
                    </div>
                    <div>
                      <label className={labelClass}>Phone</label>
                      <input type="text" value={data.phone} onChange={(e) => updateField('phone', e.target.value)} className={inputClass} />
                    </div>
                    <div>
                      <label className={labelClass}>Email</label>
                      <input type="email" value={data.email} onChange={(e) => updateField('email', e.target.value)} className={inputClass} />
                    </div>
                  </div>
                </div>

                {/* USPs */}
                <div>
                  <h4 className={sectionTitle}>Unique Selling Points</h4>
                  <p className="text-xs text-[#8A8A96] mb-3">Highlight what makes you stand out.</p>
                  <div className="space-y-2">
                    {data.usps.map((usp, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <GripVertical size={16} className="text-[#5A5A66] flex-shrink-0 cursor-grab" />
                        <input
                          type="text"
                          value={usp}
                          onChange={(e) => updateUsp(i, e.target.value)}
                          className={inputClass}
                        />
                        <button
                          onClick={() => removeUsp(i)}
                          className="p-1.5 rounded text-[#5A5A66] hover:text-[#EF4444] transition-colors flex-shrink-0"
                        >
                          <X size={16} />
                        </button>
                      </div>
                    ))}
                  </div>
                  {data.usps.length < 8 && (
                    <button
                      onClick={addUsp}
                      className="mt-3 inline-flex items-center gap-1.5 text-sm text-[#D4A853] hover:underline"
                    >
                      <Plus size={14} /> Add USP
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Vehicle Tab */}
            {activeTab === 'vehicle' && (
              <div className="space-y-8">
                {/* Vehicle Photo */}
                <div>
                  <h4 className={sectionTitle}>Vehicle Photo</h4>
                  <div className="border-2 border-dashed border-[#2A2A35] hover:border-[#D4A853] rounded-xl p-8 text-center transition-colors cursor-pointer hover:bg-[rgba(212,168,83,0.05)]">
                    <Camera size={32} className="mx-auto text-[#5A5A66] mb-2" />
                    <p className="text-sm text-[#8A8A96]">Drop vehicle photo here or click to upload</p>
                    <p className="text-xs text-[#5A5A66] mt-1">JPG, PNG. 16:9 recommended.</p>
                  </div>
                </div>

                {/* Vehicle Details */}
                <div>
                  <h4 className={sectionTitle}>Vehicle Details</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div><label className={labelClass}>Make</label><input type="text" value={data.vehicle.make} onChange={(e) => updateVehicle('make', e.target.value)} className={inputClass} /></div>
                    <div><label className={labelClass}>Model</label><input type="text" value={data.vehicle.model} onChange={(e) => updateVehicle('model', e.target.value)} className={inputClass} /></div>
                    <div><label className={labelClass}>Year</label><input type="number" value={data.vehicle.year} onChange={(e) => updateVehicle('year', e.target.value)} className={inputClass} /></div>
                    <div><label className={labelClass}>Color</label><input type="text" value={data.vehicle.color} onChange={(e) => updateVehicle('color', e.target.value)} className={inputClass} /></div>
                    <div>
                      <label className={labelClass}>Passenger Capacity</label>
                      <select value={data.vehicle.capacity} onChange={(e) => updateVehicle('capacity', e.target.value)} className={inputClass}>
                        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((n) => (
                          <option key={n} value={String(n)} className="bg-[#1E1E26]">{n}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className={labelClass}>Luggage Capacity</label>
                      <select value={data.vehicle.luggage} onChange={(e) => updateVehicle('luggage', e.target.value)} className={inputClass}>
                        {[0, 1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
                          <option key={n} value={String(n)} className="bg-[#1E1E26]">{n}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>

                {/* Features */}
                <div>
                  <h4 className={sectionTitle}>Vehicle Features & Amenities</h4>
                  <div className="flex flex-wrap gap-2 mb-3">
                    {data.vehicle.features.map((f, i) => (
                      <span key={i} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#1E1E26] border border-[#2A2A35] text-xs text-[#F0EDE8]">
                        {f}
                        <button onClick={() => removeFeature(i)} className="text-[#5A5A66] hover:text-[#EF4444]"><X size={12} /></button>
                      </span>
                    ))}
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {['Sunroof', 'Rear Entertainment', 'Refreshments', 'Newspapers', 'Child Seat Available'].map((s) => (
                      <button
                        key={s}
                        onClick={() => addFeature(s)}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full text-xs text-[#8A8A96] border border-dashed border-[#2A2A35] hover:border-[#D4A853] hover:text-[#D4A853] transition-colors"
                      >
                        <Plus size={11} /> {s}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Insurance */}
                <div>
                  <h4 className={sectionTitle}>Insurance</h4>
                  <div className="space-y-4">
                    <label className="flex items-center gap-3 cursor-pointer">
                      <Switch
                        checked={data.vehicle.showInsurance}
                        onCheckedChange={(v) => updateVehicle('showInsurance', v)}
                        className="data-[state=checked]:bg-[#D4A853]"
                      />
                      <span className="text-sm text-[#F0EDE8]">Show insurance badge on storefront</span>
                    </label>
                    {data.vehicle.showInsurance && (
                      <div className="grid grid-cols-2 gap-4">
                        <div><label className={labelClass}>Insurance Provider</label><input type="text" value={data.vehicle.insuranceProvider} onChange={(e) => updateVehicle('insuranceProvider', e.target.value)} className={inputClass} /></div>
                        <div><label className={labelClass}>Coverage</label><input type="text" value={data.vehicle.coverage} onChange={(e) => updateVehicle('coverage', e.target.value)} className={inputClass} /></div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Services Tab */}
            {activeTab === 'services' && (
              <div className="space-y-6">
                <div>
                  <h4 className={sectionTitle}>Active Services</h4>
                  <p className="text-xs text-[#8A8A96] mb-3">
                    Quick view of your services. For full editing, visit the{' '}
                    <a href="#/dashboard/services" className="text-[#D4A853] hover:underline">Services page</a>.
                  </p>
                  <div className="space-y-2.5">
                    {data.services.map((service) => (
                      <div
                        key={service.id}
                        className="flex items-center justify-between p-4 rounded-xl bg-[#141419] border border-[#2A2A35]"
                      >
                        <div>
                          <p className="text-sm font-medium text-[#F0EDE8]">{service.name}</p>
                          <p className="font-mono text-sm" style={{ color: data.theme.accentColor }}>
                            ${service.price}/{service.unit}
                          </p>
                        </div>
                        <Switch
                          checked={service.active}
                          onCheckedChange={() => toggleService(service.id)}
                          className="data-[state=checked]:bg-[#D4A853]"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Theme Tab */}
            {activeTab === 'theme' && (
              <div className="space-y-8">
                {/* Accent Color */}
                <div>
                  <h4 className={sectionTitle}>Accent Color</h4>
                  <div className="flex flex-wrap gap-3">
                    {accentColors.map((color) => {
                      const isSelected = data.theme.accentColor === color
                      const isCustom = color === '#custom'
                      return (
                        <button
                          key={color}
                          onClick={() => isCustom || updateTheme('accentColor', color)}
                          className={[
                            'w-10 h-10 rounded-full border-2 transition-all hover:scale-110 flex items-center justify-center',
                            isSelected ? 'border-[#D4A853]' : 'border-[#2A2A35]',
                          ].join(' ')}
                          style={isCustom ? {} : { backgroundColor: color }}
                          title={isCustom ? 'Custom' : color}
                        >
                          {isCustom ? (
                            <span className="text-xs text-[#8A8A96]">+</span>
                          ) : isSelected ? (
                            <Check size={16} className={color === '#C0C0C0' ? 'text-[#0A0A0F]' : 'text-white'} style={{ textShadow: '0 1px 2px rgba(0,0,0,0.5)' }} />
                          ) : null}
                        </button>
                      )
                    })}
                    {data.theme.accentColor === '#custom' && (
                      <input
                        type="color"
                        value="#D4A853"
                        onChange={(e) => updateTheme('accentColor', e.target.value)}
                        className="w-10 h-10 rounded-full border-2 border-[#D4A853] cursor-pointer"
                      />
                    )}
                  </div>
                </div>

                {/* Layout */}
                <div>
                  <h4 className={sectionTitle}>Storefront Layout</h4>
                  <div className="grid grid-cols-2 gap-4">
                    {(['standard', 'hero'] as const).map((layout) => (
                      <button
                        key={layout}
                        onClick={() => updateTheme('layout', layout)}
                        className={[
                          'p-4 rounded-xl border-2 text-left transition-all hover:border-[#D4A853]/50',
                          data.theme.layout === layout
                            ? 'border-[#D4A853] bg-[rgba(212,168,83,0.05)]'
                            : 'border-[#2A2A35] bg-[#141419]',
                        ].join(' ')}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium text-[#F0EDE8] capitalize">{layout}</span>
                          {data.theme.layout === layout && <Check size={16} className="text-[#D4A853]" />}
                        </div>
                        <p className="text-xs text-[#8A8A96]">
                          {layout === 'standard' ? 'Services below bio' : 'Large photo header with overlay text'}
                        </p>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Display Options */}
                <div>
                  <h4 className={sectionTitle}>Display Options</h4>
                  <div className="space-y-4">
                    {[
                      { key: 'showRatings' as const, label: 'Show ratings and reviews' },
                      { key: 'showRideCount' as const, label: 'Show ride count' },
                      { key: 'showMemberSince' as const, label: 'Show member since date' },
                      { key: 'showResponseTime' as const, label: 'Show response time' },
                      { key: 'allowPhoneBooking' as const, label: 'Allow direct phone booking' },
                    ].map((opt) => (
                      <label key={opt.key} className="flex items-center justify-between cursor-pointer py-1">
                        <span className="text-sm text-[#F0EDE8]">{opt.label}</span>
                        <Switch
                          checked={data.theme[opt.key]}
                          onCheckedChange={(v) => updateTheme(opt.key, v)}
                          className="data-[state=checked]:bg-[#D4A853]"
                        />
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Settings Tab */}
            {activeTab === 'settings' && (
              <div className="space-y-8">
                {/* URL */}
                <div>
                  <h4 className={sectionTitle}>Storefront URL</h4>
                  <div className="flex gap-2">
                    <div className="flex-1 px-4 py-3 rounded-lg bg-[#1E1E26] border border-[#2A2A35] text-sm text-[#8A8A96] flex items-center">
                      {data.settings.url}
                    </div>
                    <button className="px-4 py-3 rounded-lg bg-[#1E1E26] border border-[#2A2A35] text-[#8A8A96] hover:text-[#F0EDE8] hover:border-[#D4A853] transition-all">
                      <Copy size={18} />
                    </button>
                  </div>
                </div>

                {/* Visibility & Booking */}
                <div>
                  <h4 className={sectionTitle}>Visibility & Booking</h4>
                  <div className="space-y-4">
                    <label className="flex items-center justify-between cursor-pointer">
                      <span className="text-sm text-[#F0EDE8]">Storefront is visible to public</span>
                      <Switch
                        checked={data.settings.visible}
                        onCheckedChange={(v) => updateSettings('visible', v)}
                        className="data-[state=checked]:bg-[#D4A853]"
                      />
                    </label>
                    <label className="flex items-center justify-between cursor-pointer">
                      <span className="text-sm text-[#F0EDE8]">Accept new bookings</span>
                      <Switch
                        checked={data.settings.acceptBookings}
                        onCheckedChange={(v) => updateSettings('acceptBookings', v)}
                        className="data-[state=checked]:bg-[#D4A853]"
                      />
                    </label>
                    <label className="flex items-center justify-between cursor-pointer">
                      <span className="text-sm text-[#F0EDE8]">Automatically accept new bookings</span>
                      <Switch
                        checked={data.settings.autoAccept}
                        onCheckedChange={(v) => updateSettings('autoAccept', v)}
                        className="data-[state=checked]:bg-[#D4A853]"
                      />
                    </label>
                  </div>
                </div>

                {/* Minimum Notice */}
                <div>
                  <h4 className={sectionTitle}>Booking Preferences</h4>
                  <div className="space-y-4">
                    <div>
                      <label className={labelClass}>Minimum Notice</label>
                      <select
                        value={data.settings.minNotice}
                        onChange={(e) => updateSettings('minNotice', e.target.value)}
                        className={inputClass}
                      >
                        {['2 hours', '6 hours', '12 hours', '24 hours'].map((opt) => (
                          <option key={opt} value={opt} className="bg-[#1E1E26]">{opt}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className={labelClass}>Cancellation Policy</label>
                      <textarea
                        value={data.settings.cancellationPolicy}
                        onChange={(e) => updateSettings('cancellationPolicy', e.target.value)}
                        rows={4}
                        className={inputClass + ' resize-none'}
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right: Live Preview */}
        <div className="hidden xl:block">
          <div className="sticky top-[80px] max-h-[calc(100vh-100px)] overflow-y-auto">
            {/* Device toggle */}
            <div className="flex items-center justify-center gap-2 mb-4">
              <button
                onClick={() => setPreviewDevice('desktop')}
                className={[
                  'p-2 rounded-lg transition-all',
                  previewDevice === 'desktop' ? 'bg-[#2A2A35] text-[#D4A853]' : 'text-[#5A5A66] hover:text-[#8A8A96]',
                ].join(' ')}
                title="Desktop preview"
              >
                <Monitor size={18} />
              </button>
              <button
                onClick={() => setPreviewDevice('mobile')}
                className={[
                  'p-2 rounded-lg transition-all',
                  previewDevice === 'mobile' ? 'bg-[#2A2A35] text-[#D4A853]' : 'text-[#5A5A66] hover:text-[#8A8A96]',
                ].join(' ')}
                title="Mobile preview"
              >
                <Smartphone size={18} />
              </button>
            </div>

            <LivePreview data={data} device={previewDevice} />
          </div>
        </div>
      </div>
    </div>
  )
}
