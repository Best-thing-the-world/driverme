import { useState } from 'react'
import {
  Plus,
  Pencil,
  Copy,
  Trash2,
  Plane,
  Clock,
  MapPin,
  Briefcase,
  Crown,
  Heart,
  Baby,
  ShoppingBag,
  Wine,
  Camera,
  Stethoscope,
  Car,
  Users,
  Star,
  Home,
  Flag,
  X,
  GripVertical,
  Sparkles,
} from 'lucide-react'
import { Switch } from '@/components/ui/switch'

/* ------------------------------------------------------------------ */
/*  Types                                                               */
/* ------------------------------------------------------------------ */

type FieldType = 'text' | 'select' | 'number' | 'date' | 'time' | 'textarea'

interface ServiceField {
  name: string
  type: FieldType
  label: string
  placeholder?: string
  required: boolean
  options?: string[]
}

interface Service {
  id: string
  name: string
  description: string
  category: string
  basePrice: number
  priceUnit: 'ride' | 'hour' | 'mile'
  duration?: string
  icon: string
  isActive: boolean
  fields: ServiceField[]
}

/* ------------------------------------------------------------------ */
/*  Icon map                                                            */
/* ------------------------------------------------------------------ */

const iconMap: Record<string, React.ComponentType<{ size?: number; className?: string }>> = {
  Plane, Clock, MapPin, Briefcase, Crown, Heart, Baby, ShoppingBag, Wine, Camera,
  Stethoscope, Car, Users, Star, Home, Flag,
}

const allIconNames = Object.keys(iconMap)

/* ------------------------------------------------------------------ */
/*  Mock data                                                           */
/* ------------------------------------------------------------------ */

const initialServices: Service[] = [
  {
    id: '1',
    name: 'Airport Transfer',
    description: 'Door-to-door airport service with flight tracking',
    category: 'airport',
    basePrice: 85,
    priceUnit: 'ride',
    duration: '45-90 min',
    icon: 'Plane',
    isActive: true,
    fields: [
      { name: 'pickupLocation', type: 'text', label: 'Pickup Location', required: true },
      { name: 'dropoffLocation', type: 'text', label: 'Drop-off Location', required: true },
      { name: 'flightNumber', type: 'text', label: 'Flight Number', required: true },
      { name: 'airport', type: 'select', label: 'Airport', required: true, options: ['Hartsfield-Jackson ATL', 'DeKalb-Peachtree PDK'] },
      { name: 'pickupType', type: 'select', label: 'Pickup Type', required: true, options: ['Curbside', 'Meet & Greet Inside'] },
      { name: 'luggageCount', type: 'select', label: 'Luggage Count', required: true, options: ['0', '1', '2', '3', '4', '5', '6', '7', '8'] },
      { name: 'passengers', type: 'select', label: 'Number of Passengers', required: true, options: ['1', '2', '3', '4', '5', '6'] },
      { name: 'specialRequests', type: 'textarea', label: 'Special Requests', required: false },
    ],
  },
  {
    id: '2',
    name: 'Hourly Charter',
    description: 'Dedicated driver for meetings, events, and city tours',
    category: 'hourly',
    basePrice: 95,
    priceUnit: 'hour',
    duration: '2-8 hours',
    icon: 'Clock',
    isActive: true,
    fields: [
      { name: 'pickupLocation', type: 'text', label: 'Pickup Location', required: true },
      { name: 'hours', type: 'select', label: 'Hours', required: true, options: ['2', '3', '4', '5', '6', '7', '8'] },
      { name: 'itineraryNotes', type: 'textarea', label: 'Itinerary Notes', required: false },
    ],
  },
  {
    id: '3',
    name: 'Point-to-Point',
    description: 'Direct transportation between any two locations',
    category: 'point_to_point',
    basePrice: 65,
    priceUnit: 'ride',
    duration: '20-60 min',
    icon: 'MapPin',
    isActive: true,
    fields: [
      { name: 'pickupLocation', type: 'text', label: 'Pickup Location', required: true },
      { name: 'dropoffLocation', type: 'text', label: 'Drop-off Location', required: true },
      { name: 'passengers', type: 'select', label: 'Number of Passengers', required: true, options: ['1', '2', '3', '4', '5', '6'] },
    ],
  },
  {
    id: '4',
    name: 'Corporate Event',
    description: 'Professional transportation for business events',
    category: 'event',
    basePrice: 120,
    priceUnit: 'hour',
    duration: '3-10 hours',
    icon: 'Briefcase',
    isActive: true,
    fields: [
      { name: 'pickupLocation', type: 'text', label: 'Pickup Location', required: true },
      { name: 'companyName', type: 'text', label: 'Company Name', required: true },
      { name: 'eventType', type: 'select', label: 'Event Type', required: true, options: ['Conference', 'Meeting', 'Dinner', 'Team Building', 'Other'] },
      { name: 'passengers', type: 'select', label: 'Number of Passengers', required: true, options: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10'] },
    ],
  },
  {
    id: '5',
    name: 'VIP Black Service',
    description: 'White-glove service for special occasions',
    category: 'vip',
    basePrice: 150,
    priceUnit: 'hour',
    duration: '2-6 hours',
    icon: 'Crown',
    isActive: true,
    fields: [
      { name: 'pickupLocation', type: 'text', label: 'Pickup Location', required: true },
      { name: 'hours', type: 'select', label: 'Hours', required: true, options: ['2', '3', '4', '5', '6'] },
      { name: 'specialRequests', type: 'textarea', label: 'Special Requests', required: false },
    ],
  },
  {
    id: '6',
    name: 'Senior Care Transport',
    description: 'Safe, comfortable, and patient senior care rides',
    category: 'senior',
    basePrice: 55,
    priceUnit: 'ride',
    duration: '30-90 min',
    icon: 'Heart',
    isActive: false,
    fields: [
      { name: 'pickupLocation', type: 'text', label: 'Pickup Location', required: true },
      { name: 'destination', type: 'text', label: 'Destination', required: true },
      { name: 'mobilityAid', type: 'select', label: 'Mobility Aid', required: false, options: ['None', 'Walker', 'Wheelchair', 'Cane'] },
      { name: 'companion', type: 'select', label: 'Traveling with Companion', required: false, options: ['Yes', 'No'] },
    ],
  },
  {
    id: '7',
    name: 'Errands & Appointments',
    description: 'Grocery, pharmacy, and appointment runs',
    category: 'errands',
    basePrice: 45,
    priceUnit: 'hour',
    duration: '1-3 hours',
    icon: 'ShoppingBag',
    isActive: false,
    fields: [
      { name: 'pickupLocation', type: 'text', label: 'Pickup Location', required: true },
      { name: 'errandList', type: 'textarea', label: 'Errand Details', required: true },
    ],
  },
]

const templates = [
  { icon: 'Plane', name: 'Airport Transfer', description: 'Flight tracking, luggage handling' },
  { icon: 'Clock', name: 'Hourly Charter', description: 'Flexible time-based service' },
  { icon: 'Heart', name: 'Senior Transport', description: 'Safe, comfortable senior care rides' },
  { icon: 'Baby', name: 'Child Pickup', description: 'School and activity transportation' },
  { icon: 'ShoppingBag', name: 'Errands', description: 'Grocery, pharmacy, appointments' },
  { icon: 'Wine', name: 'Wine Tour', description: 'Multi-stop vineyard experiences' },
  { icon: 'Camera', name: 'City Tour', description: 'Sightseeing and tourist rides' },
  { icon: 'Stethoscope', name: 'Medical Transport', description: 'NEMT appointments' },
]

const categories = ['Airport', 'Hourly', 'Point-to-Point', 'Event', 'VIP', 'Senior', 'Errands', 'Custom']

const emptyService: Service = {
  id: '',
  name: '',
  description: '',
  category: 'Custom',
  basePrice: 0,
  priceUnit: 'ride',
  duration: '',
  icon: 'Car',
  isActive: false,
  fields: [
    { name: 'pickupLocation', type: 'text', label: 'Pickup Location', required: true },
    { name: 'dropoffLocation', type: 'text', label: 'Drop-off Location', required: true },
  ],
}

/* ------------------------------------------------------------------ */
/*  Service Card Component                                              */
/* ------------------------------------------------------------------ */

function ServiceCard({
  service,
  onToggle,
  onEdit,
  onDuplicate,
  onDelete,
}: {
  service: Service
  onToggle: () => void
  onEdit: () => void
  onDuplicate: () => void
  onDelete: () => void
}) {
  const IconComp = iconMap[service.icon] || Car

  return (
    <div
      className={[
        'rounded-2xl border transition-all duration-300 overflow-hidden group',
        service.isActive
          ? 'bg-[#141419] border-[#2A2A35] hover:border-[rgba(212,168,83,0.3)] hover:shadow-gold-sm hover:-translate-y-1'
          : 'bg-[#141419] border-[#2A2A35] opacity-60 hover:opacity-100',
      ].join(' ')}
    >
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#D4A853]/10 flex items-center justify-center">
            <IconComp size={22} className="text-[#D4A853]" />
          </div>
          <h3 className="text-lg font-semibold text-[#F0EDE8]">{service.name}</h3>
        </div>
        <Switch
          checked={service.isActive}
          onCheckedChange={onToggle}
          className="data-[state=checked]:bg-[#D4A853]"
        />
      </div>

      {/* Description */}
      <p className="px-5 text-sm text-[#8A8A96] leading-relaxed">{service.description}</p>

      {/* Pricing */}
      <div className="flex items-center gap-3 px-5 mt-3">
        <span className="font-mono text-xl font-bold text-[#D4A853]">${service.basePrice}</span>
        <span className="text-xs text-[#5A5A66]">/{service.priceUnit}</span>
        {service.duration && (
          <span className="text-xs text-[#5A5A66]">Typical: {service.duration}</span>
        )}
      </div>

      {/* Fields preview */}
      <div className="px-5 mt-3">
        <p className="text-[11px] font-medium text-[#5A5A66] uppercase tracking-wider mb-2">Booking Fields</p>
        <div className="flex flex-wrap gap-1.5">
          {service.fields.map((field) => (
            <span
              key={field.name}
              className="inline-flex items-center px-2 py-1 rounded-md bg-[#1E1E26] border border-[#2A2A35] text-[11px] text-[#8A8A96]"
            >
              {field.label}
            </span>
          ))}
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2 px-5 py-4 mt-4 border-t border-[#2A2A35]">
        <button
          onClick={onEdit}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium text-[#8A8A96] border border-[#2A2A35] hover:bg-[#1E1E26] hover:text-[#F0EDE8] transition-all"
        >
          <Pencil size={13} /> Edit
        </button>
        <button
          onClick={onDuplicate}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium text-[#8A8A96] border border-[#2A2A35] hover:bg-[#1E1E26] hover:text-[#F0EDE8] transition-all"
        >
          <Copy size={13} /> Duplicate
        </button>
        <button
          onClick={onDelete}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium text-[#8A8A96] border border-[#2A2A35] hover:bg-[#EF4444]/10 hover:text-[#EF4444] hover:border-[#EF4444]/30 transition-all"
        >
          <Trash2 size={13} /> Delete
        </button>
      </div>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/*  Main Page Component                                                 */
/* ------------------------------------------------------------------ */

export default function DashboardServices() {
  const [services, setServices] = useState<Service[]>(initialServices)
  const [modalOpen, setModalOpen] = useState(false)
  const [editingService, setEditingService] = useState<Service | null>(null)
  const [form, setForm] = useState<Service>({ ...emptyService, id: crypto.randomUUID() })

  const activeServices = services.filter((s) => s.isActive)
  const inactiveServices = services.filter((s) => !s.isActive)

  const openNew = () => {
    setEditingService(null)
    setForm({ ...emptyService, id: crypto.randomUUID() })
    setModalOpen(true)
  }

  const openEdit = (service: Service) => {
    setEditingService(service)
    setForm({ ...service })
    setModalOpen(true)
  }

  const saveService = (activate = false) => {
    const toSave = { ...form, isActive: activate || form.isActive }
    if (editingService) {
      setServices((prev) => prev.map((s) => (s.id === editingService.id ? toSave : s)))
    } else {
      setServices((prev) => [...prev, toSave])
    }
    setModalOpen(false)
  }

  const toggleService = (id: string) => {
    setServices((prev) => prev.map((s) => (s.id === id ? { ...s, isActive: !s.isActive } : s)))
  }

  const deleteService = (id: string) => {
    setServices((prev) => prev.filter((s) => s.id !== id))
  }

  const duplicateService = (service: Service) => {
    const copy = { ...service, id: crypto.randomUUID(), name: `${service.name} (Copy)`, isActive: false }
    setServices((prev) => [...prev, copy])
  }

  const useTemplate = (template: typeof templates[0]) => {
    setEditingService(null)
    setForm({
      ...emptyService,
      id: crypto.randomUUID(),
      name: template.name,
      description: template.description,
      icon: template.icon,
    })
    setModalOpen(true)
  }

  const addField = () => {
    const newField: ServiceField = {
      name: `field_${Date.now()}`,
      type: 'text',
      label: 'New Field',
      required: false,
    }
    setForm((prev) => ({ ...prev, fields: [...prev.fields, newField] }))
  }

  const removeField = (index: number) => {
    setForm((prev) => ({ ...prev, fields: prev.fields.filter((_, i) => i !== index) }))
  }

  const updateField = (index: number, updates: Partial<ServiceField>) => {
    setForm((prev) => ({
      ...prev,
      fields: prev.fields.map((f, i) => (i === index ? { ...f, ...updates } : f)),
    }))
  }

  /* ---------- Modal form helpers ---------- */

  const modalField = (label: string, children: React.ReactNode) => (
    <div className="space-y-1.5">
      <label className="text-sm font-medium text-[#8A8A96]">{label}</label>
      {children}
    </div>
  )

  return (
    <div className="min-h-full">
      {/* Page header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-[42px] font-bold text-[#F0EDE8] leading-tight tracking-tight">Services</h1>
          <p className="text-base text-[#8A8A96] mt-1">
            Manage the services you offer to clients. Active services appear on your storefront.
          </p>
        </div>
        <button
          onClick={openNew}
          className="inline-flex items-center gap-2 px-6 py-3 rounded-full text-sm font-semibold text-[#0A0A0F] bg-gold-shine hover:scale-[1.02] hover:shadow-[0_4px_24px_rgba(212,168,83,0.3)] transition-all duration-200"
        >
          <Plus size={18} /> New Service
        </button>
      </div>

      {/* Active services grid */}
      <div>
        <div className="flex items-center gap-3 mb-4">
          <h2 className="text-2xl font-semibold text-[#F0EDE8]">Active Services</h2>
          <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-[#D4A853]/10 text-[#D4A853] text-sm font-bold">
            {activeServices.length}
          </span>
        </div>
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
          {activeServices.map((service) => (
            <ServiceCard
              key={service.id}
              service={service}
              onToggle={() => toggleService(service.id)}
              onEdit={() => openEdit(service)}
              onDuplicate={() => duplicateService(service)}
              onDelete={() => deleteService(service.id)}
            />
          ))}
        </div>
      </div>

      {/* Inactive services */}
      {inactiveServices.length > 0 && (
        <div className="mt-10">
          <div className="flex items-center gap-3 mb-4">
            <h2 className="text-2xl font-semibold text-[#F0EDE8]">Inactive Services</h2>
            <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-[#2A2A35] text-[#8A8A96] text-sm font-bold">
              {inactiveServices.length}
            </span>
          </div>
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
            {inactiveServices.map((service) => (
              <ServiceCard
                key={service.id}
                service={service}
                onToggle={() => toggleService(service.id)}
                onEdit={() => openEdit(service)}
                onDuplicate={() => duplicateService(service)}
                onDelete={() => deleteService(service.id)}
              />
            ))}
          </div>
        </div>
      )}

      {/* Templates section */}
      <div className="mt-12">
        <div className="mb-4">
          <h2 className="text-2xl font-semibold text-[#F0EDE8]">Quick Add from Templates</h2>
          <p className="text-sm text-[#8A8A96] mt-1">Start with a pre-configured service and customize it.</p>
        </div>
        <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-thin">
          {templates.map((template) => {
            const TIcon = iconMap[template.icon] || Car
            return (
              <button
                key={template.name}
                onClick={() => useTemplate(template)}
                className="flex-shrink-0 w-[200px] p-5 rounded-xl bg-[#0D0D12] border border-dashed border-[#2A2A35] hover:border-[#D4A853] hover:bg-[#141419] transition-all duration-200 text-left group"
              >
                <div className="flex flex-col items-center text-center">
                  <TIcon size={28} className="text-[#5A5A66] group-hover:text-[#D4A853] transition-colors" />
                  <h5 className="text-base font-semibold text-[#F0EDE8] mt-2">{template.name}</h5>
                  <p className="text-xs text-[#5A5A66] mt-1 line-clamp-2">{template.description}</p>
                  <span className="text-sm text-[#D4A853] mt-3 inline-flex items-center gap-1">
                    <Sparkles size={13} /> Use Template
                  </span>
                </div>
              </button>
            )
          })}
        </div>
      </div>

      {/* Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setModalOpen(false)} />
          <div className="relative w-full max-w-[640px] max-h-[85vh] overflow-y-auto bg-[#141419] border border-[#2A2A35] rounded-2xl shadow-elevated">
            {/* Modal header */}
            <div className="flex items-center justify-between px-6 py-5 border-b border-[#2A2A35]">
              <h2 className="text-xl font-semibold text-[#F0EDE8]">
                {editingService ? 'Edit Service' : 'New Service'}
              </h2>
              <button
                onClick={() => setModalOpen(false)}
                className="p-2 rounded-lg text-[#5A5A66] hover:text-[#F0EDE8] hover:bg-[#1E1E26] transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            {/* Modal body */}
            <div className="px-6 py-6 space-y-6">
              {/* Basic Info */}
              <div>
                <h3 className="text-lg font-semibold text-[#F0EDE8] mb-4">Basic Information</h3>
                <div className="space-y-4">
                  {modalField('Service Name', (
                    <input
                      type="text"
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      placeholder="e.g., Airport Transfer"
                      className="w-full px-4 py-3 rounded-lg bg-[#1E1E26] border border-[#2A2A35] text-[#F0EDE8] placeholder:text-[#5A5A66] focus:border-[#D4A853] focus:outline-none focus:ring-[3px] focus:ring-[rgba(212,168,83,0.15)] transition-all text-sm"
                    />
                  ))}
                  {modalField('Category', (
                    <select
                      value={form.category}
                      onChange={(e) => setForm({ ...form, category: e.target.value })}
                      className="w-full px-4 py-3 rounded-lg bg-[#1E1E26] border border-[#2A2A35] text-[#F0EDE8] focus:border-[#D4A853] focus:outline-none focus:ring-[3px] focus:ring-[rgba(212,168,83,0.15)] transition-all text-sm appearance-none"
                    >
                      {categories.map((c) => (
                        <option key={c} value={c.toLowerCase()} className="bg-[#1E1E26]">{c}</option>
                      ))}
                    </select>
                  ))}
                  {modalField('Description', (
                    <textarea
                      value={form.description}
                      onChange={(e) => setForm({ ...form, description: e.target.value })}
                      placeholder="Describe this service to your clients..."
                      rows={3}
                      className="w-full px-4 py-3 rounded-lg bg-[#1E1E26] border border-[#2A2A35] text-[#F0EDE8] placeholder:text-[#5A5A66] focus:border-[#D4A853] focus:outline-none focus:ring-[3px] focus:ring-[rgba(212,168,83,0.15)] transition-all text-sm resize-none"
                    />
                  ))}
                  {/* Icon picker */}
                  {modalField('Icon', (
                    <div className="grid grid-cols-8 gap-2">
                      {allIconNames.map((name) => {
                        const Ic = iconMap[name]
                        const selected = form.icon === name
                        return (
                          <button
                            key={name}
                            onClick={() => setForm({ ...form, icon: name })}
                            className={[
                              'w-10 h-10 rounded-lg flex items-center justify-center transition-all',
                              selected
                                ? 'bg-[#D4A853] text-[#0A0A0F] border-2 border-[#D4A853]'
                                : 'bg-[#1E1E26] text-[#8A8A96] border border-[#2A2A35] hover:border-[#D4A853]/50',
                            ].join(' ')}
                            title={name}
                          >
                            <Ic size={18} />
                          </button>
                        )
                      })}
                    </div>
                  ))}
                </div>
              </div>

              {/* Pricing */}
              <div className="border-t border-[#2A2A35] pt-6">
                <h3 className="text-lg font-semibold text-[#F0EDE8] mb-4">Pricing</h3>
                <div className="grid grid-cols-2 gap-4">
                  {modalField('Price Type', (
                    <select
                      value={form.priceUnit}
                      onChange={(e) => setForm({ ...form, priceUnit: e.target.value as 'ride' | 'hour' | 'mile' })}
                      className="w-full px-4 py-3 rounded-lg bg-[#1E1E26] border border-[#2A2A35] text-[#F0EDE8] focus:border-[#D4A853] focus:outline-none text-sm appearance-none"
                    >
                      <option value="ride" className="bg-[#1E1E26]">Fixed Price (per ride)</option>
                      <option value="hour" className="bg-[#1E1E26]">Per Hour</option>
                      <option value="mile" className="bg-[#1E1E26]">Per Mile</option>
                    </select>
                  ))}
                  {modalField('Base Price ($)', (
                    <input
                      type="number"
                      value={form.basePrice || ''}
                      onChange={(e) => setForm({ ...form, basePrice: Number(e.target.value) })}
                      placeholder="85"
                      className="w-full px-4 py-3 rounded-lg bg-[#1E1E26] border border-[#2A2A35] text-[#F0EDE8] placeholder:text-[#5A5A66] focus:border-[#D4A853] focus:outline-none focus:ring-[3px] focus:ring-[rgba(212,168,83,0.15)] transition-all text-sm"
                    />
                  ))}
                </div>
                <div className="mt-4">
                  {modalField('Duration Estimate', (
                    <input
                      type="text"
                      value={form.duration || ''}
                      onChange={(e) => setForm({ ...form, duration: e.target.value })}
                      placeholder="e.g., 45-90 minutes"
                      className="w-full px-4 py-3 rounded-lg bg-[#1E1E26] border border-[#2A2A35] text-[#F0EDE8] placeholder:text-[#5A5A66] focus:border-[#D4A853] focus:outline-none focus:ring-[3px] focus:ring-[rgba(212,168,83,0.15)] transition-all text-sm"
                    />
                  ))}
                </div>
              </div>

              {/* Booking Fields */}
              <div className="border-t border-[#2A2A35] pt-6">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-[#F0EDE8]">Custom Booking Fields</h3>
                    <p className="text-sm text-[#8A8A96] mt-0.5">Add fields that clients fill out when booking this service.</p>
                  </div>
                </div>

                <div className="space-y-2">
                  {form.fields.map((field, index) => (
                    <div
                      key={index}
                      className="flex items-center gap-3 px-4 py-3 rounded-lg bg-[#1E1E26] border border-[#2A2A35]"
                    >
                      <GripVertical size={16} className="text-[#5A5A66] flex-shrink-0 cursor-grab" />
                      <div className="flex-1 min-w-0">
                        <input
                          type="text"
                          value={field.label}
                          onChange={(e) => updateField(index, { label: e.target.value })}
                          className="w-full bg-transparent text-sm text-[#F0EDE8] focus:outline-none"
                        />
                      </div>
                      <select
                        value={field.type}
                        onChange={(e) => updateField(index, { type: e.target.value as FieldType })}
                        className="text-xs bg-[#141419] border border-[#2A2A35] rounded px-2 py-1 text-[#8A8A96] focus:outline-none"
                      >
                        <option value="text">Text</option>
                        <option value="textarea">Textarea</option>
                        <option value="number">Number</option>
                        <option value="select">Select</option>
                        <option value="date">Date</option>
                        <option value="time">Time</option>
                      </select>
                      <label className="flex items-center gap-1.5 text-xs text-[#8A8A96] cursor-pointer flex-shrink-0">
                        <input
                          type="checkbox"
                          checked={field.required}
                          onChange={(e) => updateField(index, { required: e.target.checked })}
                          className="accent-[#D4A853]"
                        />
                        Req
                      </label>
                      <button
                        onClick={() => removeField(index)}
                        className="p-1 rounded text-[#5A5A66] hover:text-[#EF4444] transition-colors flex-shrink-0"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  ))}
                </div>

                <button
                  onClick={addField}
                  className="mt-3 inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium text-[#D4A853] border border-[#D4A853] hover:bg-[rgba(212,168,83,0.1)] transition-all"
                >
                  <Plus size={14} /> Add Field
                </button>
              </div>
            </div>

            {/* Modal actions */}
            <div className="flex items-center justify-end gap-3 px-6 py-5 border-t border-[#2A2A35]">
              <button
                onClick={() => setModalOpen(false)}
                className="px-5 py-2.5 rounded-full text-sm font-semibold text-[#F0EDE8] border border-[#2A2A35] hover:bg-[#1E1E26] transition-all"
              >
                Cancel
              </button>
              <button
                onClick={() => saveService(false)}
                className="px-5 py-2.5 rounded-full text-sm font-semibold text-[#D4A853] border border-[#D4A853] hover:bg-[rgba(212,168,83,0.1)] transition-all"
              >
                Save Service
              </button>
              <button
                onClick={() => saveService(true)}
                className="px-5 py-2.5 rounded-full text-sm font-semibold text-[#0A0A0F] bg-gold-shine hover:scale-[1.02] transition-all"
              >
                Save & Activate
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
