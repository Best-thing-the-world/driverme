import { useState, useMemo } from 'react';
import {
  Download,
  Plus,
  Search,
  LayoutList,
  LayoutGrid,
  MoreHorizontal,
  Eye,
  Check,
  X,
  RotateCcw,
  MessageSquare,
  ChevronLeft,
  ChevronRight,
  MapPin,
  Calendar,
  Clock,
  Phone,
  ArrowUpDown,
  Plane,
  Briefcase,
  Star,
  Heart,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import DashboardLayout from '@/components/DashboardLayout';
import { bookings, statusConfig, type Booking } from '@/lib/dashboard-data';

const statusTabs = [
  { key: 'all', label: 'All', count: bookings.length },
  { key: 'new', label: 'New', count: bookings.filter((b) => b.status === 'new').length },
  { key: 'accepted', label: 'Accepted', count: bookings.filter((b) => b.status === 'accepted').length },
  { key: 'confirmed', label: 'Confirmed', count: bookings.filter((b) => b.status === 'confirmed').length },
  { key: 'in_progress', label: 'In Progress', count: bookings.filter((b) => b.status === 'in_progress').length },
  { key: 'completed', label: 'Completed', count: bookings.filter((b) => b.status === 'completed').length },
  { key: 'canceled', label: 'Canceled', count: bookings.filter((b) => b.status === 'canceled').length },
];

const serviceIconMap: Record<string, React.ElementType> = {
  Plane,
  Clock,
  MapPin,
  Briefcase,
  Star,
  Heart,
};

type SortField = 'id' | 'customer' | 'service' | 'pickup' | 'date' | 'price' | 'status';
type SortDir = 'asc' | 'desc';

/* ─── Status Pill ─── */
function StatusPill({ status }: { status: string }) {
  const config = statusConfig[status];
  if (!config) return null;
  return (
    <span
      className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium"
      style={{ backgroundColor: config.bg, color: config.color }}
    >
      {config.label}
    </span>
  );
}

/* ─── Booking Detail Modal ─── */
function BookingDetailModal({
  booking,
  onClose,
}: {
  booking: Booking;
  onClose: () => void;
}) {
  const _status = statusConfig[booking.status];
  const ServiceIcon = serviceIconMap[booking.service.icon] || MapPin;

  const actionButton = () => {
    switch (booking.status) {
      case 'new':
        return { label: 'Accept Booking', variant: 'primary' as const };
      case 'accepted':
        return { label: 'Confirm Booking', variant: 'primary' as const };
      case 'confirmed':
        return { label: 'Start Ride', variant: 'primary' as const };
      case 'in_progress':
        return { label: 'Complete Ride', variant: 'primary' as const };
      default:
        return null;
    }
  };

  const primaryAction = actionButton();

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      {/* Overlay */}
      <div className="absolute inset-0 bg-black/60 backdrop-blur-[4px]" />

      {/* Modal */}
      <div
        className="relative bg-[#141419] border border-[#2A2A35] rounded-2xl w-full max-w-[640px] max-h-[90vh] overflow-y-auto shadow-2xl"
        style={{ animation: 'slideUp 0.4s cubic-bezier(0.34, 1.56, 0.64, 1)' }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between p-6 border-b border-[#2A2A35]">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <span className="font-mono text-lg font-bold text-[#D4A853]">{booking.id}</span>
              <StatusPill status={booking.status} />
            </div>
            <p className="text-sm text-[#8A8A96]">
              Created {new Date(booking.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-[#5A5A66] hover:text-[#F0EDE8] hover:bg-[#1E1E26] transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Service & Price */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[rgba(212,168,83,0.1)] flex items-center justify-center">
              <ServiceIcon size={20} className="text-[#D4A853]" />
            </div>
            <div className="flex-1">
              <p className="text-base font-semibold text-[#F0EDE8]">{booking.service.name}</p>
              <p className="text-sm text-[#8A8A96]">
                {booking.passengers} passenger{booking.passengers > 1 ? 's' : ''}
                {booking.luggage ? ` · ${booking.luggage} luggage` : ''}
              </p>
            </div>
            <div className="text-right">
              <p className="font-mono text-xl font-bold text-[#D4A853]">${booking.price.toFixed(2)}</p>
              {booking.gratuity && (
                <p className="text-xs text-[#8A8A96]">+ ${booking.gratuity.toFixed(2)} gratuity</p>
              )}
            </div>
          </div>

          {/* Divider */}
          <div className="border-t border-[#2A2A35]" />

          {/* Date & Time */}
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-start gap-3">
              <Calendar size={16} className="text-[#8A8A96] mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-xs text-[#5A5A66] mb-0.5">Date</p>
                <p className="text-sm text-[#F0EDE8]">{booking.pickup.date}</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Clock size={16} className="text-[#8A8A96] mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-xs text-[#5A5A66] mb-0.5">Time</p>
                <p className="text-sm text-[#F0EDE8]">{booking.pickup.time}</p>
              </div>
            </div>
          </div>

          {/* Locations */}
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <MapPin size={16} className="text-[#22C55E] mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-xs text-[#5A5A66] mb-0.5">Pickup</p>
                <p className="text-sm text-[#F0EDE8]">{booking.pickup.location}</p>
              </div>
            </div>
            {booking.dropoff && (
              <div className="flex items-start gap-3">
                <MapPin size={16} className="text-[#EF4444] mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-xs text-[#5A5A66] mb-0.5">Dropoff</p>
                  <p className="text-sm text-[#F0EDE8]">{booking.dropoff.location}</p>
                </div>
              </div>
            )}
          </div>

          {/* Divider */}
          <div className="border-t border-[#2A2A35]" />

          {/* Client Info */}
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-[#D4A853] flex items-center justify-center">
              <span className="text-sm font-semibold text-[#0A0A0F]">
                {booking.customer.name.split(' ').map((n) => n[0]).join('')}
              </span>
            </div>
            <div className="flex-1">
              <p className="text-base font-semibold text-[#F0EDE8]">{booking.customer.name}</p>
              <p className="text-sm text-[#8A8A96]">{booking.customer.email}</p>
              <p className="text-sm text-[#8A8A96]">{booking.customer.phone}</p>
            </div>
            <button className="p-2 rounded-lg text-[#5A5A66] hover:text-[#D4A853] hover:bg-[#1E1E26] transition-colors">
              <Phone size={16} />
            </button>
          </div>

          {/* Company & Event */}
          {(booking.company || booking.eventType) && (
            <div className="bg-[#1E1E26] rounded-lg p-4 space-y-2">
              {booking.company && (
                <div className="flex items-center gap-2">
                  <Briefcase size={14} className="text-[#8A8A96]" />
                  <span className="text-sm text-[#F0EDE8]">{booking.company}</span>
                </div>
              )}
              {booking.eventType && (
                <div className="flex items-center gap-2">
                  <Star size={14} className="text-[#8A8A96]" />
                  <span className="text-sm text-[#8A8A96]">{booking.eventType}</span>
                </div>
              )}
            </div>
          )}

          {/* Notes */}
          {booking.notes && (
            <div className="bg-[rgba(245,158,11,0.05)] border border-[rgba(245,158,11,0.15)] rounded-lg p-4">
              <p className="text-xs text-[#F59E0B] font-medium mb-1">Notes</p>
              <p className="text-sm text-[#F0EDE8]">{booking.notes}</p>
            </div>
          )}

          {/* Price Breakdown */}
          <div className="bg-[#1E1E26] rounded-lg p-4 space-y-2">
            <p className="text-xs text-[#5A5A66] font-medium uppercase tracking-wider">Price Breakdown</p>
            <div className="flex justify-between text-sm">
              <span className="text-[#8A8A96]">Base fare</span>
              <span className="text-[#F0EDE8] font-mono">${booking.price.toFixed(2)}</span>
            </div>
            {booking.gratuity && (
              <div className="flex justify-between text-sm">
                <span className="text-[#8A8A96]">Gratuity</span>
                <span className="text-[#F0EDE8] font-mono">${booking.gratuity.toFixed(2)}</span>
              </div>
            )}
            <div className="border-t border-[#2A2A35] pt-2 flex justify-between">
              <span className="text-sm font-semibold text-[#F0EDE8]">Total</span>
              <span className="font-mono font-bold text-[#D4A853]">
                ${(booking.price + (booking.gratuity || 0)).toFixed(2)}
              </span>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-3 p-6 border-t border-[#2A2A35]">
          {primaryAction && (
            <button className="px-5 py-2.5 rounded-full text-sm font-semibold text-[#0A0A0F] bg-[#D4A853] hover:scale-[1.02] hover:shadow-[0_4px_24px_rgba(212,168,83,0.3)] transition-all duration-200">
              {primaryAction.label}
            </button>
          )}
          {booking.status !== 'completed' && booking.status !== 'canceled' && (
            <button className="px-5 py-2.5 rounded-full text-sm font-semibold text-[#EF4444] border border-[#EF4444] hover:bg-[rgba(239,68,68,0.1)] transition-all duration-200">
              Cancel Booking
            </button>
          )}
          <button className="px-5 py-2.5 rounded-full text-sm font-semibold text-[#F0EDE8] border border-[#2A2A35] hover:bg-[#1E1E26] transition-all duration-200 ml-auto">
            Message Client
          </button>
        </div>
      </div>

      <style>{`
        @keyframes slideUp {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}

/* ─── Actions Dropdown ─── */
function ActionsDropdown({
  booking,
  onView,
}: {
  booking: Booking;
  onView: () => void;
}) {
  const [open, setOpen] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={(e) => {
          e.stopPropagation();
          setOpen(!open);
        }}
        className="p-2 rounded-lg text-[#5A5A66] hover:text-[#F0EDE8] hover:bg-[#1E1E26] transition-colors"
      >
        <MoreHorizontal size={16} />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-full mt-1 w-48 bg-[#1E1E26] border border-[#2A2A35] rounded-lg shadow-xl z-20 py-1 overflow-hidden">
            <button
              onClick={() => {
                onView();
                setOpen(false);
              }}
              className="w-full flex items-center gap-2 px-3 py-2 text-sm text-[#F0EDE8] hover:bg-[#252530] transition-colors"
            >
              <Eye size={14} /> View Details
            </button>
            {booking.status === 'new' && (
              <button className="w-full flex items-center gap-2 px-3 py-2 text-sm text-[#22C55E] hover:bg-[#252530] transition-colors">
                <Check size={14} /> Accept
              </button>
            )}
            <button className="w-full flex items-center gap-2 px-3 py-2 text-sm text-[#EF4444] hover:bg-[#252530] transition-colors">
              <X size={14} /> Cancel
            </button>
            <button className="w-full flex items-center gap-2 px-3 py-2 text-sm text-[#8A8A96] hover:bg-[#252530] transition-colors">
              <RotateCcw size={14} /> Reschedule
            </button>
            <button className="w-full flex items-center gap-2 px-3 py-2 text-sm text-[#8A8A96] hover:bg-[#252530] transition-colors">
              <MessageSquare size={14} /> Message Client
            </button>
          </div>
        </>
      )}
    </div>
  );
}

/* ─── Booking Table Row ─── */
function BookingTableRow({
  booking,
  index,
  onView,
}: {
  booking: Booking;
  index: number;
  onView: () => void;
}) {
  const ServiceIcon = serviceIconMap[booking.service.icon] || MapPin;

  return (
    <tr
      className="border-b border-[#2A2A35] hover:bg-[#1A1A22] transition-colors cursor-pointer group"
      onClick={onView}
      style={{
        animation: `slideRow 0.4s cubic-bezier(0,0,0.2,1) ${index * 0.04}s both`,
      }}
    >
      <td className="px-5 py-3.5">
        <span className="font-mono text-xs font-semibold text-[#D4A853]">{booking.id}</span>
      </td>
      <td className="px-5 py-3.5">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-full bg-[#D4A853] flex items-center justify-center flex-shrink-0">
            <span className="text-[10px] font-semibold text-[#0A0A0F]">
              {booking.customer.name.split(' ').map((n) => n[0]).join('')}
            </span>
          </div>
          <span className="text-sm text-[#F0EDE8]">{booking.customer.name}</span>
        </div>
      </td>
      <td className="px-5 py-3.5">
        <div className="flex items-center gap-2">
          <ServiceIcon size={14} className="text-[#8A8A96] flex-shrink-0" />
          <span className="text-sm text-[#F0EDE8]">{booking.service.name}</span>
        </div>
      </td>
      <td className="px-5 py-3.5">
        <div className="flex items-center gap-1.5">
          <MapPin size={12} className="text-[#5A5A66] flex-shrink-0" />
          <span className="text-xs text-[#8A8A96] truncate max-w-[140px]">{booking.pickup.location}</span>
        </div>
      </td>
      <td className="px-5 py-3.5">
        <p className="text-sm text-[#F0EDE8]">{booking.pickup.date}</p>
        <p className="text-xs text-[#5A5A66]">{booking.pickup.time}</p>
      </td>
      <td className="px-5 py-3.5">
        <span className="font-mono text-sm font-semibold text-[#D4A853]">${booking.price.toFixed(2)}</span>
      </td>
      <td className="px-5 py-3.5">
        <StatusPill status={booking.status} />
      </td>
      <td className="px-5 py-3.5">
        <div onClick={(e) => e.stopPropagation()}>
          <ActionsDropdown booking={booking} onView={onView} />
        </div>
      </td>
    </tr>
  );
}

/* ─── Booking Grid Card ─── */
function BookingGridCard({
  booking,
  index,
  onView,
}: {
  booking: Booking;
  index: number;
  onView: () => void;
}) {
  const ServiceIcon = serviceIconMap[booking.service.icon] || MapPin;

  return (
    <div
      className={cn(
        'bg-[#141419] border border-[#2A2A35] rounded-2xl p-6 transition-all duration-300 cursor-pointer',
        'hover:border-[rgba(212,168,83,0.3)] hover:-translate-y-1 hover:shadow-gold-sm'
      )}
      onClick={onView}
      style={{
        animation: `fadeUp 0.5s cubic-bezier(0,0,0.2,1) ${index * 0.08}s both`,
      }}
    >
      {/* Top: Status + ID */}
      <div className="flex items-center justify-between mb-4">
        <StatusPill status={booking.status} />
        <span className="font-mono text-xs font-semibold text-[#D4A853]">{booking.id}</span>
      </div>

      {/* Client */}
      <div className="flex items-center gap-3 mb-4">
        <div className="w-9 h-9 rounded-full bg-[#D4A853] flex items-center justify-center">
          <span className="text-xs font-semibold text-[#0A0A0F]">
            {booking.customer.name.split(' ').map((n) => n[0]).join('')}
          </span>
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-base font-semibold text-[#F0EDE8] truncate">{booking.customer.name}</p>
        </div>
        <button className="p-1.5 rounded-md text-[#5A5A66] hover:text-[#D4A853] hover:bg-[#1E1E26] transition-colors">
          <Phone size={14} />
        </button>
      </div>

      {/* Service */}
      <div className="flex items-center gap-2 mb-3">
        <ServiceIcon size={14} className="text-[#8A8A96]" />
        <span className="text-sm text-[#8A8A96]">{booking.service.name}</span>
        <span className="ml-auto font-mono text-sm font-semibold text-[#D4A853]">${booking.price.toFixed(2)}</span>
      </div>

      {/* Date/Time */}
      <div className="flex items-center gap-2 mb-3">
        <Calendar size={12} className="text-[#5A5A66]" />
        <span className="text-xs text-[#8A8A96]">{booking.pickup.date}</span>
        <Clock size={12} className="text-[#5A5A66] ml-2" />
        <span className="text-xs text-[#8A8A96]">{booking.pickup.time}</span>
      </div>

      {/* Pickup */}
      <div className="flex items-center gap-2 mb-4">
        <MapPin size={12} className="text-[#5A5A66]" />
        <span className="text-xs text-[#8A8A96] truncate">{booking.pickup.location}</span>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2 pt-4 border-t border-[#2A2A35]">
        <button className="flex-1 px-3 py-2 rounded-full text-xs font-semibold text-[#D4A853] border border-[#D4A853] hover:bg-[rgba(212,168,83,0.1)] transition-all">
          View
        </button>
        {(booking.status === 'new' || booking.status === 'accepted') && (
          <button className="flex-1 px-3 py-2 rounded-full text-xs font-semibold text-[#0A0A0F] bg-[#D4A853] hover:scale-[1.02] transition-all">
            {booking.status === 'new' ? 'Accept' : 'Confirm'}
          </button>
        )}
      </div>
    </div>
  );
}

/* ─── Main Bookings Page ─── */
export default function DashboardBookings() {
  const [activeTab, setActiveTab] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list');
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [sortField, setSortField] = useState<SortField>('date');
  const [sortDir, setSortDir] = useState<SortDir>('desc');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // Filter + Sort
  const filtered = useMemo(() => {
    let data = [...bookings];

    // Status filter
    if (activeTab !== 'all') {
      data = data.filter((b) => b.status === activeTab);
    }

    // Search
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      data = data.filter(
        (b) =>
          b.id.toLowerCase().includes(q) ||
          b.customer.name.toLowerCase().includes(q) ||
          b.pickup.location.toLowerCase().includes(q)
      );
    }

    // Sort
    data.sort((a, b) => {
      let cmp = 0;
      switch (sortField) {
        case 'id':
          cmp = a.id.localeCompare(b.id);
          break;
        case 'customer':
          cmp = a.customer.name.localeCompare(b.customer.name);
          break;
        case 'service':
          cmp = a.service.name.localeCompare(b.service.name);
          break;
        case 'pickup':
          cmp = a.pickup.location.localeCompare(b.pickup.location);
          break;
        case 'date':
          cmp = new Date(a.pickup.date).getTime() - new Date(b.pickup.date).getTime();
          break;
        case 'price':
          cmp = a.price - b.price;
          break;
        case 'status':
          cmp = a.status.localeCompare(b.status);
          break;
      }
      return sortDir === 'asc' ? cmp : -cmp;
    });

    return data;
  }, [activeTab, searchQuery, sortField, sortDir]);

  // Pagination
  const totalPages = Math.ceil(filtered.length / itemsPerPage);
  const paginated = filtered.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDir('asc');
    }
  };

  const SortIcon = ({ field }: { field: SortField }) => (
    <ArrowUpDown
      size={12}
      className={cn(
        'ml-1 transition-colors',
        sortField === field ? 'text-[#D4A853]' : 'text-[#5A5A66]'
      )}
    />
  );

  return (
    <DashboardLayout>
      <style>{`
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes slideRow {
          from { opacity: 0; transform: translateX(-15px); }
          to { opacity: 1; transform: translateX(0); }
        }
      `}</style>

      {/* Header */}
      <div
        className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-6"
        style={{ animation: 'fadeUp 0.4s cubic-bezier(0,0,0.2,1) 0s both' }}
      >
        <div>
          <h1 className="text-4xl font-bold text-[#F0EDE8]">Bookings</h1>
          <p className="text-base text-[#8A8A96] mt-1">
            Manage and track all your ride requests.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2.5 rounded-full text-sm font-semibold text-[#F0EDE8] border border-[#2A2A35] hover:bg-[#1E1E26] transition-all">
            <Download size={14} />
            Export CSV
          </button>
          <button className="flex items-center gap-2 px-4 py-2.5 rounded-full text-sm font-semibold text-[#0A0A0F] bg-[#D4A853] hover:scale-[1.02] hover:shadow-[0_4px_24px_rgba(212,168,83,0.3)] transition-all">
            <Plus size={14} />
            New Booking
          </button>
        </div>
      </div>

      {/* Status Filter Tabs */}
      <div
        className="flex items-center gap-2 overflow-x-auto pb-2 mb-6 scrollbar-hide"
        style={{ animation: 'fadeUp 0.4s cubic-bezier(0,0,0.2,1) 0.1s both' }}
      >
        {statusTabs.map((tab) => {
          const isActive = activeTab === tab.key;
          const tabConfig = statusConfig[tab.key];
          return (
            <button
              key={tab.key}
              onClick={() => {
                setActiveTab(tab.key);
                setCurrentPage(1);
              }}
              className={cn(
                'flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all duration-150 border',
                isActive && tabConfig
                  ? 'border-[rgba(255,255,255,0.1)]'
                  : 'border-[#2A2A35] bg-[#1E1E26] text-[#8A8A96] hover:bg-[#252530] hover:text-[#F0EDE8]',
                isActive && tab.key === 'all' && 'bg-[#F0EDE8] text-[#0A0A0F] border-[#F0EDE8]',
              )}
              style={
                isActive && tabConfig
                  ? {
                      backgroundColor: tabConfig.bg,
                      color: tabConfig.color,
                      borderColor: `${tabConfig.color}4D`,
                    }
                  : {}
              }
            >
              {tab.label}
              <span
                className={cn(
                  'min-w-[20px] h-5 flex items-center justify-center rounded-full px-1.5 text-[10px] font-bold',
                  isActive ? 'bg-[#0A0A0F]/20' : 'bg-[#0A0A0F] text-[#5A5A66]'
                )}
              >
                {tab.count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Toolbar */}
      <div
        className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-4"
        style={{ animation: 'fadeUp 0.3s ease 0.2s both' }}
      >
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#5A5A66]" />
            <input
              type="text"
              placeholder="Search bookings by client, location, or ID..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full sm:w-[320px] h-10 pl-10 pr-4 rounded-lg bg-[#1E1E26] border border-[#2A2A35] text-sm text-[#F0EDE8] placeholder-[#5A5A66] focus:outline-none focus:border-[#D4A853] focus:ring-[3px] focus:ring-[rgba(212,168,83,0.15)] transition-all"
            />
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setViewMode('list')}
            className={cn(
              'p-2.5 rounded-lg transition-colors',
              viewMode === 'list'
                ? 'text-[#D4A853] bg-[#1E1E26]'
                : 'text-[#5A5A66] hover:text-[#F0EDE8] hover:bg-[#1E1E26]'
            )}
          >
            <LayoutList size={18} />
          </button>
          <button
            onClick={() => setViewMode('grid')}
            className={cn(
              'p-2.5 rounded-lg transition-colors',
              viewMode === 'grid'
                ? 'text-[#D4A853] bg-[#1E1E26]'
                : 'text-[#5A5A66] hover:text-[#F0EDE8] hover:bg-[#1E1E26]'
            )}
          >
            <LayoutGrid size={18} />
          </button>
        </div>
      </div>

      {/* List View */}
      {viewMode === 'list' && (
        <div className="bg-[#141419] border border-[#2A2A35] rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-[#141419]">
                  {([
                    ['id', 'Booking ID'],
                    ['customer', 'Client'],
                    ['service', 'Service'],
                    ['pickup', 'Pickup'],
                    ['date', 'Date & Time'],
                    ['price', 'Price'],
                    ['status', 'Status'],
                  ] as [SortField, string][]).map(([field, label]) => (
                    <th
                      key={field}
                      className={cn(
                        'px-5 py-3.5 text-left text-[11px] font-semibold text-[#8A8A96] uppercase tracking-[0.05em] whitespace-nowrap cursor-pointer select-none hover:text-[#F0EDE8] transition-colors',
                        field === 'status' && 'cursor-default hover:text-[#8A8A96]'
                      )}
                      onClick={() => field !== 'status' && handleSort(field)}
                    >
                      <div className="flex items-center">
                        {label}
                        {field !== 'status' && <SortIcon field={field} />}
                      </div>
                    </th>
                  ))}
                  <th className="px-5 py-3.5 w-10" />
                </tr>
              </thead>
              <tbody>
                {paginated.map((booking, i) => (
                  <BookingTableRow
                    key={booking.id}
                    booking={booking}
                    index={i}
                    onView={() => setSelectedBooking(booking)}
                  />
                ))}
                {paginated.length === 0 && (
                  <tr>
                    <td colSpan={8} className="px-5 py-12 text-center text-sm text-[#5A5A66]">
                      No bookings found matching your criteria.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Grid View */}
      {viewMode === 'grid' && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {paginated.map((booking, i) => (
            <BookingGridCard
              key={booking.id}
              booking={booking}
              index={i}
              onView={() => setSelectedBooking(booking)}
            />
          ))}
          {paginated.length === 0 && (
            <div className="col-span-full py-12 text-center text-sm text-[#5A5A66]">
              No bookings found matching your criteria.
            </div>
          )}
        </div>
      )}

      {/* Pagination */}
      {filtered.length > 0 && (
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mt-6">
          <p className="text-xs text-[#5A5A66]">
            Showing {(currentPage - 1) * itemsPerPage + 1}-{Math.min(currentPage * itemsPerPage, filtered.length)} of{' '}
            {filtered.length} bookings
          </p>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className={cn(
                'flex items-center gap-1 px-3 py-2 rounded-lg text-sm transition-all',
                currentPage === 1
                  ? 'text-[#5A5A66] cursor-not-allowed'
                  : 'text-[#8A8A96] hover:bg-[#1E1E26] hover:text-[#F0EDE8]'
              )}
            >
              <ChevronLeft size={14} />
              Previous
            </button>
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
              <button
                key={page}
                onClick={() => setCurrentPage(page)}
                className={cn(
                  'w-9 h-9 rounded-lg text-sm font-medium transition-all',
                  page === currentPage
                    ? 'bg-[#D4A853] text-[#0A0A0F]'
                    : 'text-[#8A8A96] hover:bg-[#1E1E26] hover:text-[#F0EDE8]'
                )}
              >
                {page}
              </button>
            ))}
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className={cn(
                'flex items-center gap-1 px-3 py-2 rounded-lg text-sm transition-all',
                currentPage === totalPages
                  ? 'text-[#5A5A66] cursor-not-allowed'
                  : 'text-[#8A8A96] hover:bg-[#1E1E26] hover:text-[#F0EDE8]'
              )}
            >
              Next
              <ChevronRight size={14} />
            </button>
          </div>
        </div>
      )}

      {/* Detail Modal */}
      {selectedBooking && (
        <BookingDetailModal
          booking={selectedBooking}
          onClose={() => setSelectedBooking(null)}
        />
      )}
    </DashboardLayout>
  );
}
