export interface ServiceField {
  name: string;
  type: 'text' | 'select' | 'number' | 'date' | 'time' | 'textarea' | 'radio';
  label: string;
  placeholder?: string;
  required: boolean;
  options?: string[];
}

export interface Service {
  id: string;
  name: string;
  description: string;
  category: 'airport' | 'hourly' | 'point_to_point' | 'event' | 'vip' | 'senior' | 'errands';
  basePrice: number;
  priceUnit: 'ride' | 'hour' | 'mile';
  duration?: string;
  icon: string;
  isActive: boolean;
  fields: ServiceField[];
}

export interface Review {
  id: string;
  author: string;
  avatar?: string;
  rating: number;
  text: string;
  date: string;
  service: string;
}

export interface Driver {
  id: string;
  name: string;
  avatar: string;
  location: string;
  vehicle: {
    type: string;
    make: string;
    model: string;
    year: number;
    color: string;
    image: string;
    capacity: number;
    luggage: number;
  };
  bio: string;
  tagline: string;
  usps: string[];
  services: Service[];
  ratings: {
    average: number;
    count: number;
  };
  reviews: Review[];
  pricingTier: 'starter' | 'professional' | 'premier';
  isAvailable: boolean;
  responseTime: string;
  memberSince: string;
  totalRides: number;
  status: 'active' | 'pending' | 'suspended';
  hourlyRate: number;
  specialties: string[];
  phone?: string;
}

export interface BookingFormData {
  serviceId: string;
  date: string;
  time: string;
  pickupLocation: string;
  dropoffLocation: string;
  passengers: number;
  specialRequests: string;
  flightNumber?: string;
  airport?: string;
  pickupType?: string;
  luggageCount?: number;
  hours?: number;
  itineraryNotes?: string;
  companyName?: string;
  eventType?: string;
}

export interface Customer {
  id: string;
  name: string;
  initials: string;
  email: string;
  phone: string;
  type: 'personal' | 'corporate' | 'recurring';
  company?: string;
  totalBookings: number;
  totalSpent: number;
  lastBooking: string;
  avatarColor: string;
  tags: string[];
  notes: { id: string; text: string; date: string; author: string }[];
  preferences: string[];
  recentBookings: { id: string; date: string; service: string; amount: number; status: string }[];
}
